from qcviz_mcp.web.app import app, create_app

__all__ = ["app", "create_app"]