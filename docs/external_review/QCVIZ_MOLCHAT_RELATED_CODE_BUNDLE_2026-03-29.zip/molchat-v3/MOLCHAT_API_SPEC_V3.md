# MOLCHAT_API_SPEC_V3_FULL.md - Comprehensive Project Specification & Source Archive

> **Status:** Final Audited Version (Enterprise-Grade).
> This document is a complete standalone reference containing the full API specification, business logic, and the **entire source code** of all core components.

---

## 1. API Lookup Table (23 Endpoints)

| #   | Method | Path                                   | Description          | Request Body        | Response Body            | Auth |
| --- | ------ | -------------------------------------- | -------------------- | ------------------- | ------------------------ | :--: |
| 1   | POST   | `/api/v1/chat`                         | General Chat (Sync)  | `ChatRequest`       | `ChatResponse`           |  O   |
| 2   | POST   | `/api/v1/chat/stream`                  | Streaming Chat (SSE) | `ChatRequest`       | SSE (text/event-stream)  |  O   |
| 3   | GET    | `/api/v1/chat/{sid}/history`           | History              | -                   | `list[ChatMessage]`      |  O   |
| 4   | GET    | `/api/v1/chat/sessions`                | List Sessions        | -                   | `SessionListResponse`    |  O   |
| 5   | GET    | `/api/v1/sessions`                     | List (Legacy)        | -                   | `SessionListResponse`    |  O   |
| 6   | POST   | `/api/v1/sessions`                     | Create Session       | `SessionCreate`     | `SessionResponse`        |  O   |
| 7   | PATCH  | `/api/v1/sessions/{id}`                | Rename Session       | `SessionCreate`     | `SessionResponse`        |  O   |
| 8   | DELETE | `/api/v1/sessions/{id}`                | Delete Session       | -                   | `SuccessResponse`        |  O   |
| 9   | GET    | `/api/v1/molecules/search`             | Multi-source Search  | -                   | `MoleculeSearchResponse` |  X   |
| 10  | GET    | `/api/v1/molecules/card`               | Molecule Card        | -                   | `MoleculeCardResponse`   |  O   |
| 11  | POST   | `/api/v1/molecules/generate-3d`        | SMILES -> 3D         | `Generate3DRequest` | `Generate3DResponse`     |  O   |
| 12  | GET    | `/api/v1/molecules/generate-3d/sdf`    | SMILES -> SDF        | -                   | `text/plain`             |  O   |
| 13  | GET    | `/api/v1/molecules/resolve`            | Name -> CID          | -                   | `{"resolved": [...]}`    |  O   |
| 14  | GET    | `/api/v1/molecules/{id}`               | Detail by ID         | -                   | `MoleculeDetailResponse` |  O   |
| 15  | GET    | `/api/v1/molecules/{id}/structures`    | List Versions        | -                   | `list[StructureInfo]`    |  O   |
| 16  | GET    | `/api/v1/molecules/{id}/structure/{f}` | Download File        | -                   | `text/plain`             |  O   |
| 17  | POST   | `/api/v1/molecules/{id}/calculate`     | Submit xTB           | -                   | `{"task_id": "..."}`     |  O   |
| 18  | GET    | `/api/v1/molecules/calculations/{tid}` | Poll Status          | -                   | `{"status": "..."}`      |  O   |
| 19  | POST   | `/api/v1/molecules/compare`            | Multi-Compare        | `smiles_list`       | `ComparisonResult`       |  O   |
| 20  | POST   | `/api/v1/feedback`                     | Submit Feedback      | `FeedbackCreate`    | `SuccessResponse`        |  O   |
| 21  | GET    | `/api/v1/feedback/{sid}`               | Session Feedback     | -                   | `list[Feedback]`         |  O   |
| 22  | GET    | `/api/v1/health`                       | System Health        | -                   | `HealthResponse`         |  X   |
| 23  | GET    | `/api/v1/health/live`                  | Liveness             | -                   | `{"status": "alive"}`    |  X   |

---

## 2. Business Logic & Architecture

### 2.1. The 3-Layer Molecule Engine

- **Layer 0 (Search):** Query -> `QueryResolver` -> `SearchAggregator`.
- **Layer 1 (Structure):** `ConforgeHandler` -> `RDKitHandler` fallback.
- **Layer 2 (Calculation):** `XTBRunner` via `CalculationQueue`.

### 2.2. AI Intelligence (`MolChatAgent`)

- Uses `FallbackRouter` (Gemini -> Ollama).
- Implements `HallucinationGuard` to validate numerical facts.

---

## 3. Full Source Code Archive

### File: backend/app/main.py

```py

"""
FastAPI application entry point.

Configures:
  • Application metadata (title, version, docs)
  • Middleware stack
  • Route registration
  • Startup / shutdown lifecycle hooks
  • Prometheus metrics (optional)
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

import structlog
from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError

from app.core.config import settings
from app.core.database import dispose_engine, engine
from app.core.logging import setup_logging
from app.core.redis import close_redis_pool
from app.middleware import register_middleware
from app.middleware.error_handler import ErrorHandlerMiddleware, MolChatError
from app.routers import include_routers

logger = structlog.get_logger(__name__)


# ═══════════════════════════════════════════════
# Lifespan
# ═══════════════════════════════════════════════


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifecycle manager."""
    # ── Startup ──
    setup_logging()
    logger.info(
        "app_starting",
        app=settings.APP_NAME,
        version=settings.APP_VERSION,
        env=settings.APP_ENV,
    )

    # Verify database connectivity
    try:
        from sqlalchemy import text

        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
        logger.info("database_connected")
    except Exception as exc:
        logger.error("database_connection_failed", error=str(exc))

    # Verify Redis connectivity
    try:
        from app.core.redis import get_redis_client

        client = get_redis_client()
        await client.ping()
        await client.aclose()
        logger.info("redis_connected")
    except Exception as exc:
        logger.warning("redis_connection_failed", error=str(exc))

    # Prometheus metrics
    if settings.PROMETHEUS_ENABLED:
        try:
            from prometheus_fastapi_instrumentator import Instrumentator

            Instrumentator(
                should_group_status_codes=True,
                should_ignore_untemplated=True,
                should_respect_env_var=False,
                excluded_handlers=["/health/live", "/metrics"],
                env_var_name="ENABLE_METRICS",
            )  # .instrument(app).expose(app, endpoint="/metrics")  # moved outside lifespan
            logger.info("prometheus_metrics_enabled")
        except ImportError:
            logger.debug("prometheus_instrumentator_not_installed")

    logger.info("app_started")
    yield

    # ── Shutdown ──
    logger.info("app_shutting_down")
    await close_redis_pool()
    await dispose_engine()
    logger.info("app_stopped")


# ═══════════════════════════════════════════════
# Application factory
# ═══════════════════════════════════════════════


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description=(
            "MolChat – AI-Powered Molecular Intelligence Chatbot API. "
            "Search molecules, visualize structures, compute properties, "
            "and chat with an AI chemistry assistant."
        ),
        docs_url="/docs" if settings.APP_DEBUG or settings.is_development else None,
        redoc_url="/redoc" if settings.APP_DEBUG or settings.is_development else None,
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    # Middleware
    register_middleware(app)

    # Routes
    include_routers(app)

    # Root redirect
    @app.get("/", include_in_schema=False)
    async def root():
        return {
            "name": settings.APP_NAME,
            "version": settings.APP_VERSION,
            "docs": "/docs",
            "health": "/api/v1/health",
        }

    return app


# ── Singleton for uvicorn ──
app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=settings.APP_HOST,
        port=settings.APP_PORT,
        reload=settings.is_development,
        log_level=settings.LOG_LEVEL.lower(),
        workers=1,
    )
```

### File: backend/app/routers/**init**.py

```py

"""
API Routers – FastAPI route definitions for MolChat.

All routers share the ``/api/v1`` prefix and are registered
in ``main.py`` via ``include_routers(app)``.
"""

from __future__ import annotations

from fastapi import FastAPI

from app.routers.chat import router as chat_router
from app.routers.feedback import router as feedback_router
from app.routers.health import router as health_router
from app.routers.molecules import router as molecules_router
from app.routers.sessions import router as sessions_router
from app.routers.websocket import router as ws_router

_API_PREFIX = "/api/v1"


def include_routers(app: FastAPI) -> None:
    """Register all routers on the FastAPI application."""
    app.include_router(health_router, prefix=_API_PREFIX, tags=["Health"])
    app.include_router(molecules_router, prefix=_API_PREFIX, tags=["Molecules"])
    app.include_router(chat_router, prefix=_API_PREFIX, tags=["Chat"])
    app.include_router(sessions_router, prefix=_API_PREFIX, tags=["Sessions"])
    app.include_router(feedback_router, prefix=_API_PREFIX, tags=["Feedback"])
    app.include_router(ws_router, prefix="", tags=["WebSocket"])


__all__ = ["include_routers"]
```

### File: backend/app/routers/chat.py

```py

"""
Chat API routes.

Endpoints:
  POST /api/v1/chat              – send a message and receive AI response
  POST /api/v1/chat/stream       – SSE streaming response
  GET  /api/v1/chat/{session_id}/history – get conversation history
"""

from __future__ import annotations

import uuid
from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.session import ChatMessage, Session
from app.schemas.chat import (
    ChatMessageResponse,
    ChatRequest,
    ChatResponse,
    SessionListResponse,
    SessionResponse,
    SessionUpdate,
)
from app.schemas.common import ErrorResponse
from app.services.intelligence.agent import (
    AgentResponse,
    ConversationMessage,
    MolChatAgent,
)

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/chat")


# ── Dependency ──

def _get_agent() -> MolChatAgent:
    return MolChatAgent()


# ═══════════════════════════════════════════════
# Chat (non-streaming)
# ═══════════════════════════════════════════════


@router.post(
    "",
    response_model=ChatResponse,
    summary="Send a chat message",
    description="Send a message to MolChat AI and receive a response with tool results.",
    responses={502: {"model": ErrorResponse}},
)
async def chat(
    request: ChatRequest,
    db: AsyncSession = Depends(get_db),
    agent: MolChatAgent = Depends(_get_agent),
) -> ChatResponse:
    log = logger.bind(session_id=str(request.session_id))
    log.info("chat_request", message_preview=request.message[:80])

    # ── Resolve or create session ──
    session = await _resolve_session(db, request.session_id, request.message)

    # ── Load conversation history ──
    history = await _load_history(db, session.id, limit=20)

    # ── Run agent ──
    agent_response: AgentResponse = await agent.chat(
        user_message=request.message,
        history=history,
        session_id=session.id,
        context=request.context,
    )

    # ── Persist messages ──
    user_msg = await _save_message(
        db,
        session_id=session.id,
        role="user",
        content=request.message,
    )
    assistant_msg = await _save_message(
        db,
        session_id=session.id,
        role="assistant",
        content=agent_response.content,
        model_used=agent_response.model_used,
        token_count=agent_response.token_count,
        tool_calls={
            "calls": [
                {
                    "tool": tc.tool_name,
                    "args": tc.arguments,
                    "success": tc.success,
                }
                for tc in agent_response.tool_calls
            ]
        } if agent_response.tool_calls else None,
    )

    # Update session message count & auto-title
    session.message_count += 2
    await _generate_title(db, session, request.message)
    await db.flush()

    return ChatResponse(
        session_id=session.id,
        message=ChatMessageResponse.model_validate(assistant_msg),
        molecules_referenced=agent_response.molecules_referenced,
        tool_results=[
            {
                "tool": tc.tool_name,
                "success": tc.success,
                "result_preview": str(tc.result)[:300],
                "elapsed_ms": tc.elapsed_ms,
            }
            for tc in agent_response.tool_calls
        ],
        confidence=agent_response.confidence,
        hallucination_flags=agent_response.hallucination_flags,
        elapsed_ms=agent_response.elapsed_ms,
    )


# ═══════════════════════════════════════════════
# Streaming
# ═══════════════════════════════════════════════


@router.post(
    "/stream",
    summary="Stream a chat response (SSE)",
    description="Server-Sent Events stream of tokens and tool results.",
)
async def chat_stream(
    request: ChatRequest,
    db: AsyncSession = Depends(get_db),
    agent: MolChatAgent = Depends(_get_agent),
) -> StreamingResponse:
    session = await _resolve_session(db, request.session_id, request.message)
    history = await _load_history(db, session.id, limit=20)

    # Save user message immediately
    await _save_message(db, session_id=session.id, role="user", content=request.message)

    async def event_generator():
        import json

        full_content = ""

        async for event in agent.chat_stream(
            user_message=request.message,
            history=history,
            session_id=session.id,
            context=request.context,
        ):
            event_type = event.get("type", "token")
            data = event.get("data", "")

            if event_type == "token":
                full_content += data

            payload = json.dumps(event, ensure_ascii=False, default=str)
            yield f"event: {event_type}\ndata: {payload}\n\n"

        # Save full assistant response
        await _save_message(
            db, session_id=session.id, role="assistant", content=full_content
        )
        session.message_count += 2
        await db.flush()

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ═══════════════════════════════════════════════
# History
# ═══════════════════════════════════════════════


@router.get(
    "/{session_id}/history",
    response_model=list[ChatMessageResponse],
    summary="Get conversation history",
)
async def get_history(
    session_id: uuid.UUID,
    limit: int = 50,
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
) -> list[ChatMessageResponse]:
    stmt = (
        select(ChatMessage)
        .where(ChatMessage.session_id == session_id)
        .order_by(ChatMessage.created_at.desc())
        .offset(offset)
        .limit(limit)
    )
    result = await db.execute(stmt)
    messages = result.scalars().all()
    return [
        ChatMessageResponse.model_validate(m) for m in reversed(messages)
    ]




# ═══════════════════════════════════════════════
# Session CRUD
# ═══════════════════════════════════════════════


@router.get(
    "/sessions",
    response_model=SessionListResponse,
    summary="List chat sessions",
    description="List all sessions with optional full-text search, sorted by most recent.",
)
async def list_sessions(
    q: str | None = None,
    limit: int = 50,
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
) -> SessionListResponse:
    """Return sessions ordered by updated_at desc.
    If `q` is provided, search session titles and message content.
    """
    from sqlalchemy import or_, func as sqlfunc, distinct

    base = select(Session)

    if q and q.strip():
        search_term = f"%{q.strip()}%"
        # Search in session title OR in any message content
        msg_session_ids = (
            select(distinct(ChatMessage.session_id))
            .where(ChatMessage.content.ilike(search_term))
            .scalar_subquery()
        )
        base = base.where(
            or_(
                Session.title.ilike(search_term),
                Session.id.in_(msg_session_ids),
            )
        )

    # Count
    count_stmt = select(sqlfunc.count()).select_from(base.subquery())
    total = (await db.execute(count_stmt)).scalar() or 0

    # Fetch
    stmt = base.order_by(Session.updated_at.desc()).offset(offset).limit(limit)
    result = await db.execute(stmt)
    sessions = result.scalars().all()

    return SessionListResponse(
        total=total,
        limit=limit,
        offset=offset,
        sessions=[SessionResponse.model_validate(s) for s in sessions],
    )


@router.get(
    "/sessions/{session_id}",
    response_model=SessionResponse,
    summary="Get session details",
)
async def get_session(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> SessionResponse:
    stmt = select(Session).where(Session.id == session_id)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return SessionResponse.model_validate(session)


@router.put(
    "/sessions/{session_id}",
    response_model=SessionResponse,
    summary="Update session title",
)
async def update_session(
    session_id: uuid.UUID,
    body: SessionUpdate,
    db: AsyncSession = Depends(get_db),
) -> SessionResponse:
    stmt = select(Session).where(Session.id == session_id)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if body.title is not None:
        session.title = body.title
    await db.flush()
    return SessionResponse.model_validate(session)


@router.delete(
    "/sessions/{session_id}",
    status_code=204,
    summary="Delete a session and all its messages",
)
async def delete_session(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> None:
    stmt = select(Session).where(Session.id == session_id)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    await db.delete(session)
    await db.flush()


# ═══════════════════════════════════════════════
# Internal helpers
# ═══════════════════════════════════════════════




async def _generate_title(db: AsyncSession, session: Session, user_message: str) -> None:
    """Generate a concise title for the session from the first message."""
    if session.message_count > 0 and session.title and not session.title.startswith(user_message[:20]):
        return  # Already has a real title from a previous turn

    # Simple heuristic: use first 60 chars, cleaned up
    import re
    title = user_message.strip()
    # Remove markdown
    title = re.sub(r'[#*_`~]', '', title)
    # Truncate smartly
    if len(title) > 60:
        # Try to break at word boundary
        title = title[:60].rsplit(' ', 1)[0] + '…'
    session.title = title or "New Chat"
    await db.flush()

async def _resolve_session(
    db: AsyncSession,
    session_id: uuid.UUID | None,
    first_message: str,
) -> Session:
    """Find an existing session or create a new one."""
    if session_id:
        stmt = select(Session).where(Session.id == session_id)
        result = await db.execute(stmt)
        session = result.scalar_one_or_none()
        if session:
            return session

    # Auto-create
    title = first_message[:100].strip() or "New Chat"
    session = Session(
        id=uuid.uuid4(),
        title=title,
        message_count=0,
    )
    db.add(session)
    await db.flush()
    return session


async def _load_history(
    db: AsyncSession,
    session_id: uuid.UUID,
    limit: int = 20,
) -> list[ConversationMessage]:
    """Load recent messages and convert to ConversationMessage."""
    stmt = (
        select(ChatMessage)
        .where(ChatMessage.session_id == session_id)
        .order_by(ChatMessage.created_at.desc())
        .limit(limit * 2)  # user+assistant pairs
    )
    result = await db.execute(stmt)
    messages = list(reversed(result.scalars().all()))

    return [
        ConversationMessage(
            role=m.role,
            content=m.content,
        )
        for m in messages
    ]


async def _save_message(
    db: AsyncSession,
    *,
    session_id: uuid.UUID,
    role: str,
    content: str,
    model_used: str | None = None,
    token_count: int | None = None,
    tool_calls: dict | None = None,
) -> ChatMessage:
    """Persist a chat message to the database."""
    msg = ChatMessage(
        id=uuid.uuid4(),
        session_id=session_id,
        role=role,
        content=content,
        model_used=model_used,
        token_count=token_count,
        tool_calls=tool_calls,
    )
    db.add(msg)
    await db.flush()
    return msg
```

### File: backend/app/routers/feedback.py

```py

"""
Feedback API routes.

Endpoints:
  POST /api/v1/feedback              – submit feedback on a message
  GET  /api/v1/feedback/stats        – aggregated feedback statistics
  GET  /api/v1/feedback/{session_id} – feedback for a session
"""

from __future__ import annotations

import uuid
from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.feedback import Feedback
from app.models.session import ChatMessage
from app.schemas.common import SuccessResponse

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/feedback")


# ── Request / Response schemas ──


class FeedbackCreate(BaseModel):
    message_id: uuid.UUID = Field(..., description="The chat message being rated")
    session_id: uuid.UUID = Field(..., description="Session the message belongs to")
    rating: int = Field(..., ge=1, le=5, description="Rating 1-5")
    category: str | None = Field(
        default=None,
        description="Category: accuracy, helpfulness, speed, hallucination, other",
    )
    comment: str | None = Field(default=None, max_length=2000)


class FeedbackResponse(BaseModel):
    id: uuid.UUID
    message_id: uuid.UUID
    session_id: uuid.UUID
    rating: int
    category: str | None
    comment: str | None
    created_at: str

    class Config:
        from_attributes = True


class FeedbackStats(BaseModel):
    total_feedbacks: int
    average_rating: float | None
    rating_distribution: dict[int, int]
    category_distribution: dict[str, int]
    recent_comments: list[dict[str, Any]]


# ═══════════════════════════════════════════════
# Submit
# ═══════════════════════════════════════════════


@router.post(
    "",
    response_model=SuccessResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Submit feedback on a message",
)
async def submit_feedback(
    body: FeedbackCreate,
    db: AsyncSession = Depends(get_db),
) -> SuccessResponse:
    # Verify message exists
    msg_stmt = select(ChatMessage).where(ChatMessage.id == body.message_id)
    msg_result = await db.execute(msg_stmt)
    if msg_result.scalar_one_or_none() is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Message not found",
        )

    feedback = Feedback(
        id=uuid.uuid4(),
        message_id=body.message_id,
        session_id=body.session_id,
        rating=body.rating,
        category=body.category,
        comment=body.comment,
    )
    db.add(feedback)
    await db.flush()

    logger.info(
        "feedback_submitted",
        feedback_id=str(feedback.id),
        rating=body.rating,
        category=body.category,
    )
    return SuccessResponse(message="Feedback submitted successfully")


# ═══════════════════════════════════════════════
# Statistics
# ═══════════════════════════════════════════════


@router.get(
    "/stats",
    response_model=FeedbackStats,
    summary="Aggregated feedback statistics",
)
async def get_feedback_stats(
    db: AsyncSession = Depends(get_db),
) -> FeedbackStats:
    # Total & average
    total_stmt = select(func.count()).select_from(Feedback)
    total = (await db.execute(total_stmt)).scalar() or 0

    avg_stmt = select(func.avg(Feedback.rating))
    avg_rating = (await db.execute(avg_stmt)).scalar()

    # Rating distribution
    rating_dist_stmt = (
        select(Feedback.rating, func.count())
        .group_by(Feedback.rating)
        .order_by(Feedback.rating)
    )
    rating_rows = (await db.execute(rating_dist_stmt)).fetchall()
    rating_distribution = {row[0]: row[1] for row in rating_rows}

    # Category distribution
    cat_stmt = (
        select(Feedback.category, func.count())
        .where(Feedback.category.is_not(None))
        .group_by(Feedback.category)
        .order_by(func.count().desc())
    )
    cat_rows = (await db.execute(cat_stmt)).fetchall()
    category_distribution = {row[0]: row[1] for row in cat_rows}

    # Recent comments
    recent_stmt = (
        select(Feedback)
        .where(Feedback.comment.is_not(None), Feedback.comment != "")
        .order_by(Feedback.created_at.desc())
        .limit(10)
    )
    recent_result = await db.execute(recent_stmt)
    recent = [
        {
            "rating": f.rating,
            "category": f.category,
            "comment": f.comment,
            "created_at": str(f.created_at),
        }
        for f in recent_result.scalars().all()
    ]

    return FeedbackStats(
        total_feedbacks=total,
        average_rating=round(float(avg_rating), 2) if avg_rating else None,
        rating_distribution=rating_distribution,
        category_distribution=category_distribution,
        recent_comments=recent,
    )


# ═══════════════════════════════════════════════
# Per-session feedback
# ═══════════════════════════════════════════════


@router.get(
    "/{session_id}",
    response_model=list[FeedbackResponse],
    summary="Feedback for a session",
)
async def get_session_feedback(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> list[FeedbackResponse]:
    stmt = (
        select(Feedback)
        .where(Feedback.session_id == session_id)
        .order_by(Feedback.created_at.desc())
    )
    result = await db.execute(stmt)
    feedbacks = result.scalars().all()

    return [
        FeedbackResponse(
            id=f.id,
            message_id=f.message_id,
            session_id=f.session_id,
            rating=f.rating,
            category=f.category,
            comment=f.comment,
            created_at=str(f.created_at),
        )
        for f in feedbacks
    ]
```

### File: backend/app/routers/health.py

```py

"""
Health check & readiness endpoints.

Endpoints:
  GET /api/v1/health      – full health status (DB, Redis, LLM, Cache)
  GET /api/v1/health/live  – lightweight liveness probe (K8s)
  GET /api/v1/health/ready – readiness probe (all dependencies)
"""

from __future__ import annotations

import time
from typing import Any

import structlog
from fastapi import APIRouter, Depends
from redis.asyncio import Redis
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.redis import get_redis
from app.schemas.common import HealthResponse

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/health")


@router.get(
    "",
    response_model=HealthResponse,
    summary="Full health check",
    description="Returns status of all dependencies: database, cache, LLM providers.",
)
async def health_check(
    db: AsyncSession = Depends(get_db),
    redis: Redis = Depends(get_redis),
) -> HealthResponse:
    t0 = time.perf_counter()
    checks: dict[str, Any] = {}

    # ── PostgreSQL ──
    try:
        result = await db.execute(text("SELECT 1"))
        val = result.scalar()
        checks["database"] = {
            "status": "healthy" if val == 1 else "degraded",
            "type": "postgresql",
        }
    except Exception as exc:
        checks["database"] = {"status": "unhealthy", "error": str(exc)}

    # ── Redis ──
    try:
        pong = await redis.ping()
        info = await redis.info(section="memory")
        checks["cache"] = {
            "status": "healthy" if pong else "degraded",
            "type": "redis",
            "used_memory": info.get("used_memory_human", "unknown"),
        }
    except Exception as exc:
        checks["cache"] = {"status": "unhealthy", "error": str(exc)}

    # ── Ollama ──
    try:
        from app.services.intelligence.ollama_client import OllamaClient

        ollama = OllamaClient()
        ollama_health = await ollama.health_check()
        checks["ollama"] = ollama_health
    except Exception as exc:
        checks["ollama"] = {"status": "unhealthy", "error": str(exc)}

    # ── Gemini (connectivity only) ──
    try:
        from app.services.intelligence.gemini_client import GeminiClient

        gemini = GeminiClient()
        checks["gemini"] = await gemini.health_check()
    except Exception as exc:
        checks["gemini"] = {"status": "unhealthy", "error": str(exc)}

    # ── Calculation queue ──
    try:
        from app.services.molecule_engine.layer2_calculation.task_queue import CalculationQueue

        queue = CalculationQueue(redis)
        queue_stats = await queue.stats()
        checks["calculation_queue"] = {
            "status": "healthy",
            **queue_stats,
        }
    except Exception as exc:
        checks["calculation_queue"] = {"status": "unhealthy", "error": str(exc)}

    # ── Overall status ──
    critical_healthy = all(
        checks.get(k, {}).get("status") in ("healthy", "degraded")
        for k in ("database", "cache")
    )

    elapsed_ms = (time.perf_counter() - t0) * 1000

    return HealthResponse(
        status="healthy" if critical_healthy else "unhealthy",
        version=settings.APP_VERSION,
        environment=settings.APP_ENV,
        checks=checks,
        elapsed_ms=round(elapsed_ms, 2),
    )


@router.get(
    "/live",
    summary="Liveness probe",
    description="Lightweight check — returns 200 if the process is alive.",
)
async def liveness() -> dict[str, str]:
    return {"status": "alive"}


@router.get(
    "/ready",
    summary="Readiness probe",
    description="Returns 200 only when DB and Redis are reachable.",
)
async def readiness(
    db: AsyncSession = Depends(get_db),
    redis: Redis = Depends(get_redis),
) -> dict[str, str]:
    try:
        await db.execute(text("SELECT 1"))
        await redis.ping()
        return {"status": "ready"}
    except Exception as exc:
        from fastapi import HTTPException

        raise HTTPException(status_code=503, detail=f"Not ready: {exc}")

```

### File: backend/app/routers/molecules.py

```py

"""
Molecule API routes.

Endpoints:
  GET  /api/v1/molecules/search       – search across all sources
  GET  /api/v1/molecules/{id}         – detail by UUID
  GET  /api/v1/molecules/{id}/structure/{format}  – download structure file
  POST /api/v1/molecules/{id}/calculate           – submit xTB calculation
  GET  /api/v1/molecules/calculations/{task_id}   – poll calculation status
  POST /api/v1/molecules/compare      – compare multiple molecules
"""

from __future__ import annotations
import asyncio
import httpx

import uuid
from typing import Any

import structlog
from pydantic import BaseModel as _BaseModel
from fastapi import APIRouter, Depends, Query
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.redis import get_redis
from app.schemas.common import ErrorResponse
from app.schemas.molecule import (
    MoleculeDetailResponse,
    MoleculeSearchRequest,
    MoleculeSearchResponse,
)
from app.services.molecule_engine.cache_manager import MoleculeCacheManager
from app.services.molecule_engine.layer0_search.aggregator import SearchAggregator
from app.services.molecule_engine.layer0_search.base import classify_query
from app.services.molecule_engine.layer0_search.local_db import LocalDBProvider
from app.services.molecule_engine.layer0_search.pubchem import PubChemProvider
from app.services.molecule_engine.layer1_structure.converter import FormatConverter
from app.services.molecule_engine.layer2_calculation.property_calc import PropertyCalculator
from app.services.molecule_engine.layer2_calculation.task_queue import CalculationQueue
from app.services.molecule_engine.orchestrator import MoleculeOrchestrator

logger = structlog.get_logger(__name__)



class Generate3DRequest(_BaseModel):
    """Request body for SMILES to 3D structure generation."""
    smiles: str
    name: str | None = None
    format: str = "sdf"
    optimize_xtb: bool = False


class Generate3DResponse(_BaseModel):
    """Response with generated 3D structure."""
    smiles: str
    format: str
    structure_data: str
    generation_method: str
    atom_count: int
    properties: dict | None = None


router = APIRouter(prefix="/molecules")


# ── Dependency helpers ──

async def _get_orchestrator(
    db: AsyncSession = Depends(get_db),
    redis: Redis = Depends(get_redis),
) -> MoleculeOrchestrator:
    cache = MoleculeCacheManager(redis)
    aggregator = SearchAggregator()
    aggregator.set_local_provider(LocalDBProvider(db))
    return MoleculeOrchestrator(db=db, cache=cache, search_aggregator=aggregator)




# ═══════════════════════════════════════════════
# Generate 3D from SMILES (no DB required)
# ═══════════════════════════════════════════════


@router.post(
    "/generate-3d",
    response_model=Generate3DResponse,
    summary="Generate 3D structure from SMILES",
    description="Convert SMILES to 3D structure using RDKit ETKDG, optionally optimized with xTB.",
)
async def generate_3d_from_smiles(
    body: Generate3DRequest,
) -> Generate3DResponse:
    """Generate 3D molecular structure from SMILES string.

    Full pipeline:
      1. CONFORGE (CDPKit) — best quality 3D conformer
      2. RDKit ETKDGv3 + MMFF94 — fallback if CONFORGE unavailable
      3. xTB GFN2 geometry optimization — optional, on top of 1 or 2
      4. Format conversion if not SDF
    """
    from app.services.molecule_engine.layer1_structure.rdkit_handler import RDKitHandler
    from app.services.molecule_engine.layer1_structure.conforge_handler import ConforgeHandler
    from app.services.molecule_engine.layer1_structure.converter import FormatConverter

    rdkit_h = RDKitHandler()

    # Validate SMILES
    is_valid = await rdkit_h.parse_smiles(body.smiles)
    if not is_valid:
        raise HTTPException(status_code=422, detail=f"Invalid SMILES: {body.smiles}")

    # Count atoms
    atom_count = await rdkit_h.count_atoms(body.smiles)
    if atom_count > 500:
        raise HTTPException(status_code=422, detail=f"Too many atoms ({atom_count}). Max 500.")

    generation_method = ""
    sdf_data: str | None = None

    # ── Stage 1: CONFORGE (CDPKit) — best quality ──
    try:
        conforge = ConforgeHandler()
        sdf_data = await conforge.smiles_to_sdf(body.smiles)
        if sdf_data and len(sdf_data) > 10:
            generation_method = "conforge"
            logger.info("generate3d_conforge_success", atoms=atom_count, sdf_len=len(sdf_data))
    except Exception as exc:
        logger.debug("generate3d_conforge_failed", error=str(exc))

    # ── Stage 2: RDKit ETKDGv3 + MMFF94 (fallback) ──
    if not sdf_data:
        sdf_data = await rdkit_h.smiles_to_sdf(body.smiles, optimize=True)
        if sdf_data:
            generation_method = "rdkit-etkdg"
            logger.info("generate3d_rdkit_fallback", atoms=atom_count, sdf_len=len(sdf_data))

    if not sdf_data:
        raise HTTPException(status_code=500, detail="3D generation failed for this SMILES")

    # ── Stage 3: xTB GFN2 optimization (optional or always for small molecules) ──
    run_xtb = body.optimize_xtb or atom_count <= 80  # auto-optimize small molecules
    if run_xtb and atom_count <= 150:
        try:
            from app.services.molecule_engine.layer2_calculation.xtb_runner import XTBRunner

            converter = FormatConverter(rdkit_h)
            xyz_data = await converter.convert(sdf_data, "sdf", "xyz")

            if xyz_data:
                import asyncio
                runner = XTBRunner()
                xtb_result = await asyncio.wait_for(
                    runner.run(xyz_data, tasks=["optimize"]),
                    timeout=30.0
                )

                if xtb_result.success and xtb_result.optimized_xyz:
                    opt_sdf = await converter.convert(xtb_result.optimized_xyz, "xyz", "sdf")
                    if opt_sdf and len(opt_sdf) > 10:
                        sdf_data = opt_sdf
                        generation_method = f"{generation_method}+xtb-gfn2"
                        logger.info("generate3d_xtb_success",
                                  energy=xtb_result.total_energy,
                                  elapsed=f"{xtb_result.elapsed_seconds:.1f}s")
        except Exception as exc:
            logger.warning("generate3d_xtb_failed_fallback", error=str(exc))

    # ── Stage 4: Format conversion if needed ──
    structure_data = sdf_data
    if body.format != "sdf":
        converter = FormatConverter(rdkit_h)
        converted = await converter.convert(sdf_data, "sdf", body.format)
        if converted:
            structure_data = converted
        else:
            raise HTTPException(status_code=422, detail=f"Cannot convert to {body.format}")

    # ── Compute properties ──
    properties = await rdkit_h.compute_descriptors(body.smiles)

    return Generate3DResponse(
        smiles=body.smiles,
        format=body.format,
        structure_data=structure_data,
        generation_method=generation_method,
        atom_count=atom_count,
        properties=properties if properties else None,
    )


@router.get(
    "/generate-3d/sdf",
    summary="Generate SDF from SMILES (plain text response)",
    responses={200: {"content": {"text/plain": {}}}},
)
async def generate_sdf_plain(
    smiles: str = Query(..., description="SMILES string"),
    optimize_xtb: bool = Query(default=False),
):
    """Quick endpoint: returns raw SDF text from SMILES."""
    from fastapi.responses import PlainTextResponse
    from app.services.molecule_engine.layer1_structure.rdkit_handler import RDKitHandler

    rdkit_h = RDKitHandler()
    is_valid = await rdkit_h.parse_smiles(smiles)
    if not is_valid:
        raise HTTPException(status_code=422, detail="Invalid SMILES")

    sdf = await rdkit_h.smiles_to_sdf(smiles, optimize=True)
    if sdf is None:
        raise HTTPException(status_code=500, detail="3D generation failed")

    return PlainTextResponse(content=sdf, media_type="text/plain")



# ═══════════════════════════════════════════════


# ═══════════════════════════════════════════════
# Molecule Card — comprehensive single-molecule view
# ═══════════════════════════════════════════════

@router.get(
    "/card",
    summary="Get comprehensive molecule card",
    description=(
        "Returns a complete molecule card with properties, safety data, "
        "drug-likeness assessment, similar molecules, and AI-generated summary. "
        "Provide either 'q' (name/SMILES/InChIKey) or 'cid' (PubChem CID)."
    ),
)
async def get_molecule_card(
    q: str | None = Query(
        default=None,
        min_length=1,
        max_length=500,
        description="Search query: molecule name, SMILES, InChIKey, or formula",
    ),
    cid: int | None = Query(
        default=None,
        ge=1,
        description="PubChem CID",
    ),
    orchestrator: MoleculeOrchestrator = Depends(_get_orchestrator),
):
    """Comprehensive molecule card — one query, all information."""
    if not q and not cid:
        from fastapi import HTTPException
        raise HTTPException(
            status_code=400,
            detail="Either 'q' or 'cid' parameter is required",
        )
    return await orchestrator.get_card(q=q, cid=cid)


# Search
# ═══════════════════════════════════════════════


@router.get(
    "/search",
    response_model=MoleculeSearchResponse,
    summary="Search molecules",
    description="Search across PubChem, ChEMBL, ChemSpider, ZINC, and local DB.",
    responses={404: {"model": ErrorResponse}},
)
async def search_molecules(
    q: str = Query(
        ..., min_length=1, max_length=500, description="Search query"
    ),
    limit: int = Query(default=10, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    sources: str | None = Query(
        default=None,
        description="Comma-separated source filter: pubchem,chembl,chemspider,zinc,local",
    ),
    orchestrator: MoleculeOrchestrator = Depends(_get_orchestrator),
) -> MoleculeSearchResponse:
    source_list = (
        [s.strip() for s in sources.split(",") if s.strip()]
        if sources
        else None
    )
    return await orchestrator.search(
        q, limit=limit, offset=offset, sources=source_list
    )


# ═══════════════════════════════════════════════
# Detail
# ═══════════════════════════════════════════════



# --- PubChem Name→CID Resolution (Enterprise Patch v2) ---

_pubchem_cache: dict[str, int | None] = {}

@router.get("/resolve")
async def resolve_molecule_names(
    names: str = Query(..., description="Comma-separated molecule names")
):
    """
    Resolve molecule names to PubChem CIDs via PUG-REST.
    Returns verified CID for each name. Caches results.
    """
    name_list = [n.strip() for n in names.split(",") if n.strip()]
    results = []

    async with httpx.AsyncClient(timeout=10.0) as client:
        for name in name_list[:12]:  # max 12 molecules per request
            # Check cache
            cache_key = name.lower()
            if cache_key in _pubchem_cache:
                cid = _pubchem_cache[cache_key]
                if cid:
                    results.append({"name": name, "cid": cid})
                continue

            try:
                # PubChem name → CID
                url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{name}/cids/JSON"
                resp = await client.get(url)
                if resp.status_code == 200:
                    data = resp.json()
                    cid_list = data.get("IdentifierList", {}).get("CID", [])
                    if cid_list:
                        cid = cid_list[0]  # Take first (most relevant) CID
                        _pubchem_cache[cache_key] = cid
                        results.append({"name": name, "cid": cid})
                    else:
                        _pubchem_cache[cache_key] = None
                elif resp.status_code == 404:
                    _pubchem_cache[cache_key] = None
                else:
                    pass  # Skip on error, don't cache
            except Exception:
                pass  # Skip on network error

            await asyncio.sleep(0.25)  # Respect PubChem rate limit (max 5/s)

    return {"resolved": results, "total": len(results)}
# --- End PubChem Resolution ---

@router.get(
    "/{molecule_id}",
    response_model=MoleculeDetailResponse,
    summary="Get molecule detail",
    responses={404: {"model": ErrorResponse}},
)
async def get_molecule_detail(
    molecule_id: uuid.UUID,
    include_calculation: bool = Query(default=False),
    orchestrator: MoleculeOrchestrator = Depends(_get_orchestrator),
) -> MoleculeDetailResponse:
    return await orchestrator.get_detail(
        molecule_id, include_calculation=include_calculation
    )


# ═══════════════════════════════════════════════
# Structure download
# ═══════════════════════════════════════════════


@router.get(
    "/{molecule_id}/structure/{fmt}",
    summary="Download structure in specified format",
    responses={
        200: {"content": {"text/plain": {}}},
        404: {"model": ErrorResponse},
    },
)
async def get_structure(
    molecule_id: uuid.UUID,
    fmt: str,
    db: AsyncSession = Depends(get_db),
    redis: Redis = Depends(get_redis),
) -> Any:
    from fastapi.responses import PlainTextResponse
    from sqlalchemy import select
    from app.models.molecule import Molecule, MoleculeStructure

    cache = MoleculeCacheManager(redis)

    # Cache check
    cached = await cache.get_structure(molecule_id, fmt)
    if cached:
        return PlainTextResponse(content=cached, media_type="text/plain")

    # DB lookup
    stmt = (
        select(MoleculeStructure)
        .where(
            MoleculeStructure.molecule_id == molecule_id,
            MoleculeStructure.format == fmt,
        )
        .order_by(MoleculeStructure.is_primary.desc())
    )
    result = await db.execute(stmt)
    structure = result.scalars().first()

    if structure is None:
        # Try to generate via converter
        mol_stmt = select(Molecule).where(Molecule.id == molecule_id)
        mol_result = await db.execute(mol_stmt)
        mol = mol_result.scalar_one_or_none()

        if mol is None:
            from app.middleware.error_handler import MoleculeNotFoundError
            raise MoleculeNotFoundError(str(molecule_id))

        # If SMILES is missing, try to get it from RDKit via InChI
        smiles = mol.canonical_smiles
        if not smiles and mol.inchi:
            try:
                from rdkit import Chem
                m = Chem.MolFromInchi(mol.inchi)
                if m:
                    smiles = Chem.MolToSmiles(m)
                    # Save back to DB
                    mol.canonical_smiles = smiles
                    await db.flush()
            except Exception:
                pass

        if not smiles:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail=f"No SMILES available for molecule {molecule_id}")

        converter = FormatConverter()
        converted = await converter.convert(
            smiles, "smiles", fmt
        )
        if converted is None:
            from fastapi import HTTPException
            raise HTTPException(
                status_code=404,
                detail=f"Cannot generate {fmt} format for this molecule",
            )

        await cache.set_structure(molecule_id, fmt, converted)
        return PlainTextResponse(content=converted, media_type="text/plain")

    await cache.set_structure(molecule_id, fmt, structure.structure_data)
    return PlainTextResponse(
        content=structure.structure_data, media_type="text/plain"
    )


# ═══════════════════════════════════════════════
# Calculation
# ═══════════════════════════════════════════════




@router.get(
    "/{molecule_id}/structures",
    summary="List available structure versions",
)
async def list_structures(
    molecule_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> Any:
    """Return all available structure versions for a molecule."""
    from sqlalchemy import select as sa_select
    from app.models.molecule import MoleculeStructure

    stmt = sa_select(MoleculeStructure).where(
        MoleculeStructure.molecule_id == molecule_id,
    )
    result = await db.execute(stmt)
    structures = result.scalars().all()

    return [
        {
            "id": str(s.id),
            "format": s.format,
            "generation_method": s.generation_method,
            "is_primary": s.is_primary,
            "data_length": len(s.structure_data) if s.structure_data else 0,
        }
        for s in structures
    ]

@router.post(
    "/{molecule_id}/calculate",
    summary="Submit xTB calculation",
    responses={422: {"model": ErrorResponse}},
)
async def submit_calculation(
    molecule_id: uuid.UUID,
    method: str = Query(default="gfn2"),
    tasks: str = Query(default="energy", description="Comma-separated: energy,optimize,frequencies"),
    orchestrator: MoleculeOrchestrator = Depends(_get_orchestrator),
) -> dict[str, Any]:
    task_list = [t.strip() for t in tasks.split(",") if t.strip()]
    return await orchestrator.calculate(
        molecule_id, method=method, tasks=task_list
    )


@router.get(
    "/calculations/{task_id}",
    summary="Poll calculation status",
)
async def get_calculation_status(
    task_id: str,
    redis: Redis = Depends(get_redis),
) -> dict[str, Any]:
    queue = CalculationQueue(redis)
    return await queue.get_status(task_id)


# ═══════════════════════════════════════════════
# Compare
# ═══════════════════════════════════════════════


@router.post(
    "/compare",
    summary="Compare multiple molecules",
)
async def compare_molecules(
    smiles_list: list[str],
    names: list[str] | None = None,
) -> dict[str, Any]:
    from app.services.intelligence.tools.molecule_tools import compare_molecules as _compare
    return await _compare(smiles_list=smiles_list, names=names)


```

### File: backend/app/routers/sessions.py

```py

"""
Session management API routes.

Endpoints:
  POST /api/v1/sessions                 – create a new session
  GET  /api/v1/sessions                 – list sessions
  GET  /api/v1/sessions/{session_id}    – get session detail
  PATCH /api/v1/sessions/{session_id}   – update session (rename)
  DELETE /api/v1/sessions/{session_id}  – delete session and its messages
"""

from __future__ import annotations

import uuid

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import delete, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.session import ChatMessage, Session
from app.schemas.chat import (
    SessionCreate,
    SessionListResponse,
    SessionResponse,
)
from app.schemas.common import SuccessResponse

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/sessions")


# ═══════════════════════════════════════════════
# Create
# ═══════════════════════════════════════════════


@router.post(
    "",
    response_model=SessionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new chat session",
)
async def create_session(
    body: SessionCreate,
    db: AsyncSession = Depends(get_db),
) -> SessionResponse:
    session = Session(
        id=uuid.uuid4(),
        title=body.title or "New Chat",
        model_used=body.model_preference,
        message_count=0,
    )
    db.add(session)
    await db.flush()

    logger.info("session_created", session_id=str(session.id))
    return SessionResponse.model_validate(session)


# ═══════════════════════════════════════════════
# List
# ═══════════════════════════════════════════════


@router.get(
    "",
    response_model=SessionListResponse,
    summary="List chat sessions",
)
async def list_sessions(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
) -> SessionListResponse:
    # Total count
    count_stmt = select(func.count()).select_from(Session)
    total = (await db.execute(count_stmt)).scalar() or 0

    # Paginated query
    stmt = (
        select(Session)
        .order_by(Session.updated_at.desc())
        .offset(offset)
        .limit(limit)
    )
    result = await db.execute(stmt)
    sessions = result.scalars().all()

    return SessionListResponse(
        total=total,
        limit=limit,
        offset=offset,
        sessions=[SessionResponse.model_validate(s) for s in sessions],
    )


# ═══════════════════════════════════════════════
# Detail
# ═══════════════════════════════════════════════


@router.get(
    "/{session_id}",
    response_model=SessionResponse,
    summary="Get session detail",
)
async def get_session(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> SessionResponse:
    stmt = select(Session).where(Session.id == session_id)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()

    if session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found",
        )

    return SessionResponse.model_validate(session)


# ═══════════════════════════════════════════════
# Update
# ═══════════════════════════════════════════════


@router.patch(
    "/{session_id}",
    response_model=SessionResponse,
    summary="Update session title",
)
async def update_session(
    session_id: uuid.UUID,
    body: SessionCreate,
    db: AsyncSession = Depends(get_db),
) -> SessionResponse:
    stmt = select(Session).where(Session.id == session_id)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()

    if session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found",
        )

    if body.title is not None:
        session.title = body.title
    if body.model_preference is not None:
        session.model_used = body.model_preference

    await db.flush()
    logger.info("session_updated", session_id=str(session_id))
    return SessionResponse.model_validate(session)


# ═══════════════════════════════════════════════
# Delete
# ═══════════════════════════════════════════════


@router.delete(
    "/{session_id}",
    response_model=SuccessResponse,
    summary="Delete session and all messages",
)
async def delete_session(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> SuccessResponse:
    # Check existence
    stmt = select(Session).where(Session.id == session_id)
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()

    if session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found",
        )

    # Delete messages first (cascade should handle, but explicit is clearer)
    await db.execute(
        delete(ChatMessage).where(ChatMessage.session_id == session_id)
    )
    await db.delete(session)
    await db.flush()

    logger.info("session_deleted", session_id=str(session_id))
    return SuccessResponse(message="Session deleted successfully")
```

### File: backend/app/routers/websocket.py

```py

"""
WebSocket endpoint for real-time chat streaming.

Protocol:
  1. Client connects to ``ws://host/ws/chat/{session_id}``.
  2. Client sends JSON: ``{"type": "message", "content": "..."}``
  3. Server streams back events:
       {"type": "token",       "data": "partial text"}
       {"type": "tool_start",  "data": {"tool_name": "..."}}
       {"type": "tool_result", "data": {"tool_name": "...", "success": true}}
       {"type": "done",        "data": {"elapsed_ms": 1234}}
       {"type": "error",       "data": "error message"}
  4. Client can send ``{"type": "ping"}`` → server replies ``{"type": "pong"}``.
  5. Connection closes on client disconnect or server error.
"""

from __future__ import annotations

import json
import uuid
from typing import Any

import structlog
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

from app.services.intelligence.agent import ConversationMessage, MolChatAgent

logger = structlog.get_logger(__name__)

router = APIRouter()

# Track active connections for monitoring
_active_connections: dict[str, WebSocket] = {}


@router.websocket("/ws/chat/{session_id}")
async def websocket_chat(websocket: WebSocket, session_id: str) -> None:
    """WebSocket endpoint for real-time chat."""
    await websocket.accept()

    connection_id = str(uuid.uuid4())[:8]
    _active_connections[connection_id] = websocket

    log = logger.bind(
        session_id=session_id,
        connection_id=connection_id,
    )
    log.info("ws_connected")

    agent = MolChatAgent()
    history: list[ConversationMessage] = []

    try:
        session_uuid: uuid.UUID | None = None
        try:
            session_uuid = uuid.UUID(session_id)
        except ValueError:
            session_uuid = uuid.uuid4()

        while True:
            # ── Receive message ──
            raw = await websocket.receive_text()

            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await _send_json(websocket, {
                    "type": "error",
                    "data": "Invalid JSON",
                })
                continue

            msg_type = msg.get("type", "message")

            # ── Ping/pong ──
            if msg_type == "ping":
                await _send_json(websocket, {"type": "pong"})
                continue

            # ── Chat message ──
            if msg_type == "message":
                content = msg.get("content", "").strip()
                if not content:
                    await _send_json(websocket, {
                        "type": "error",
                        "data": "Empty message",
                    })
                    continue

                context = msg.get("context")

                log.info("ws_message_received", content_preview=content[:80])

                # Add user message to history
                history.append(
                    ConversationMessage(role="user", content=content)
                )

                # Stream response
                full_response = ""
                async for event in agent.chat_stream(
                    user_message=content,
                    history=history,
                    session_id=session_uuid,
                    context=context,
                ):
                    if websocket.client_state != WebSocketState.CONNECTED:
                        break

                    event_type = event.get("type", "token")

                    if event_type == "token":
                        full_response += event.get("data", "")

                    await _send_json(websocket, event)

                # Add assistant response to history
                if full_response:
                    history.append(
                        ConversationMessage(role="assistant", content=full_response)
                    )

                # Trim history to prevent memory growth
                if len(history) > 40:
                    history = history[-40:]

                continue

            # ── Unknown type ──
            await _send_json(websocket, {
                "type": "error",
                "data": f"Unknown message type: {msg_type}",
            })

    except WebSocketDisconnect:
        log.info("ws_disconnected")

    except Exception as exc:
        log.error("ws_error", error=str(exc))
        try:
            if websocket.client_state == WebSocketState.CONNECTED:
                await _send_json(websocket, {
                    "type": "error",
                    "data": "Internal server error",
                })
        except Exception:
            pass

    finally:
        _active_connections.pop(connection_id, None)
        log.info("ws_cleanup", active_connections=len(_active_connections))


async def _send_json(websocket: WebSocket, data: dict[str, Any]) -> None:
    """Safe JSON send that handles connection state."""
    try:
        if websocket.client_state == WebSocketState.CONNECTED:
            await websocket.send_text(
                json.dumps(data, ensure_ascii=False, default=str)
            )
    except Exception:
        pass


# ═══════════════════════════════════════════════
# Connection monitoring (used by health endpoint)
# ═══════════════════════════════════════════════


def get_active_connections_count() -> int:
    """Return the number of active WebSocket connections."""
    return len(_active_connections)
```

### File: backend/app/services/intelligence/**init**.py

```py

"""
Intelligence Layer – LLM-powered conversational agent for molecular chemistry.

Architecture:
  ┌─────────────────────────────────────────────────────┐
  │                   MolChatAgent                       │
  │  (orchestrates conversation, tool calls, streaming)  │
  └──────┬──────────┬───────────────┬───────────────────┘
         │          │               │
   ┌─────▼────┐ ┌──▼────────┐ ┌───▼──────────────┐
   │ Fallback  │ │  Prompt   │ │  Hallucination   │
   │  Router   │ │  Builder  │ │     Guard        │
   └──┬───┬───┘ └───────────┘ └──────────────────┘
      │   │
 ┌────▼┐ ┌▼─────┐
 │Gemini│ │Ollama│
 │Client│ │Client│
 └─────┘ └──────┘

Tool bindings expose Molecule Engine capabilities as
structured function calls the LLM can invoke.
"""

from app.services.intelligence.agent import MolChatAgent
from app.services.intelligence.fallback_router import FallbackRouter
from app.services.intelligence.hallucination_guard import HallucinationGuard
from app.services.intelligence.prompt_builder import PromptBuilder

__all__ = [
    "MolChatAgent",
    "FallbackRouter",
    "HallucinationGuard",
    "PromptBuilder",
]
```

### File: backend/app/services/intelligence/agent.py

```py

"""
MolChatAgent – top-level conversational agent.

Responsibilities:
  1. Receive user messages and conversation history.
  2. Build prompts with system instructions + tool definitions.
  3. Route to the best available LLM (Gemini → Ollama fallback).
  4. Parse tool-call requests from the LLM response.
  5. Execute tool calls against the Molecule Engine.
  6. Feed tool results back into the LLM for final synthesis.
  7. Run the Hallucination Guard on the final answer.
  8. Return a structured ``AgentResponse``.

Design:
  • Stateless per-request; conversation history is passed in.
  • Supports both synchronous (request/response) and streaming modes.
  • Max tool-call loop depth is capped to prevent infinite recursion.
  • Every step is instrumented with structured logging.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import structlog

from app.core.config import settings
from app.services.intelligence.fallback_router import FallbackRouter, LLMResponse
from app.services.intelligence.hallucination_guard import (
    HallucinationGuard,
    GuardResult,
)
from app.services.intelligence.prompt_builder import PromptBuilder
from app.services.intelligence.tools import get_tool_registry, ToolRegistry

logger = structlog.get_logger(__name__)

_MAX_TOOL_ROUNDS = 5  # Maximum tool-call → LLM loops


@dataclass
class ToolCallResult:
    """Result of executing a single tool call."""

    tool_name: str
    tool_call_id: str
    arguments: dict[str, Any]
    result: dict[str, Any] | str = ""
    success: bool = True
    elapsed_ms: float = 0.0
    error: str = ""


@dataclass
class AgentResponse:
    """Full response from the MolChatAgent."""

    session_id: uuid.UUID | None = None
    content: str = ""
    model_used: str = ""
    token_count: int = 0
    tool_calls: list[ToolCallResult] = field(default_factory=list)
    molecules_referenced: list[dict[str, Any]] = field(default_factory=list)
    confidence: float | None = None
    hallucination_flags: list[str] = field(default_factory=list)
    guard_result: GuardResult | None = None
    elapsed_ms: float = 0.0
    fallback_used: bool = False


@dataclass
class ConversationMessage:
    """A single message in the conversation history."""

    role: str  # system, user, assistant, tool
    content: str
    tool_call_id: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    name: str | None = None


class MolChatAgent:
    """Conversational AI agent for molecular chemistry."""

    def __init__(
        self,
        router: FallbackRouter | None = None,
        prompt_builder: PromptBuilder | None = None,
        guard: HallucinationGuard | None = None,
        tool_registry: ToolRegistry | None = None,
    ) -> None:
        self._router = router or FallbackRouter()
        self._prompt = prompt_builder or PromptBuilder()
        self._guard = guard or HallucinationGuard()
        self._tools = tool_registry or get_tool_registry()

    # ═══════════════════════════════════════════
    # Synchronous (request/response) mode
    # ═══════════════════════════════════════════

    async def chat(
        self,
        user_message: str,
        *,
        history: list[ConversationMessage] | None = None,
        session_id: uuid.UUID | None = None,
        context: dict[str, Any] | None = None,
    ) -> AgentResponse:
        """Process a user message and return a complete response.

        This is the primary entry point for non-streaming interactions.
        """
        t0 = time.perf_counter()
        log = logger.bind(
            session_id=str(session_id) if session_id else None,
            message_preview=user_message[:80],
        )
        log.info("agent_chat_started")

        response = AgentResponse(session_id=session_id)
        history = history or []

        try:
            # ── 1. Build messages ──
            messages = self._build_messages(user_message, history, context)

            # ── 2. Tool-call loop ──
            for round_idx in range(_MAX_TOOL_ROUNDS):
                log.debug("agent_round", round=round_idx + 1)

                # Call LLM
                llm_response = await self._router.generate(
                    messages=messages,
                    tools=self._tools.get_tool_definitions(),
                )

                response.model_used = llm_response.model
                response.token_count += llm_response.token_count
                response.fallback_used = llm_response.fallback_used

                # Check for tool calls
                if llm_response.tool_calls:
                    tool_results = await self._execute_tool_calls(
                        llm_response.tool_calls
                    )
                    response.tool_calls.extend(tool_results)

                    # Collect referenced molecules
                    for tr in tool_results:
                        if isinstance(tr.result, dict):
                            mol_refs = self._extract_molecule_refs(tr.result)
                            response.molecules_referenced.extend(mol_refs)

                    # Append assistant message with tool calls
                    messages.append(ConversationMessage(
                        role="assistant",
                        content=llm_response.content or "",
                        tool_calls=llm_response.tool_calls,
                    ))

                    # Append tool results
                    for tr in tool_results:
                        messages.append(ConversationMessage(
                            role="tool",
                            content=self._serialize_tool_result(tr),
                            tool_call_id=tr.tool_call_id,
                            name=tr.tool_name,
                        ))

                    continue  # Next round

                # No tool calls → final answer
                response.content = llm_response.content or ""
                break

            # ── 2.5 Extract molecules from response text ──
            if response.content and not response.molecules_referenced:
                text_molecules = self._extract_molecules_from_text(response.content)
                if text_molecules:
                    response.molecules_referenced = text_molecules
                    log.info("molecules_extracted_from_text", count=len(text_molecules))

            # ── 2.6 Enrich molecule refs with SMILES from PubChem ──
            if response.molecules_referenced:
                try:
                    await self._enrich_molecules_with_smiles(response.molecules_referenced)
                except Exception as enrich_err:
                    log.debug("smiles_enrichment_failed", error=str(enrich_err))

            # ── 3. Hallucination Guard ──
            if response.content:
                guard_result = await self._guard.check(
                    response=response.content,
                    tool_results=[
                        tr.result for tr in response.tool_calls if tr.success
                    ],
                    context=context,
                )
                response.guard_result = guard_result
                response.confidence = guard_result.confidence
                response.hallucination_flags = guard_result.flags

                # If guard modifies the response
                if guard_result.corrected_response:
                    log.info(
                        "hallucination_guard_corrected",
                        flags=guard_result.flags,
                    )
                    response.content = guard_result.corrected_response

        except Exception as exc:
            log.error("agent_chat_error", error=str(exc))
            response.content = (
                "죄송합니다. 요청을 처리하는 중 오류가 발생했습니다. "
                "잠시 후 다시 시도해 주세요."
            )

        response.elapsed_ms = (time.perf_counter() - t0) * 1000
        log.info(
            "agent_chat_completed",
            model=response.model_used,
            tools_used=len(response.tool_calls),
            elapsed_ms=response.elapsed_ms,
            confidence=response.confidence,
        )
        return response

    # ═══════════════════════════════════════════
    # Streaming mode
    # ═══════════════════════════════════════════

    async def chat_stream(
        self,
        user_message: str,
        *,
        history: list[ConversationMessage] | None = None,
        session_id: uuid.UUID | None = None,
        context: dict[str, Any] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream response tokens as SSE-compatible dicts.

        Yields dicts with keys:
          - ``type``: 'token', 'tool_start', 'tool_result', 'done', 'error'
          - ``data``: the payload
        """
        t0 = time.perf_counter()
        history = history or []
        messages = self._build_messages(user_message, history, context)

        try:
            # First pass: check if LLM wants to call tools
            llm_response = await self._router.generate(
                messages=messages,
                tools=self._tools.get_tool_definitions(),
            )

            if llm_response.tool_calls:
                # Execute tools first, then stream final answer
                for tc in llm_response.tool_calls:
                    yield {
                        "type": "tool_start",
                        "data": {
                            "tool_name": tc.get("name", ""),
                            "arguments": tc.get("arguments", {}),
                        },
                    }

                tool_results = await self._execute_tool_calls(
                    llm_response.tool_calls
                )

                for tr in tool_results:
                    yield {
                        "type": "tool_result",
                        "data": {
                            "tool_name": tr.tool_name,
                            "success": tr.success,
                            "result_preview": str(tr.result)[:200],
                        },
                    }

                # Append tool context and stream final response
                messages.append(ConversationMessage(
                    role="assistant",
                    content=llm_response.content or "",
                    tool_calls=llm_response.tool_calls,
                ))
                for tr in tool_results:
                    messages.append(ConversationMessage(
                        role="tool",
                        content=self._serialize_tool_result(tr),
                        tool_call_id=tr.tool_call_id,
                        name=tr.tool_name,
                    ))

                async for token in self._router.stream(
                    messages=messages, tools=None
                ):
                    yield {"type": "token", "data": token}

            else:
                # No tool calls → stream directly
                async for token in self._router.stream(
                    messages=messages, tools=None
                ):
                    yield {"type": "token", "data": token}

        except Exception as exc:
            logger.error("agent_stream_error", error=str(exc))
            yield {
                "type": "error",
                "data": "스트리밍 중 오류가 발생했습니다.",
            }

        elapsed = (time.perf_counter() - t0) * 1000
        yield {
            "type": "done",
            "data": {"elapsed_ms": elapsed},
        }

    # ═══════════════════════════════════════════
    # Internal helpers
    # ═══════════════════════════════════════════

    def _build_messages(
        self,
        user_message: str,
        history: list[ConversationMessage],
        context: dict[str, Any] | None,
    ) -> list[ConversationMessage]:
        """Assemble the full message list for the LLM."""
        messages: list[ConversationMessage] = []

        # System prompt
        system_prompt = self._prompt.build_system_prompt(context=context)
        messages.append(ConversationMessage(role="system", content=system_prompt))

        # History (truncated to last 20 turns)
        recent_history = history[-40:]  # 20 turns × 2 messages
        messages.extend(recent_history)

        # Current user message
        messages.append(ConversationMessage(role="user", content=user_message))

        return messages

    async def _execute_tool_calls(
        self,
        tool_calls: list[dict[str, Any]],
    ) -> list[ToolCallResult]:
        """Execute a batch of tool calls from the LLM."""
        results: list[ToolCallResult] = []

        for tc in tool_calls:
            tool_name = tc.get("name", tc.get("function", {}).get("name", ""))
            tool_call_id = tc.get("id", str(uuid.uuid4()))
            arguments = tc.get("arguments", tc.get("function", {}).get("arguments", {}))

            if isinstance(arguments, str):
                import json

                try:
                    arguments = json.loads(arguments)
                except (json.JSONDecodeError, TypeError):
                    arguments = {"raw": arguments}

            t0 = time.perf_counter()
            result = ToolCallResult(
                tool_name=tool_name,
                tool_call_id=tool_call_id,
                arguments=arguments,
            )

            try:
                tool_fn = self._tools.get_tool(tool_name)
                if tool_fn is None:
                    result.success = False
                    result.error = f"Unknown tool: {tool_name}"
                    result.result = {"error": result.error}
                else:
                    output = await tool_fn(**arguments)
                    result.result = output
                    result.success = True

            except Exception as exc:
                logger.warning(
                    "tool_execution_error",
                    tool=tool_name,
                    error=str(exc),
                )
                result.success = False
                result.error = str(exc)
                result.result = {"error": str(exc)}

            result.elapsed_ms = (time.perf_counter() - t0) * 1000

            logger.info(
                "tool_executed",
                tool=tool_name,
                success=result.success,
                elapsed_ms=result.elapsed_ms,
            )
            results.append(result)

        return results

    @staticmethod
    def _serialize_tool_result(tr: ToolCallResult) -> str:
        """Serialize a tool result for injection into the LLM context."""
        import json

        if isinstance(tr.result, str):
            return tr.result
        try:
            return json.dumps(tr.result, ensure_ascii=False, default=str)
        except (TypeError, ValueError):
            return str(tr.result)


    @staticmethod
    def _extract_molecules_from_text(text: str) -> list:
        """Extract molecule names from LLM response text."""
        import re

        NOT_MOL = {
            "hbd", "hba", "tpsa", "adme", "ic50", "ec50", "ld50",
            "logp", "pka", "mw", "bbb", "cns", "ppi", "moa", "sar",
            "qsar", "smiles", "inchi", "cas", "fda", "ema", "who",
            "dna", "rna", "atp", "adp", "nad", "nadh", "fad", "coa",
            "nsaid", "nsaids", "otc", "api", "usp",
            "amylase", "protease", "lipase", "enzyme", "protein",
            "receptor", "substrate", "inhibitor", "agonist", "antagonist",
            "starch", "dextrin", "fructose", "sucrose",
            "coffee", "green tea", "black tea", "cocoa", "cola",
            "cyclooxygenase", "prostaglandin", "cox", "cox-1", "cox-2",
            "ligand", "pharmacokinetics", "bioavailability", "lipinski",
            "analgesic", "antipyretic", "anti-inflammatory", "antithrombotic",
            "excretion", "absorption", "distribution", "metabolism",
            "topological", "polar", "surface", "area",
        }

        NOT_MOL_KR = {
            "에너지", "증후군", "소포제", "음료", "드링크", "식품", "건강",
            "치료", "질환", "효과", "부작용", "복용", "처방", "약물",
            "성분", "종류", "기능", "작용", "특징", "방법", "용도",
            "초콜릿", "커피", "녹차", "홍차", "콜라", "사이다", "코코아",
            "에너지 드링크", "초콜릿 음료", "차나무", "커피콩",
            "맥아당", "전해질", "녹말", "덱스트린", "전분",
            "중추신경", "신경전달", "수용체", "효소", "단백질",
            "탄산음료", "소염진통제", "해열진통제", "진통제", "제산제",
            "비타민", "아미노산", "지방산", "탄수화물",
            "배설", "흡수", "분포", "대사", "배출", "축적", "전달",
            "합성", "저해", "사이클로옥시게나제", "프로스타글란딘",
            "혈소판", "위궤양", "중추신경계", "응집", "억제", "활성화",
            "리간드", "경구", "투여", "해열", "진통", "소염", "항혈전",
            "방향족", "지용성", "소화제", "항생제", "항혈전제",
        }

        if not text or len(text) < 10:
            return []

        molecules = []
        seen = set()

        def add(fam: str, pro: str = ""):
            fam = fam.strip().strip("*").strip()
            pro = pro.strip().strip("*").strip() if pro else ""
            if not fam or len(fam) < 2 or len(fam) > 60:
                return
            fl = fam.lower()
            pl = pro.lower() if pro else fl
            if fl in NOT_MOL or pl in NOT_MOL:
                return
            if fam in NOT_MOL_KR or fl in NOT_MOL_KR:
                return
            if fl in seen or pl in seen:
                return
            seen.add(fl)
            if pl != fl:
                seen.add(pl)
            molecules.append({
                "name": pro if pro else fam,
                "familiar_name": fam,
                "professional_name": pro if pro else fam,
            })

        # Pattern 1: **Korean(English)** — split on LAST open-paren to handle names with commas
        for m in re.finditer(r"\*\*([^*]{2,20})\s*[\(（]([^)）]{2,50})[\)）]\*\*", text):
            n1 = m.group(1).strip()
            n2_raw = m.group(2).strip()
            # For English names like "Ursodeoxycholic acid, UDCA" keep full name
            # Only split on comma if the part before comma is >3 chars
            if "," in n2_raw:
                parts = n2_raw.split(",")
                n2 = parts[0].strip()
                # If first part is too short (like "1" from "1,3,7-..."), use full string
                if len(n2) < 3:
                    n2 = n2_raw.strip()
            else:
                n2 = n2_raw
            kr1 = bool(re.search(r"[가-힣]", n1))
            kr2 = bool(re.search(r"[가-힣]", n2))
            if kr1 and not kr2:
                add(n1, n2)
            elif kr2 and not kr1:
                add(n2, n1)
            else:
                add(n1, n2)

        # Pattern 2: Korean (English) without bold
        for m in re.finditer(r"([가-힣]{2,10})\s*[\(（]\s*([A-Za-z][A-Za-z\s\-]{2,40}?)\s*[\)）]", text):
            n2_raw = m.group(2).strip()
            if "," in n2_raw:
                parts = n2_raw.split(",")
                n2 = parts[0].strip() if len(parts[0].strip()) >= 3 else n2_raw
            else:
                n2 = n2_raw
            add(m.group(1), n2)

        # Pattern 3: **BoldEnglish** with chemical suffix
        chem_rx = r"\*\*([A-Z][a-z]+(?:ine|ide|ate|one|cin|lin|rol|fen|xin|pin|nil|zol|mab|nib|vir|rin|min|tan|lol|pam|mide|done|zole|pine|tine|dine|sine|cine|ride)e?)\*\*"
        for m in re.finditer(chem_rx, text):
            add(m.group(1))

        # Pattern 4: **Bold Korean 2-6 chars** if followed by chemical context
        for m in re.finditer(r"\*\*([가-힣]{2,6})\*\*", text):
            name = m.group(1)
            if name in NOT_MOL_KR:
                continue
            # Check context: followed by 은/는/이/의 or (
            after = text[m.end():m.end()+10]
            if re.search(r"^[\s]*[\(（은는이의]", after):
                add(name)

        # Pattern 5: Chemical formulas C8H10N4O2
        for m in re.finditer(r"\b(C\d{1,3}H\d{1,3}(?:[A-Z][a-z]?\d{0,3}){1,5})\b", text):
            if len(m.group(1)) >= 6:
                add(m.group(1))

        # ── Enrich with SMILES from PubChem (best-effort) ──
        import aiohttp

        async def _enrich_smiles(mol_list: list) -> list:
            """Best-effort SMILES enrichment from PubChem."""
            try:
                import httpx
                async with httpx.AsyncClient(timeout=5.0) as client:
                    for mol in mol_list:
                        if mol.get("canonical_smiles"):
                            continue
                        search_name = mol.get("professional_name") or mol.get("name", "")
                        if not search_name:
                            continue
                        try:
                            # Get CID
                            cid_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{search_name}/cids/JSON"
                            resp = await client.get(cid_url)
                            if resp.status_code != 200:
                                continue
                            cid = resp.json().get("IdentifierList", {}).get("CID", [None])[0]
                            if not cid:
                                continue
                            mol["cid"] = cid

                            # Get SMILES
                            prop_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/property/CanonicalSMILES/JSON"
                            prop_resp = await client.get(prop_url)
                            if prop_resp.status_code == 200:
                                props = prop_resp.json().get("PropertyTable", {}).get("Properties", [{}])[0]
                                smiles = props.get("CanonicalSMILES")
                                if smiles:
                                    mol["canonical_smiles"] = smiles
                        except Exception:
                            continue
            except ImportError:
                # httpx not available — try urllib
                pass
            return mol_list

        # Run enrichment synchronously in this context
        try:
            import asyncio
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # We're already in async context — schedule as task
                import concurrent.futures
                # Can't await in staticmethod easily, skip enrichment here
                # Enrichment will happen in the caller (process_message)
                pass
        except Exception:
            pass

        return molecules[:10]
    @staticmethod
    def _extract_molecule_refs(data: dict[str, Any]) -> list[dict[str, Any]]:
        """Extract molecule references from tool results."""
        refs: list[dict[str, Any]] = []

        if "molecule" in data:
            refs.append(data["molecule"])
        if "results" in data and isinstance(data["results"], list):
            for item in data["results"]:
                if isinstance(item, dict) and "canonical_smiles" in item:
                    refs.append(item)

        return refs
    async def _enrich_molecules_with_smiles(self, molecules: list[dict]) -> None:
        """PubChem에서 SMILES와 CID를 가져와 molecules_referenced를 보강."""
        import httpx

        if not molecules:
            return

        async with httpx.AsyncClient(timeout=8.0, follow_redirects=True) as client:
            for mol in molecules:
                # 이미 SMILES가 있으면 스킵
                if mol.get("canonical_smiles"):
                    continue

                # professional_name 우선, 없으면 name
                name = mol.get("professional_name") or mol.get("name") or ""
                if not name or len(name) < 2:
                    continue
                name = name.strip()

                try:
                    # Step 1: name → CID
                    url1 = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{name}/cids/JSON"
                    r1 = await client.get(url1)
                    if r1.status_code != 200:
                        continue
                    cids = r1.json().get("IdentifierList", {}).get("CID", [])
                    if not cids:
                        continue
                    cid = cids[0]

                    # Step 2: CID → CanonicalSMILES
                    url2 = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/property/CanonicalSMILES/JSON"
                    r2 = await client.get(url2)
                    if r2.status_code == 200:
                        props = r2.json().get("PropertyTable", {}).get("Properties", [{}])[0]
                        smiles = props.get("CanonicalSMILES", "")
                        if smiles:
                            mol["canonical_smiles"] = smiles
                            mol["cid"] = cid
                            log.info("smiles_enriched", name=name, cid=cid, smiles=smiles)
                        else:
                            mol["cid"] = cid
                    else:
                        mol["cid"] = cid

                except Exception as e:
                    log.warning("smiles_enrichment_error", name=name, error=str(e))
                    continue

```

### File: backend/app/services/intelligence/fallback_router.py

```py

"""
FallbackRouter – intelligent LLM routing with automatic failover.

Routing logic:
  1. If Gemini API key configured AND monthly cost < budget → Gemini.
  2. If Gemini fails (timeout, 5xx, quota) → Ollama primary.
  3. If Ollama primary fails → Ollama fallback model.
  4. If all fail → raise LLMError.

Also handles:
  • Cost tracking (increments Redis counter after each Gemini call).
  • Circuit breaker pattern (disable Gemini for N seconds after M failures).
  • Unified message format conversion.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import structlog

from app.core.config import settings
from app.middleware.error_handler import LLMError
from app.services.intelligence.gemini_client import GeminiClient
from app.services.intelligence.ollama_client import OllamaClient

logger = structlog.get_logger(__name__)

# Circuit breaker settings
_CB_FAILURE_THRESHOLD = 3        # failures before opening circuit
_CB_RECOVERY_TIMEOUT = 120.0     # seconds before retrying Gemini


@dataclass
class LLMResponse:
    """Normalized response from any LLM provider."""

    content: str = ""
    tool_calls: list[dict[str, Any]] | None = None
    token_count: int = 0
    model: str = ""
    finish_reason: str = ""
    cost_usd: float = 0.0
    fallback_used: bool = False
    elapsed_ms: float = 0.0


@dataclass
class _CircuitState:
    """Per-provider circuit breaker state."""

    failure_count: int = 0
    last_failure_time: float = 0.0
    is_open: bool = False

    def record_failure(self) -> None:
        self.failure_count += 1
        self.last_failure_time = time.time()
        if self.failure_count >= _CB_FAILURE_THRESHOLD:
            self.is_open = True
            logger.warning(
                "circuit_breaker_opened",
                failures=self.failure_count,
            )

    def record_success(self) -> None:
        self.failure_count = 0
        self.is_open = False

    def should_allow(self) -> bool:
        if not self.is_open:
            return True
        elapsed = time.time() - self.last_failure_time
        if elapsed >= _CB_RECOVERY_TIMEOUT:
            logger.info("circuit_breaker_half_open")
            return True  # Half-open: allow one attempt
        return False


class FallbackRouter:
    """Route LLM requests with automatic failover and cost control."""

    def __init__(
        self,
        gemini: GeminiClient | None = None,
        ollama: OllamaClient | None = None,
    ) -> None:
        self._gemini = gemini or GeminiClient()
        self._ollama = ollama or OllamaClient()
        self._gemini_circuit = _CircuitState()

    # ═══════════════════════════════════════════
    # Generate (non-streaming)
    # ═══════════════════════════════════════════

    async def generate(
        self,
        messages: list[Any],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> LLMResponse:
        """Route to the best available LLM and return a normalized response."""
        msg_dicts = self._normalize_messages(messages)

        # ── Try Gemini ──
        if await self._should_use_gemini():
            try:
                result = await self._gemini.generate(
                    msg_dicts,
                    tools=tools,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )

                # Record cost
                if result.get("cost_usd", 0) > 0:
                    await self._gemini.record_cost(result["cost_usd"])

                self._gemini_circuit.record_success()

                return LLMResponse(
                    content=result.get("content", ""),
                    tool_calls=result.get("tool_calls"),
                    token_count=result.get("token_count", 0),
                    model=result.get("model", ""),
                    finish_reason=result.get("finish_reason", ""),
                    cost_usd=result.get("cost_usd", 0.0),
                    fallback_used=False,
                    elapsed_ms=result.get("elapsed_ms", 0.0),
                )

            except Exception as exc:
                logger.warning(
                    "gemini_failed_falling_back",
                    error=str(exc),
                )
                self._gemini_circuit.record_failure()

        # ── Fallback to Ollama ──
        try:
            result = await self._ollama.generate(
                msg_dicts,
                tools=tools,
                temperature=temperature or 0.3,
                max_tokens=max_tokens or 4096,
            )

            return LLMResponse(
                content=result.get("content", ""),
                tool_calls=result.get("tool_calls"),
                token_count=result.get("token_count", 0),
                model=result.get("model", ""),
                finish_reason=result.get("finish_reason", ""),
                cost_usd=0.0,
                fallback_used=True,
                elapsed_ms=result.get("elapsed_ms", 0.0),
            )

        except Exception as exc:
            logger.error("all_llm_providers_failed", error=str(exc))
            raise LLMError(
                model="all",
                reason=f"All LLM providers failed: {exc}",
            )

    # ═══════════════════════════════════════════
    # Streaming
    # ═══════════════════════════════════════════

    async def stream(
        self,
        messages: list[Any],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[str]:
        """Stream tokens from the best available LLM."""
        msg_dicts = self._normalize_messages(messages)

        # ── Try Gemini streaming ──
        if await self._should_use_gemini():
            try:
                async for token in self._gemini.stream(
                    msg_dicts,
                    tools=tools,
                    temperature=temperature,
                    max_tokens=max_tokens,
                ):
                    yield token
                self._gemini_circuit.record_success()
                return
            except Exception as exc:
                logger.warning("gemini_stream_failed", error=str(exc))
                self._gemini_circuit.record_failure()

        # ── Ollama streaming fallback ──
        try:
            async for token in self._ollama.stream(
                msg_dicts,
                tools=tools,
                temperature=temperature or 0.3,
                max_tokens=max_tokens or 4096,
            ):
                yield token
        except Exception as exc:
            logger.error("all_stream_providers_failed", error=str(exc))
            yield "[오류: LLM 서비스를 사용할 수 없습니다.]"

    # ═══════════════════════════════════════════
    # Routing logic
    # ═══════════════════════════════════════════

    async def _should_use_gemini(self) -> bool:
        """Determine whether to route to Gemini."""
        # API key check
        if not self._gemini.is_available():
            return False

        # Circuit breaker
        if not self._gemini_circuit.should_allow():
            logger.debug("gemini_circuit_open_skipping")
            return False

        # Cost budget
        try:
            monthly_cost = await self._gemini.get_monthly_cost()
            if monthly_cost >= settings.GEMINI_MONTHLY_COST_LIMIT:
                logger.info(
                    "gemini_budget_exceeded",
                    cost=monthly_cost,
                    limit=settings.GEMINI_MONTHLY_COST_LIMIT,
                )
                return False
        except Exception:
            pass  # Fail-open: allow Gemini if Redis is down

        return True

    # ═══════════════════════════════════════════
    # Message normalization
    # ═══════════════════════════════════════════

    @staticmethod
    def _normalize_messages(messages: list[Any]) -> list[dict[str, Any]]:
        """Convert ConversationMessage objects or dicts to plain dicts."""
        result: list[dict[str, Any]] = []
        for msg in messages:
            if isinstance(msg, dict):
                result.append(msg)
            else:
                d: dict[str, Any] = {
                    "role": getattr(msg, "role", "user"),
                    "content": getattr(msg, "content", ""),
                }
                if getattr(msg, "tool_call_id", None):
                    d["tool_call_id"] = msg.tool_call_id
                if getattr(msg, "tool_calls", None):
                    d["tool_calls"] = msg.tool_calls
                if getattr(msg, "name", None):
                    d["name"] = msg.name
                result.append(d)
        return result

    # ═══════════════════════════════════════════
    # Health
    # ═══════════════════════════════════════════

    async def health_check(self) -> dict[str, Any]:
        """Return combined health status for all LLM providers."""
        gemini_health, ollama_health = await asyncio.gather(
            self._gemini.health_check(),
            self._ollama.health_check(),
            return_exceptions=True,
        )

        if isinstance(gemini_health, Exception):
            gemini_health = {"status": "error", "error": str(gemini_health)}
        if isinstance(ollama_health, Exception):
            ollama_health = {"status": "error", "error": str(ollama_health)}

        any_healthy = (
            gemini_health.get("status") == "healthy"
            or ollama_health.get("status") == "healthy"
        )

        return {
            "status": "healthy" if any_healthy else "degraded",
            "gemini": gemini_health,
            "ollama": ollama_health,
            "circuit_breaker": {
                "gemini_open": self._gemini_circuit.is_open,
                "failure_count": self._gemini_circuit.failure_count,
            },
        }
```

### File: backend/app/services/intelligence/gemini_client.py

```py

"""
GeminiClient – async wrapper for Google Gemini 2.5 Flash API.

Features:
  • Function/tool-calling support.
  • Streaming via async generators.
  • Automatic retry with exponential backoff (via tenacity).
  • Token counting and cost tracking.
  • Request timeout enforcement.

Cost tracking writes cumulative usage to Redis so the monthly
budget gate in ``FallbackRouter`` can trigger Ollama fallback
before overspending.
"""

from __future__ import annotations

import json
import time
from typing import Any, AsyncIterator

import httpx
import structlog
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.core.config import settings

logger = structlog.get_logger(__name__)

_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
_TIMEOUT = httpx.Timeout(connect=5.0, read=60.0, write=10.0, pool=10.0)

# Approximate pricing (per 1M tokens) – Gemini 2.5 Flash
_PRICE_INPUT_PER_M = 0.15
_PRICE_OUTPUT_PER_M = 0.60


class GeminiClient:
    """Async client for the Google Gemini API."""

    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
    ) -> None:
        self._api_key = api_key or settings.GEMINI_API_KEY
        self._model = model or settings.GEMINI_MODEL
        self._max_tokens = settings.GEMINI_MAX_TOKENS
        self._temperature = settings.GEMINI_TEMPERATURE

    @property
    def model_name(self) -> str:
        return self._model

    def is_available(self) -> bool:
        """Check if the API key is configured."""
        return bool(self._api_key and self._api_key != "YOUR_GEMINI_API_KEY_HERE")

    # ═══════════════════════════════════════════
    # Generate (non-streaming)
    # ═══════════════════════════════════════════

    @retry(
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.HTTPStatusError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def generate(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> dict[str, Any]:
        """Send a chat completion request and return structured result.

        Returns:
            {
                "content": str,
                "tool_calls": list[dict] | None,
                "token_count": int,
                "model": str,
                "finish_reason": str,
                "cost_usd": float,
            }
        """
        url = f"{_BASE_URL}/models/{self._model}:generateContent"
        params = {"key": self._api_key}

        body = self._build_request_body(
            messages, tools, temperature, max_tokens
        )

        t0 = time.perf_counter()

        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.post(url, params=params, json=body)
            resp.raise_for_status()
            data = resp.json()

        elapsed = (time.perf_counter() - t0) * 1000
        result = self._parse_response(data)
        result["elapsed_ms"] = elapsed

        logger.info(
            "gemini_generate",
            model=self._model,
            tokens=result["token_count"],
            elapsed_ms=elapsed,
            has_tool_calls=bool(result.get("tool_calls")),
        )

        return result

    # ═══════════════════════════════════════════
    # Streaming
    # ═══════════════════════════════════════════

    async def stream(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[str]:
        """Stream response tokens as an async generator."""
        url = f"{_BASE_URL}/models/{self._model}:streamGenerateContent"
        params = {"key": self._api_key, "alt": "sse"}

        body = self._build_request_body(
            messages, tools, temperature, max_tokens
        )

        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            async with client.stream("POST", url, params=params, json=body) as resp:
                resp.raise_for_status()

                buffer = ""
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    raw = line[6:]
                    if raw.strip() == "[DONE]":
                        break
                    try:
                        chunk = json.loads(raw)
                        candidates = chunk.get("candidates", [])
                        if candidates:
                            parts = (
                                candidates[0]
                                .get("content", {})
                                .get("parts", [])
                            )
                            for part in parts:
                                text = part.get("text", "")
                                if text:
                                    yield text
                    except (json.JSONDecodeError, KeyError, IndexError):
                        continue

    # ═══════════════════════════════════════════
    # Request/Response builders
    # ═══════════════════════════════════════════

    def _build_request_body(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        temperature: float | None,
        max_tokens: int | None,
    ) -> dict[str, Any]:
        """Build the Gemini API request body."""
        # Convert our message format to Gemini format
        contents = []
        system_instruction = None

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                system_instruction = {"parts": [{"text": content}]}
                continue

            gemini_role = "model" if role == "assistant" else "user"

            # Handle tool results
            if role == "tool":
                contents.append({
                    "role": "user",
                    "parts": [{
                        "functionResponse": {
                            "name": msg.get("name", "tool"),
                            "response": {
                                "content": content,
                            },
                        },
                    }],
                })
                continue

            parts = [{"text": content}]

            # Handle tool calls in assistant messages
            tool_calls = msg.get("tool_calls")
            if tool_calls:
                for tc in tool_calls:
                    parts.append({
                        "functionCall": {
                            "name": tc.get("name", ""),
                            "args": tc.get("arguments", {}),
                        },
                    })

            contents.append({"role": gemini_role, "parts": parts})

        body: dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature or self._temperature,
                "maxOutputTokens": max_tokens or self._max_tokens,
                "topP": 0.95,
                "topK": 40,
            },
        }

        if system_instruction:
            body["systemInstruction"] = system_instruction

        if tools:
            body["tools"] = [{"functionDeclarations": tools}]

        return body

    def _parse_response(self, data: dict[str, Any]) -> dict[str, Any]:
        """Parse the Gemini API response into a normalized dict."""
        result: dict[str, Any] = {
            "content": "",
            "tool_calls": None,
            "token_count": 0,
            "model": self._model,
            "finish_reason": "",
            "cost_usd": 0.0,
        }

        # Usage metadata
        usage = data.get("usageMetadata", {})
        input_tokens = usage.get("promptTokenCount", 0)
        output_tokens = usage.get("candidatesTokenCount", 0)
        result["token_count"] = input_tokens + output_tokens
        result["cost_usd"] = (
            (input_tokens / 1_000_000 * _PRICE_INPUT_PER_M)
            + (output_tokens / 1_000_000 * _PRICE_OUTPUT_PER_M)
        )

        # Candidates
        candidates = data.get("candidates", [])
        if not candidates:
            return result

        candidate = candidates[0]
        result["finish_reason"] = candidate.get("finishReason", "")

        parts = candidate.get("content", {}).get("parts", [])

        text_parts: list[str] = []
        tool_calls: list[dict[str, Any]] = []

        for part in parts:
            if "text" in part:
                text_parts.append(part["text"])
            elif "functionCall" in part:
                fc = part["functionCall"]
                tool_calls.append({
                    "id": f"call_{len(tool_calls)}",
                    "name": fc.get("name", ""),
                    "arguments": fc.get("args", {}),
                })

        result["content"] = "".join(text_parts)
        if tool_calls:
            result["tool_calls"] = tool_calls

        return result

    # ═══════════════════════════════════════════
    # Cost tracking
    # ═══════════════════════════════════════════

    async def get_monthly_cost(self) -> float:
        """Read the cumulative monthly cost from Redis."""
        try:
            from app.core.redis import get_redis_client

            client = get_redis_client()
            raw = await client.get("molchat:gemini:monthly_cost")
            await client.aclose()
            return float(raw) if raw else 0.0
        except Exception:
            return 0.0

    async def record_cost(self, cost_usd: float) -> float:
        """Atomically increment the monthly cost counter. Returns new total."""
        try:
            from app.core.redis import get_redis_client

            client = get_redis_client()
            new_total = await client.incrbyfloat(
                "molchat:gemini:monthly_cost", cost_usd
            )
            # Set TTL to end of month (~30 days)
            await client.expire("molchat:gemini:monthly_cost", 2_592_000)
            await client.aclose()
            return float(new_total)
        except Exception:
            return 0.0

    async def health_check(self) -> dict[str, Any]:
        """Check Gemini API connectivity and return status."""
        if not self.is_available():
            return {"status": "unavailable", "reason": "api_key_not_configured"}

        try:
            url = f"{_BASE_URL}/models/{self._model}"
            params = {"key": self._api_key}
            async with httpx.AsyncClient(timeout=httpx.Timeout(10.0)) as client:
                resp = await client.get(url, params=params)
                if resp.status_code == 200:
                    return {"status": "healthy", "model": self._model}
                return {
                    "status": "degraded",
                    "http_status": resp.status_code,
                }
        except Exception as exc:
            return {"status": "unhealthy", "error": str(exc)}
```

### File: backend/app/services/intelligence/hallucination_guard.py

```py

"""
HallucinationGuard – three-stage verification of LLM responses.

Stages:
  1. **Cross-reference** – compare claimed facts against tool results.
  2. **Confidence scoring** – evaluate numeric claims and chemical assertions.
  3. **Citation validation** – check that cited sources exist and match.

Output: ``GuardResult`` with overall confidence, list of flags,
and optionally a corrected response.

Design:
  • Runs synchronously after the LLM produces its final answer.
  • Does NOT call the LLM again (no recursive risk).
  • All checks are rule-based or regex-based for determinism.
  • Configurable thresholds via settings.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# Thresholds
_MIN_CONFIDENCE = 0.7
_MOLECULAR_WEIGHT_TOLERANCE = 0.5  # Daltons
_ENERGY_TOLERANCE = 0.01           # Hartree
_LOGP_TOLERANCE = 0.5


@dataclass
class GuardResult:
    """Output of the hallucination guard."""

    confidence: float = 1.0
    flags: list[str] = field(default_factory=list)
    issues: list[dict[str, Any]] = field(default_factory=list)
    corrected_response: str | None = None
    checks_performed: int = 0
    checks_passed: int = 0

    @property
    def is_clean(self) -> bool:
        return len(self.flags) == 0 and self.confidence >= _MIN_CONFIDENCE


class HallucinationGuard:
    """Three-stage hallucination detection and mitigation."""

    async def check(
        self,
        response: str,
        tool_results: list[Any] | None = None,
        context: dict[str, Any] | None = None,
    ) -> GuardResult:
        """Run all guard stages on the LLM response.

        Args:
            response: The LLM's text response.
            tool_results: Raw results from tool calls (for cross-reference).
            context: Additional context (e.g., molecule data).
        """
        result = GuardResult()
        tool_results = tool_results or []
        context = context or {}

        # Stage 1: Cross-reference
        self._stage_cross_reference(response, tool_results, result)

        # Stage 2: Confidence scoring
        self._stage_confidence_scoring(response, tool_results, result)

        # Stage 3: Citation validation
        self._stage_citation_validation(response, result)

        # Additional checks
        self._check_hedging_language(response, result)
        self._check_fabricated_data(response, tool_results, result)

        # Calculate overall confidence
        if result.checks_performed > 0:
            result.confidence = round(
                result.checks_passed / result.checks_performed, 2
            )
        else:
            result.confidence = 0.95  # Default high if no checkable claims

        # Build corrected response if needed
        if not result.is_clean:
            result.corrected_response = self._build_corrected_response(
                response, result
            )

        logger.info(
            "hallucination_guard_result",
            confidence=result.confidence,
            flags=result.flags,
            checks=f"{result.checks_passed}/{result.checks_performed}",
        )

        return result

    # ═══════════════════════════════════════════
    # Stage 1: Cross-reference
    # ═══════════════════════════════════════════

    def _stage_cross_reference(
        self,
        response: str,
        tool_results: list[Any],
        result: GuardResult,
    ) -> None:
        """Compare claimed molecular data against tool results."""
        if not tool_results:
            return

        flat_data = self._flatten_tool_results(tool_results)

        # Check molecular weight claims
        mw_matches = re.findall(
            r"(?:분자량|molecular weight|MW|mol\.?\s*wt\.?)[\s:]*"
            r"([\d.]+)\s*(?:g/mol|Da|dalton)?",
            response,
            re.IGNORECASE,
        )
        for mw_str in mw_matches:
            result.checks_performed += 1
            claimed_mw = float(mw_str)
            actual_mw = flat_data.get("molecular_weight")
            if actual_mw is not None:
                if abs(claimed_mw - actual_mw) <= _MOLECULAR_WEIGHT_TOLERANCE:
                    result.checks_passed += 1
                else:
                    result.flags.append("WRONG_MOLECULAR_WEIGHT")
                    result.issues.append({
                        "type": "cross_ref",
                        "field": "molecular_weight",
                        "claimed": claimed_mw,
                        "actual": actual_mw,
                    })

        # Check LogP claims
        logp_matches = re.findall(
            r"(?:LogP|XLogP|logP)[\s:]*([+-]?[\d.]+)",
            response,
            re.IGNORECASE,
        )
        for logp_str in logp_matches:
            result.checks_performed += 1
            claimed_logp = float(logp_str)
            actual_logp = flat_data.get("logp") or flat_data.get("xlogp")
            if actual_logp is not None:
                if abs(claimed_logp - actual_logp) <= _LOGP_TOLERANCE:
                    result.checks_passed += 1
                else:
                    result.flags.append("WRONG_LOGP")
                    result.issues.append({
                        "type": "cross_ref",
                        "field": "logp",
                        "claimed": claimed_logp,
                        "actual": actual_logp,
                    })

        # Check molecular formula
        formula_matches = re.findall(
            r"(?:분자식|formula|분자 공식)[\s:]*([A-Z][A-Za-z0-9]+)",
            response,
            re.IGNORECASE,
        )
        for formula in formula_matches:
            result.checks_performed += 1
            actual_formula = flat_data.get("molecular_formula")
            if actual_formula is not None:
                if formula.strip() == actual_formula.strip():
                    result.checks_passed += 1
                else:
                    result.flags.append("WRONG_FORMULA")
                    result.issues.append({
                        "type": "cross_ref",
                        "field": "molecular_formula",
                        "claimed": formula,
                        "actual": actual_formula,
                    })

        # Check CID
        cid_matches = re.findall(
            r"(?:CID|PubChem\s*(?:CID)?)[\s:#]*(\d{2,})",
            response,
            re.IGNORECASE,
        )
        for cid_str in cid_matches:
            result.checks_performed += 1
            claimed_cid = int(cid_str)
            actual_cid = flat_data.get("cid")
            if actual_cid is not None:
                if claimed_cid == actual_cid:
                    result.checks_passed += 1
                else:
                    result.flags.append("WRONG_CID")
                    result.issues.append({
                        "type": "cross_ref",
                        "field": "cid",
                        "claimed": claimed_cid,
                        "actual": actual_cid,
                    })

    # ═══════════════════════════════════════════
    # Stage 2: Confidence scoring
    # ═══════════════════════════════════════════

    def _stage_confidence_scoring(
        self,
        response: str,
        tool_results: list[Any],
        result: GuardResult,
    ) -> None:
        """Score confidence based on response characteristics."""
        # Check for specific numeric claims without tool backing
        numeric_claims = re.findall(
            r"([\d.]+)\s*(?:kcal/mol|kJ/mol|eV|Hartree|Å|nm|pm|K|°C|atm|bar|ppm)",
            response,
        )

        has_tool_data = bool(tool_results)

        if numeric_claims and not has_tool_data:
            # Numeric claims without tool results = suspicious
            result.flags.append("UNVERIFIED_NUMERIC_CLAIMS")
            result.issues.append({
                "type": "confidence",
                "message": f"Found {len(numeric_claims)} numeric claims with no tool data",
                "values": numeric_claims[:5],
            })

        # Check for SMILES-like strings that weren't validated
        smiles_pattern = re.findall(
            r"`([A-Za-z0-9@+\-\[\]\\/()\=#$.]+)`",
            response,
        )
        for smiles_candidate in smiles_pattern:
            if len(smiles_candidate) > 5 and any(
                c in smiles_candidate for c in "()[]=#"
            ):
                result.checks_performed += 1
                # Check against tool results
                flat_data = self._flatten_tool_results(tool_results)
                actual_smiles = flat_data.get("canonical_smiles")
                if actual_smiles and smiles_candidate == actual_smiles:
                    result.checks_passed += 1
                elif actual_smiles:
                    result.flags.append("POSSIBLY_WRONG_SMILES")
                    result.issues.append({
                        "type": "confidence",
                        "field": "smiles",
                        "claimed": smiles_candidate,
                        "actual": actual_smiles,
                    })

    # ═══════════════════════════════════════════
    # Stage 3: Citation validation
    # ═══════════════════════════════════════════

    def _stage_citation_validation(
        self,
        response: str,
        result: GuardResult,
    ) -> None:
        """Validate that cited sources are plausible."""
        # Check for PubChem URLs
        pubchem_urls = re.findall(
            r"pubchem\.ncbi\.nlm\.nih\.gov/compound/(\d+)",
            response,
        )
        for cid_str in pubchem_urls:
            result.checks_performed += 1
            cid = int(cid_str)
            if 1 <= cid <= 500_000_000:  # Plausible CID range
                result.checks_passed += 1
            else:
                result.flags.append("IMPLAUSIBLE_CID_CITATION")

        # Check for DOI patterns
        dois = re.findall(r"10\.\d{4,}/[^\s]+", response)
        for doi in dois:
            result.checks_performed += 1
            # Basic plausibility: DOI format is correct
            if re.match(r"^10\.\d{4,}/\S+$", doi):
                result.checks_passed += 1
            else:
                result.flags.append("MALFORMED_DOI")

        # Check for fabricated journal names
        fake_journal_patterns = [
            r"Journal of (?:Advanced|Modern|International) (?:Chemistry|Science)",
            r"Nature Chemistry.*vol\.\s*\d+.*p\.\s*\d+",
        ]
        for pattern in fake_journal_patterns:
            if re.search(pattern, response, re.IGNORECASE):
                result.checks_performed += 1
                result.flags.append("POSSIBLY_FABRICATED_CITATION")
                result.issues.append({
                    "type": "citation",
                    "message": "Response contains a possibly fabricated citation",
                })

    # ═══════════════════════════════════════════
    # Additional checks
    # ═══════════════════════════════════════════

    def _check_hedging_language(
        self,
        response: str,
        result: GuardResult,
    ) -> None:
        """Detect excessive hedging that may indicate uncertainty."""
        hedging_markers = [
            "아마도", "추정", "대략", "정확하지 않", "확인이 필요",
            "probably", "approximately", "might be", "not sure",
            "I think", "I believe", "it seems", "possibly",
        ]
        hedge_count = sum(
            1 for marker in hedging_markers
            if marker.lower() in response.lower()
        )

        if hedge_count >= 3:
            result.flags.append("EXCESSIVE_HEDGING")
            result.issues.append({
                "type": "language",
                "message": f"Response contains {hedge_count} hedging markers",
            })

    def _check_fabricated_data(
        self,
        response: str,
        tool_results: list[Any],
        result: GuardResult,
    ) -> None:
        """Detect potentially fabricated structured data."""
        # Suspiciously round numbers in scientific context
        round_number_pattern = re.findall(
            r"([\d]+\.0{2,})\s*(?:kcal|kJ|eV|Hartree)", response
        )
        if round_number_pattern and not tool_results:
            result.flags.append("SUSPICIOUSLY_ROUND_VALUES")
            result.issues.append({
                "type": "fabrication",
                "message": "Suspiciously round scientific values without tool data",
                "values": round_number_pattern[:3],
            })

    # ═══════════════════════════════════════════
    # Correction
    # ═══════════════════════════════════════════

    def _build_corrected_response(
        self,
        original: str,
        guard_result: GuardResult,
    ) -> str:
        """Append a disclaimer to flagged responses."""
        disclaimer_parts: list[str] = []

        if "WRONG_MOLECULAR_WEIGHT" in guard_result.flags:
            for issue in guard_result.issues:
                if issue.get("field") == "molecular_weight":
                    disclaimer_parts.append(
                        f"⚠️ 분자량 수정: {issue['claimed']} → {issue['actual']} g/mol"
                    )

        if "WRONG_FORMULA" in guard_result.flags:
            for issue in guard_result.issues:
                if issue.get("field") == "molecular_formula":
                    disclaimer_parts.append(
                        f"⚠️ 분자식 수정: {issue['claimed']} → {issue['actual']}"
                    )

        if "WRONG_CID" in guard_result.flags:
            for issue in guard_result.issues:
                if issue.get("field") == "cid":
                    disclaimer_parts.append(
                        f"⚠️ CID 수정: {issue['claimed']} → {issue['actual']}"
                    )

        if "UNVERIFIED_NUMERIC_CLAIMS" in guard_result.flags:
            disclaimer_parts.append(
                "⚠️ 일부 수치 데이터는 도구로 검증되지 않았습니다."
            )

        if "POSSIBLY_FABRICATED_CITATION" in guard_result.flags:
            disclaimer_parts.append(
                "⚠️ 인용된 일부 출처의 정확성을 확인할 수 없습니다."
            )

        if not disclaimer_parts:
            return original

        disclaimer = "\n\n---\n" + "\n".join(disclaimer_parts)
        return original + disclaimer

    # ═══════════════════════════════════════════
    # Utilities
    # ═══════════════════════════════════════════

    @staticmethod
    def _flatten_tool_results(tool_results: list[Any]) -> dict[str, Any]:
        """Flatten tool result list into a single dict for easy lookup."""
        flat: dict[str, Any] = {}
        for tr in tool_results:
            if isinstance(tr, dict):
                flat.update(tr)
                # Handle nested structures
                if "molecule" in tr and isinstance(tr["molecule"], dict):
                    flat.update(tr["molecule"])
                if "properties" in tr and isinstance(tr["properties"], dict):
                    flat.update(tr["properties"])
                if "results" in tr and isinstance(tr["results"], list):
                    for item in tr["results"]:
                        if isinstance(item, dict):
                            flat.update(item)
        return flat
```

### File: backend/app/services/intelligence/ollama_client.py

```py

"""
OllamaClient – async wrapper for the Ollama REST API (local LLM).

Serves as the fallback when Gemini is unavailable or over budget.
Supports tool/function calling (Ollama ≥ 0.4 with compatible models),
streaming, and model management.
"""

from __future__ import annotations

import json
import time
from typing import Any, AsyncIterator

import httpx
import structlog

from app.core.config import settings

logger = structlog.get_logger(__name__)

_TIMEOUT = httpx.Timeout(connect=5.0, read=180.0, write=10.0, pool=10.0)


class OllamaClient:
    """Async client for the Ollama local LLM server."""

    def __init__(
        self,
        base_url: str | None = None,
        model: str | None = None,
        fallback_model: str | None = None,
    ) -> None:
        self._base_url = (base_url or settings.OLLAMA_BASE_URL).rstrip("/")
        self._model = model or settings.OLLAMA_MODEL_PRIMARY
        self._fallback_model = fallback_model or settings.OLLAMA_MODEL_FALLBACK
        self._num_ctx = settings.OLLAMA_NUM_CTX

    @property
    def model_name(self) -> str:
        return self._model

    # ═══════════════════════════════════════════
    # Generate (non-streaming)
    # ═══════════════════════════════════════════

    async def generate(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
        model_override: str | None = None,
    ) -> dict[str, Any]:
        """Send a chat completion request to Ollama.

        Returns the same normalized dict structure as GeminiClient.
        """
        model = model_override or self._model
        url = f"{self._base_url}/api/chat"

        body = self._build_request_body(
            messages, model, tools, temperature, max_tokens
        )

        t0 = time.perf_counter()

        try:
            async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
                resp = await client.post(url, json=body)
                resp.raise_for_status()
                data = resp.json()

        except (httpx.TimeoutException, httpx.HTTPStatusError) as exc:
            # Try fallback model
            if model != self._fallback_model:
                logger.warning(
                    "ollama_primary_failed_trying_fallback",
                    primary=model,
                    fallback=self._fallback_model,
                    error=str(exc),
                )
                return await self.generate(
                    messages,
                    tools=tools,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    model_override=self._fallback_model,
                )
            raise

        elapsed = (time.perf_counter() - t0) * 1000
        result = self._parse_response(data, model)
        result["elapsed_ms"] = elapsed

        logger.info(
            "ollama_generate",
            model=model,
            tokens=result["token_count"],
            elapsed_ms=elapsed,
        )

        return result

    # ═══════════════════════════════════════════
    # Streaming
    # ═══════════════════════════════════════════

    async def stream(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]:
        """Stream response tokens as an async generator."""
        url = f"{self._base_url}/api/chat"

        body = self._build_request_body(
            messages, self._model, tools, temperature, max_tokens
        )
        body["stream"] = True

        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            async with client.stream("POST", url, json=body) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                        msg = chunk.get("message", {})
                        content = msg.get("content", "")
                        if content:
                            yield content
                        if chunk.get("done", False):
                            break
                    except (json.JSONDecodeError, KeyError):
                        continue

    # ═══════════════════════════════════════════
    # Request / Response
    # ═══════════════════════════════════════════

    def _build_request_body(
        self,
        messages: list[dict[str, Any]],
        model: str,
        tools: list[dict[str, Any]] | None,
        temperature: float,
        max_tokens: int,
    ) -> dict[str, Any]:
        """Build the Ollama chat API request body."""
        # Convert messages to Ollama format
        ollama_messages = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "tool":
                # Ollama tool response format
                ollama_messages.append({
                    "role": "tool",
                    "content": content,
                })
                continue

            ollama_msg: dict[str, Any] = {
                "role": role,
                "content": content,
            }

            # Tool calls
            tool_calls = msg.get("tool_calls")
            if tool_calls and role == "assistant":
                ollama_msg["tool_calls"] = [
                    {
                        "function": {
                            "name": tc.get("name", ""),
                            "arguments": tc.get("arguments", {}),
                        }
                    }
                    for tc in tool_calls
                ]

            ollama_messages.append(ollama_msg)

        body: dict[str, Any] = {
            "model": model,
            "messages": ollama_messages,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
                "num_ctx": self._num_ctx,
                "top_p": 0.95,
                "repeat_penalty": 1.1,
            },
        }

        if tools:
            # Convert tool definitions to Ollama format
            body["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.get("name", ""),
                        "description": t.get("description", ""),
                        "parameters": t.get("parameters", {}),
                    },
                }
                for t in tools
            ]

        return body

    def _parse_response(
        self, data: dict[str, Any], model: str
    ) -> dict[str, Any]:
        """Parse Ollama response into normalized dict."""
        message = data.get("message", {})
        content = message.get("content", "")

        # Token counts
        prompt_eval = data.get("prompt_eval_count", 0)
        eval_count = data.get("eval_count", 0)

        # Tool calls
        tool_calls = None
        raw_tool_calls = message.get("tool_calls")
        if raw_tool_calls:
            tool_calls = []
            for i, tc in enumerate(raw_tool_calls):
                fn = tc.get("function", {})
                tool_calls.append({
                    "id": f"call_{i}",
                    "name": fn.get("name", ""),
                    "arguments": fn.get("arguments", {}),
                })

        return {
            "content": content,
            "tool_calls": tool_calls,
            "token_count": prompt_eval + eval_count,
            "model": model,
            "finish_reason": "stop" if data.get("done") else "length",
            "cost_usd": 0.0,  # Local model = free
        }

    # ═══════════════════════════════════════════
    # Model management
    # ═══════════════════════════════════════════

    async def list_models(self) -> list[dict[str, Any]]:
        """List all locally available models."""
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(10.0)) as client:
                resp = await client.get(f"{self._base_url}/api/tags")
                resp.raise_for_status()
                data = resp.json()
                return data.get("models", [])
        except Exception as exc:
            logger.warning("ollama_list_models_error", error=str(exc))
            return []

    async def is_model_available(self, model: str | None = None) -> bool:
        """Check if a specific model is downloaded."""
        model = model or self._model
        models = await self.list_models()
        return any(m.get("name", "").startswith(model) for m in models)

    async def health_check(self) -> dict[str, Any]:
        """Check Ollama server connectivity."""
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(10.0)) as client:
                resp = await client.get(f"{self._base_url}/api/tags")
                if resp.status_code == 200:
                    models = resp.json().get("models", [])
                    model_names = [m.get("name", "") for m in models]
                    primary_ready = any(
                        n.startswith(self._model) for n in model_names
                    )
                    return {
                        "status": "healthy" if primary_ready else "degraded",
                        "models_available": model_names,
                        "primary_model": self._model,
                        "primary_ready": primary_ready,
                    }
                return {"status": "degraded", "http_status": resp.status_code}
        except Exception as exc:
            return {"status": "unhealthy", "error": str(exc)}
```

### File: backend/app/services/intelligence/prompt_builder.py

````py

"""
PromptBuilder – construct system prompts and context-aware instructions.

Responsibilities:
  • Inject the MolChat system persona.
  • Add context-specific instructions (e.g., if a molecule is selected).
  • Format tool usage guidelines.
  • Handle language detection and multilingual prompts.
  • Manage prompt versioning for A/B testing.
"""

from __future__ import annotations

from typing import Any

import structlog

logger = structlog.get_logger(__name__)

_SYSTEM_PROMPT_VERSION = "1.0.0"

_SYSTEM_PROMPT_TEMPLATE = """당신은 MolChat의 AI 어시스턴트입니다. 분자 과학 분야의 깊은 전문 지식을 바탕으로,
사용자와 자연스럽고 유익한 대화를 나눕니다.

## 핵심 원칙

1. **화학 전문성 + 폭넓은 교양**: 화학·약학·생화학이 전문이지만, 화학과 연결된 일상 지식(음식, 음료, 건강, 환경, 산업 등)도 자유롭게 설명합니다.
   - 예: "카페인이 든 음료는?" → 커피, 차, 에너지 드링크를 설명하면서 카페인의 화학적 작용도 함께 소개
   - 예: "소화제 성분은?" → 성분 목록 + 각 성분의 화학적 작용 메커니즘
   - 예: "비타민C가 많은 과일은?" → 과일 목록 + 아스코르브산의 화학 구조와 항산화 메커니즘
2. **정확한 화학 데이터**: 구체적인 분자 데이터(분자량, SMILES, 구조 등)는 반드시 도구를 사용하여 검증합니다.
3. **출처 명시**: 데이터베이스에서 가져온 수치 데이터는 출처를 표기합니다.
4. **불확실성 인정**: 확실하지 않은 정보는 솔직하게 밝히고 추측과 사실을 구분합니다.
5. **안전 우선**: 위험한 화학물질이나 합성 경로 질문에는 안전 경고를 포함합니다.

## 대화 스타일

- **거부하지 마세요**: 화학과 조금이라도 관련된 질문은 적극적으로 답하세요. "저는 화학 어시스턴트라서 그건 모릅니다"라고 하지 마세요.
- **연결 짓기**: 일상적 질문도 화학적 관점을 자연스럽게 덧붙여 교육적 가치를 높이세요.
- **친근하고 흥미롭게**: 전문적이면서도 이해하기 쉽게, 마치 화학을 사랑하는 교수님이 커피 한잔 하며 설명하듯이.
- **풍부하게 답하세요**: 짧고 건조한 답변보다는, 맥락과 배경지식을 포함한 풍성한 답변을 하세요.
- **화학과 전혀 무관한 질문**만 정중히 화학 주제로 안내하세요 (예: "오늘 날씨 어때?" → "날씨는 잘 모르지만, 날씨와 관련된 대기 화학에 대해 알려드릴 수 있어요!")

## 물질 분류 규칙 (분자 카드 생성 판단)

사용자가 언급한 물질이 다음 중 어디에 해당하는지 반드시 구분하세요:
- **단일 화합물 (compound)**: aspirin, caffeine, citric acid, glucose 등 → 분자 카드 생성 가능
- **고분자/혼합물 (polymer/mixture)**: polydextrose, starch, dietary fiber, collagen 등 → 카드 생성 불가, 구성 단위(monomer)를 대신 안내
- **기능적 분류명 (category)**: 항산화제, 비타민, 식이섬유, 고과당옥수수시럽 등 → 카드 생성 불가, 해당 분류에 속하는 대표 화합물을 안내
- **비화학물질 (non-chemical)**: 제품명, 브랜드, 일반 단어 등 → 카드 생성 시도하지 않음

응답에서 분자를 언급할 때:
- 단일 화합물은 **굵게** 표시하고 가능하면 PubChem CID를 함께 표기 (예: **Aspirin** (PubChem CID: 2244))
- 혼합물/분류명은 카드 대신 텍스트로 설명하세요.

## 도구 사용 가이드

사용 가능한 도구:
- `search_molecule`: 이름, SMILES, InChIKey, CID로 분자를 검색합니다.
- `get_molecule_detail`: 특정 분자의 상세 정보(구조, 속성)를 조회합니다.
- `compute_properties`: 분자의 물리화학적 속성을 계산합니다.
- `compare_molecules`: 두 개 이상의 분자를 비교합니다.
- `submit_calculation`: xTB 양자역학 계산을 요청합니다.

도구 사용 전략:
- 사용자가 **특정 분자**에 대해 물으면 `search_molecule`로 검색하여 정확한 데이터를 제공하세요.
- **일반적인 화학 지식** 질문(예: "소화제 종류", "항산화 물질이란?")은 도구 없이 직접 풍부하게 답변하세요.
- 대화 중 언급된 분자의 정확한 수치 데이터가 필요할 때만 도구를 호출하세요.
- 도구 호출이 필요 없는 질문에 불필요하게 도구를 호출하지 마세요.

## 응답 형식
- 분자 이름은 **굵게** 표시합니다.
- SMILES는 `코드` 형식으로 표시합니다.
- 수치 데이터는 적절한 단위와 유효숫자를 포함합니다.
- 복잡한 비교에는 표 형식을 사용합니다.
- 마크다운 서식(제목, 목록, 코드 블록, 표)을 적극 활용하여 가독성을 높이세요.

## 언어
사용자의 언어에 맞춰 응답합니다. 한국어 질문에는 한국어로, 영어 질문에는 영어로 답합니다.
화학 용어는 국제 표준 명명법(IUPAC)도 함께 표기합니다.


## 분자 구조화 데이터 블록 (필수)

응답에서 **단일 화합물**(PubChem CID가 존재하는 것)을 언급할 때, 반드시 응답의 **맨 마지막**에 아래 형식의 블록을 추가하세요:



규칙:
- PubChem CID가 확실한 **개별 화합물만** 포함하세요.
- 카테고리명("Vitamins", "Minerals", "Electrolytes", "영양소" 등)은 절대 포함하지 마세요.
- "name"은 PubChem에서 사용하는 영문 공식 제목을 사용하세요 (예: "L-Ascorbic acid", "Caffeine").
- 응답당 최대 8개까지만 포함하세요.
- 해당 화합물이 없으면 이 블록을 생략하세요.
- 이 블록은 사용자에게 보이지 않으므로, 본문에서도 각 화합물의 CID를 (PubChem CID: XXXXX) 형태로 별도 표기하세요.

{context_section}


# --- 분자 구조화 블록 v2 (이름만, CID 없음) ---
# 답변에 언급하는 모든 분자/화합물을 아래 형식으로 답변 맨 끝에 추가하세요.
# CID는 절대 포함하지 마세요. 이름만 영문으로 작성하세요.
# <!--MOLECULES
# [
#   {{"name": "L-Ascorbic acid"}},
#   {{"name": "Nicotinic acid"}},
#   {{"name": "Pantothenic acid"}}
# ]
# MOLECULES-->
# 카테고리(비타민, 미네랄 등)가 아닌 개별 화합물만 포함하세요.
# --- 분자 구조화 블록 끝 ---
"""

_CONTEXT_MOLECULE_TEMPLATE = """
## 현재 컨텍스트
사용자가 현재 다음 분자를 보고 있습니다:
- 이름: {name}
- CID: {cid}
- SMILES: `{smiles}`
- 분자식: {formula}

이 분자에 관련된 질문일 가능성이 높으므로, 관련 도구 호출 시 이 정보를 활용하세요.
"""


class PromptBuilder:
    """Build context-aware system prompts for the LLM."""

    def __init__(self, version: str | None = None) -> None:
        self._version = version or _SYSTEM_PROMPT_VERSION

    def build_system_prompt(
        self,
        *,
        context: dict[str, Any] | None = None,
        language: str | None = None,
    ) -> str:
        """Build the full system prompt with optional context injection."""
        context_section = ""

        if context:
            context_section = self._build_context_section(context)

        prompt = _SYSTEM_PROMPT_TEMPLATE.format(
            context_section=context_section,
        )

        if language:
            prompt += f"\n\n[사용자 언어 감지: {language}. 해당 언어로 응답하세요.]"

        return prompt.strip()

    def build_tool_result_prompt(
        self,
        tool_name: str,
        result: dict[str, Any] | str,
    ) -> str:
        """Build a prompt for the LLM to synthesize tool results."""
        if isinstance(result, str):
            result_text = result
        else:
            import json
            result_text = json.dumps(result, ensure_ascii=False, indent=2, default=str)

        return (
            f"도구 `{tool_name}`의 실행 결과입니다. "
            f"이 데이터를 사용자 질문의 맥락에 맞게 자연스럽고 정확하게 설명하세요.\n\n"
            f"```json\n{result_text}\n```"
        )

    def build_comparison_prompt(
        self,
        molecules: list[dict[str, Any]],
    ) -> str:
        """Build a prompt for comparing multiple molecules."""
        names = [m.get("name", "Unknown") for m in molecules]
        return (
            f"다음 분자들을 비교 분석해주세요: {', '.join(names)}. "
            "각 분자의 구조적 특징, 물리화학적 속성, 약물유사성을 비교하고 "
            "표 형식으로 정리해주세요."
        )

    def _build_context_section(self, context: dict[str, Any]) -> str:
        """Build the context section for the system prompt."""
        # Molecule context
        if "molecule" in context or "cid" in context:
            return _CONTEXT_MOLECULE_TEMPLATE.format(
                name=context.get("name", context.get("molecule", "Unknown")),
                cid=context.get("cid", "N/A"),
                smiles=context.get("smiles", "N/A"),
                formula=context.get("formula", "N/A"),
            )

        # Generic context
        if context:
            import json
            ctx_str = json.dumps(context, ensure_ascii=False, default=str)
            return f"\n## 추가 컨텍스트\n{ctx_str}"

        return ""

    def get_version(self) -> str:
        """Return the current prompt version."""
        return self._version
````

### File: backend/app/services/intelligence/tools/**init**.py

```py

"""
Tool bindings – expose Molecule Engine capabilities as structured
function calls that the LLM can invoke.

Architecture:
  • ``ToolRegistry`` holds all available tools.
  • Each tool is an async callable with typed parameters.
  • Tool definitions follow the OpenAI/Gemini function-calling schema.
  • The ``MolChatAgent`` queries the registry for definitions and dispatches calls.
"""

from __future__ import annotations

from typing import Any, Callable, Awaitable

import structlog

logger = structlog.get_logger(__name__)


# Type alias for an async tool function
ToolFunction = Callable[..., Awaitable[dict[str, Any] | str]]


class ToolRegistry:
    """Registry of callable tools for the LLM agent."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolFunction] = {}
        self._definitions: list[dict[str, Any]] = []

    def register(
        self,
        name: str,
        fn: ToolFunction,
        definition: dict[str, Any],
    ) -> None:
        """Register a tool with its function and schema definition."""
        self._tools[name] = fn
        self._definitions.append(definition)
        logger.debug("tool_registered", name=name)

    def get_tool(self, name: str) -> ToolFunction | None:
        """Look up a tool by name."""
        return self._tools.get(name)

    def get_tool_definitions(self) -> list[dict[str, Any]]:
        """Return all tool definitions for the LLM."""
        return list(self._definitions)

    def list_tools(self) -> list[str]:
        """Return all registered tool names."""
        return list(self._tools.keys())


# ── Singleton registry ──
_registry: ToolRegistry | None = None


def get_tool_registry() -> ToolRegistry:
    """Get or create the global tool registry.

    Lazily imports and registers all tools on first access.
    """
    global _registry
    if _registry is None:
        _registry = ToolRegistry()
        _register_all_tools(_registry)
    return _registry


def _register_all_tools(registry: ToolRegistry) -> None:
    """Import and register all tool modules."""
    from app.services.intelligence.tools.molecule_tools import register_molecule_tools
    from app.services.intelligence.tools.calculation_tools import register_calculation_tools

    register_molecule_tools(registry)
    register_calculation_tools(registry)

    logger.info(
        "tools_registered",
        count=len(registry.list_tools()),
        tools=registry.list_tools(),
    )


__all__ = [
    "ToolRegistry",
    "ToolFunction",
    "get_tool_registry",
]
```

### File: backend/app/services/intelligence/tools/calculation_tools.py

```py

"""
Calculation tools – xTB quantum chemistry and conformer generation.

These tools submit long-running tasks to the calculation queue
and return task handles for async polling.
"""

from __future__ import annotations

import uuid
from typing import Any

import structlog

from app.services.intelligence.tools import ToolRegistry

logger = structlog.get_logger(__name__)


def register_calculation_tools(registry: ToolRegistry) -> None:
    """Register all calculation-related tools."""

    # ── 1. submit_calculation ──
    registry.register(
        name="submit_calculation",
        fn=submit_calculation,
        definition={
            "name": "submit_calculation",
            "description": (
                "xTB(GFN2-xTB) 양자역학 계산을 요청합니다. "
                "에너지, 구조 최적화, 진동수 분석 등을 수행할 수 있습니다. "
                "계산은 비동기적으로 진행되며, task_id를 통해 상태를 확인할 수 있습니다."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "smiles": {
                        "type": "string",
                        "description": "분자의 SMILES 문자열",
                    },
                    "tasks": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["energy", "optimize", "frequencies"],
                        },
                        "description": "수행할 계산 종류 (기본값: ['energy'])",
                        "default": ["energy"],
                    },
                    "charge": {
                        "type": "integer",
                        "description": "분자의 전하 (기본값: 0)",
                        "default": 0,
                    },
                    "solvent": {
                        "type": "string",
                        "description": "용매 이름 (예: 'water', 'methanol'). 생략 시 기상 계산.",
                    },
                },
                "required": ["smiles"],
            },
        },
    )

    # ── 2. check_calculation ──
    registry.register(
        name="check_calculation",
        fn=check_calculation,
        definition={
            "name": "check_calculation",
            "description": (
                "진행 중인 xTB 계산의 상태를 확인합니다. "
                "완료된 경우 계산 결과(에너지, 최적화 구조, 진동수 등)를 반환합니다."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "string",
                        "description": "submit_calculation에서 반환된 task_id",
                    },
                },
                "required": ["task_id"],
            },
        },
    )

    # ── 3. generate_conformers ──
    registry.register(
        name="generate_conformers",
        fn=generate_conformers,
        definition={
            "name": "generate_conformers",
            "description": (
                "분자의 3D 컨포머(conformer) 앙상블을 생성합니다. "
                "ETKDG 알고리즘으로 다양한 3D 배향을 탐색하고 "
                "MMFF 에너지로 순위를 매깁니다."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "smiles": {
                        "type": "string",
                        "description": "분자의 SMILES 문자열",
                    },
                    "num_conformers": {
                        "type": "integer",
                        "description": "생성할 컨포머 수 (기본값: 20)",
                        "default": 20,
                    },
                    "energy_window": {
                        "type": "number",
                        "description": "에너지 필터 윈도우 (kcal/mol, 기본값: 10.0)",
                        "default": 10.0,
                    },
                },
                "required": ["smiles"],
            },
        },
    )


# ═══════════════════════════════════════════════
# Tool implementations
# ═══════════════════════════════════════════════


async def submit_calculation(
    smiles: str,
    tasks: list[str] | None = None,
    charge: int = 0,
    solvent: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Submit an xTB calculation to the task queue."""
    try:
        from app.services.molecule_engine.layer1_structure.rdkit_handler import RDKitHandler
        from app.services.molecule_engine.layer2_calculation.task_queue import CalculationQueue
        from app.core.config import settings

        rdkit = RDKitHandler()
        tasks = tasks or ["energy"]

        # Validate SMILES
        is_valid = await rdkit.parse_smiles(smiles)
        if not is_valid:
            return {"error": f"유효하지 않은 SMILES: {smiles}"}

        # Check atom count
        atom_count = await rdkit.count_atoms(smiles)
        if atom_count > settings.XTB_MAX_ATOMS:
            return {
                "error": (
                    f"분자가 너무 큽니다 ({atom_count}개 원자, "
                    f"최대 {settings.XTB_MAX_ATOMS}개)"
                ),
            }

        # Generate XYZ for xTB
        xyz = await rdkit.smiles_to_xyz(smiles)
        if xyz is None:
            return {"error": "3D 구조를 생성할 수 없습니다."}

        # Submit to queue
        queue = CalculationQueue()
        molecule_id = uuid.uuid4()

        task_id = await queue.submit(
            molecule_id=molecule_id,
            smiles=smiles,
            method=settings.XTB_METHOD,
            tasks=tasks,
            charge=charge,
            solvent=solvent,
        )

        return {
            "task_id": task_id,
            "status": "pending",
            "smiles": smiles,
            "tasks": tasks,
            "atom_count": atom_count,
            "charge": charge,
            "solvent": solvent or "gas phase",
            "message": (
                f"xTB 계산이 제출되었습니다 (task_id: {task_id}). "
                f"check_calculation 도구로 상태를 확인하세요."
            ),
        }

    except Exception as exc:
        logger.error("tool_submit_calc_error", error=str(exc))
        return {"error": f"계산 제출 중 오류 발생: {exc}"}


async def check_calculation(
    task_id: str,
    **kwargs: Any,
) -> dict[str, Any]:
    """Check the status of a submitted calculation."""
    try:
        from app.services.molecule_engine.layer2_calculation.task_queue import CalculationQueue

        queue = CalculationQueue()
        status = await queue.get_status(task_id)

        if status.get("status") == "not_found":
            return {
                "task_id": task_id,
                "error": "해당 task_id를 찾을 수 없습니다.",
            }

        if status.get("status") == "completed":
            result = status.get("result", {})
            return {
                "task_id": task_id,
                "status": "completed",
                "total_energy_hartree": result.get("total_energy"),
                "homo_lumo_gap_ev": result.get("homo_lumo_gap"),
                "dipole_moment_debye": result.get("dipole_moment"),
                "gibbs_free_energy_hartree": result.get("gibbs_free_energy"),
                "frequencies_count": len(result.get("frequencies", [])),
                "imaginary_frequencies": result.get("imaginary_frequencies", 0),
                "elapsed_seconds": result.get("elapsed_seconds"),
            }

        return {
            "task_id": task_id,
            "status": status.get("status", "unknown"),
            "progress": status.get("progress", 0),
            "message": status.get("message", ""),
        }

    except Exception as exc:
        logger.error("tool_check_calc_error", error=str(exc))
        return {"error": f"상태 확인 중 오류 발생: {exc}"}


async def generate_conformers(
    smiles: str,
    num_conformers: int = 20,
    energy_window: float = 10.0,
    **kwargs: Any,
) -> dict[str, Any]:
    """Generate a conformer ensemble for a molecule."""
    try:
        from app.services.molecule_engine.layer1_structure.rdkit_handler import RDKitHandler
        from app.services.molecule_engine.layer2_calculation.conformer import ConformerGenerator

        rdkit = RDKitHandler()

        # Validate
        is_valid = await rdkit.parse_smiles(smiles)
        if not is_valid:
            return {"error": f"유효하지 않은 SMILES: {smiles}"}

        generator = ConformerGenerator()
        ensemble = await generator.generate(
            smiles,
            num_conformers=min(num_conformers, 100),
            energy_window=energy_window,
        )

        conformer_summaries = []
        for conf in ensemble.conformers[:10]:  # Limit to top 10
            conformer_summaries.append({
                "id": conf.conformer_id,
                "energy_kcal_mol": conf.energy,
                "rmsd_to_best": conf.rmsd_to_best,
                "is_minimum": conf.is_minimum,
            })

        return {
            "smiles": smiles,
            "num_generated": ensemble.num_generated,
            "num_converged": ensemble.num_converged,
            "num_unique": len(ensemble.conformers),
            "method": ensemble.method,
            "elapsed_seconds": round(ensemble.elapsed_seconds, 2),
            "best_energy_kcal_mol": (
                ensemble.conformers[0].energy
                if ensemble.conformers
                else None
            ),
            "conformers": conformer_summaries,
        }

    except Exception as exc:
        logger.error("tool_conformers_error", error=str(exc))
        return {"error": f"컨포머 생성 중 오류 발생: {exc}"}

```

### File: backend/app/services/intelligence/tools/molecule_tools.py

```py

"""
Molecule tools – search, detail, comparison, property computation.

Each tool function:
  • Accepts typed keyword arguments.
  • Returns a dict or string (serialized to JSON for the LLM).
  • Handles its own errors and returns error dicts (never raises).
"""

from __future__ import annotations

from typing import Any

import structlog

from app.services.intelligence.tools import ToolRegistry

logger = structlog.get_logger(__name__)


def register_molecule_tools(registry: ToolRegistry) -> None:
    """Register all molecule-related tools."""

    # ── 1. search_molecule ──
    registry.register(
        name="search_molecule",
        fn=search_molecule,
        definition={
            "name": "search_molecule",
            "description": (
                "분자 데이터베이스(PubChem, ChEMBL, ZINC 등)에서 분자를 검색합니다. "
                "이름, SMILES, InChIKey, CID, 분자식으로 검색할 수 있습니다."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "검색어 (분자 이름, SMILES, InChIKey, CID, 분자식)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "최대 결과 수 (기본값: 5)",
                        "default": 5,
                    },
                },
                "required": ["query"],
            },
        },
    )

    # ── 2. get_molecule_detail ──
    registry.register(
        name="get_molecule_detail",
        fn=get_molecule_detail,
        definition={
            "name": "get_molecule_detail",
            "description": (
                "특정 분자의 상세 정보를 조회합니다. "
                "구조, 3D 좌표, 물리화학적 속성, 약물유사성 등을 포함합니다."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "molecule_id": {
                        "type": "string",
                        "description": "분자 UUID (검색 결과에서 얻은 ID)",
                    },
                    "include_calculation": {
                        "type": "boolean",
                        "description": "xTB 양자 계산 포함 여부 (기본값: false)",
                        "default": False,
                    },
                },
                "required": ["molecule_id"],
            },
        },
    )

    # ── 3. compute_properties ──
    registry.register(
        name="compute_properties",
        fn=compute_properties,
        definition={
            "name": "compute_properties",
            "description": (
                "SMILES 문자열로부터 분자의 물리화학적 속성을 계산합니다. "
                "분자량, LogP, TPSA, 수소결합, 회전결합, QED, Lipinski 규칙 등을 반환합니다."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "smiles": {
                        "type": "string",
                        "description": "분자의 SMILES 문자열",
                    },
                },
                "required": ["smiles"],
            },
        },
    )

    # ── 4. compare_molecules ──
    registry.register(
        name="compare_molecules",
        fn=compare_molecules,
        definition={
            "name": "compare_molecules",
            "description": (
                "두 개 이상의 분자를 비교합니다. "
                "각 분자의 속성을 나란히 비교하여 구조적·물리화학적 차이를 보여줍니다."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "smiles_list": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "비교할 분자들의 SMILES 목록 (2~5개)",
                    },
                    "names": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "분자 이름 목록 (선택, smiles_list와 같은 순서)",
                    },
                },
                "required": ["smiles_list"],
            },
        },
    )


# ═══════════════════════════════════════════════
# Tool implementations
# ═══════════════════════════════════════════════


async def search_molecule(
    query: str,
    limit: int = 5,
    **kwargs: Any,
) -> dict[str, Any]:
    """Search for molecules across all databases."""
    try:
        from app.services.molecule_engine.layer0_search.pubchem import PubChemProvider
        from app.services.molecule_engine.layer0_search.base import classify_query

        search_type = classify_query(query)
        provider = PubChemProvider()
        results = await provider.search(query, search_type, limit=limit)

        if not results:
            return {
                "found": False,
                "query": query,
                "message": f"'{query}'에 대한 검색 결과가 없습니다.",
            }

        return {
            "found": True,
            "query": query,
            "total": len(results),
            "results": [
                {
                    "name": r.name,
                    "canonical_smiles": r.canonical_smiles,
                    "inchikey": r.inchikey,
                    "cid": r.cid,
                    "molecular_formula": r.molecular_formula,
                    "molecular_weight": r.molecular_weight,
                    "source": r.source,
                    "source_url": r.source_url,
                    "properties": r.properties,
                }
                for r in results
            ],
        }

    except Exception as exc:
        logger.error("tool_search_molecule_error", error=str(exc))
        return {"error": f"검색 중 오류 발생: {exc}", "query": query}


async def get_molecule_detail(
    molecule_id: str,
    include_calculation: bool = False,
    **kwargs: Any,
) -> dict[str, Any]:
    """Get detailed information about a specific molecule."""
    try:
        # For now, search by the molecule_id as a CID or name
        from app.services.molecule_engine.layer0_search.pubchem import PubChemProvider
        from app.services.molecule_engine.layer0_search.base import SearchType

        provider = PubChemProvider()

        # Try as CID first
        if molecule_id.isdigit():
            result = await provider.get_by_identifier(
                molecule_id, SearchType.CID
            )
        else:
            result = await provider.get_by_identifier(
                molecule_id, SearchType.NAME
            )

        if result is None:
            return {
                "found": False,
                "molecule_id": molecule_id,
                "message": "분자를 찾을 수 없습니다.",
            }

        # Compute RDKit properties if SMILES available
        properties = {}
        if result.canonical_smiles:
            from app.services.molecule_engine.layer2_calculation.property_calc import (
                PropertyCalculator,
            )

            calc = PropertyCalculator()
            properties = await calc.rdkit_descriptors(result.canonical_smiles)

        return {
            "found": True,
            "name": result.name,
            "canonical_smiles": result.canonical_smiles,
            "inchi": result.inchi,
            "inchikey": result.inchikey,
            "cid": result.cid,
            "molecular_formula": result.molecular_formula,
            "molecular_weight": result.molecular_weight,
            "source": result.source,
            "source_url": result.source_url,
            "properties": {**result.properties, **properties},
            "has_3d_structure": result.structure_3d is not None,
        }

    except Exception as exc:
        logger.error("tool_get_detail_error", error=str(exc))
        return {"error": f"상세 조회 중 오류 발생: {exc}"}


async def compute_properties(
    smiles: str,
    **kwargs: Any,
) -> dict[str, Any]:
    """Compute molecular properties from SMILES."""
    try:
        from app.services.molecule_engine.layer1_structure.rdkit_handler import RDKitHandler
        from app.services.molecule_engine.layer2_calculation.property_calc import PropertyCalculator

        rdkit = RDKitHandler()

        # Validate SMILES
        is_valid = await rdkit.parse_smiles(smiles)
        if not is_valid:
            return {
                "error": f"유효하지 않은 SMILES: {smiles}",
                "smiles": smiles,
            }

        # Canonicalize
        canonical = await rdkit.canonical_smiles(smiles)

        # Compute properties
        calc = PropertyCalculator(rdkit_handler=rdkit)
        properties = await calc.rdkit_descriptors(canonical or smiles)

        # Drug-likeness
        drug_likeness = calc._assess_drug_likeness(properties)

        return {
            "smiles": canonical or smiles,
            "properties": properties,
            "drug_likeness": drug_likeness,
        }

    except Exception as exc:
        logger.error("tool_compute_props_error", error=str(exc))
        return {"error": f"속성 계산 중 오류 발생: {exc}", "smiles": smiles}


async def compare_molecules(
    smiles_list: list[str],
    names: list[str] | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Compare multiple molecules side by side."""
    try:
        from app.services.molecule_engine.layer2_calculation.property_calc import PropertyCalculator

        if len(smiles_list) < 2:
            return {"error": "비교하려면 최소 2개의 분자가 필요합니다."}
        if len(smiles_list) > 5:
            return {"error": "최대 5개까지 비교할 수 있습니다."}

        names = names or [f"Molecule {i+1}" for i in range(len(smiles_list))]
        calc = PropertyCalculator()
        comparisons = []

        for i, smiles in enumerate(smiles_list):
            props = await calc.rdkit_descriptors(smiles)
            drug_likeness = calc._assess_drug_likeness(props)
            comparisons.append({
                "name": names[i] if i < len(names) else f"Molecule {i+1}",
                "smiles": smiles,
                "properties": props,
                "drug_likeness": drug_likeness,
            })

        # Summary differences
        all_keys = set()
        for comp in comparisons:
            all_keys.update(comp["properties"].keys())

        return {
            "count": len(comparisons),
            "molecules": comparisons,
            "property_keys": sorted(all_keys),
        }

    except Exception as exc:
        logger.error("tool_compare_error", error=str(exc))
        return {"error": f"비교 중 오류 발생: {exc}"}
```

### File: backend/app/services/molecule_engine/**init**.py

```py

"""
Molecule Engine – three-layer architecture for molecular data acquisition,
structure processing, and quantum-chemical computation.

Architecture:
  ┌──────────────────────────────────────────────┐
  │            MoleculeOrchestrator               │
  │  (facade: routes all requests through layers) │
  └──────┬──────────┬──────────────┬─────────────┘
         │          │              │
    ┌────▼───┐ ┌────▼─────┐ ┌─────▼──────┐
    │Layer 0 │ │ Layer 1  │ │  Layer 2   │
    │Search  │ │Structure │ │Calculation │
    └────────┘ └──────────┘ └────────────┘

Cache Manager sits beside the orchestrator and transparently
handles Redis read-through / write-through caching.
"""

from app.services.molecule_engine.orchestrator import MoleculeOrchestrator
from app.services.molecule_engine.cache_manager import MoleculeCacheManager

__all__ = [
    "MoleculeOrchestrator",
    "MoleculeCacheManager",
]
```

### File: backend/app/services/molecule_engine/cache_manager.py

```py

"""
MoleculeCacheManager – transparent Redis caching layer for the Molecule Engine.

Strategy:
  • Read-through: check cache before upstream.
  • Write-through: populate cache after upstream.
  • Namespace isolation: ``mol:search:<hash>``, ``mol:detail:<uuid>``, ``mol:struct:<uuid>:<fmt>``.
  • TTL hierarchy: search results 15 min, detail 1 h, structures 24 h.
  • Graceful degradation: all methods return ``None`` on Redis failure.

Serialization uses ``orjson`` for speed (~6× faster than stdlib json).
"""

from __future__ import annotations

import hashlib
import uuid
from typing import Any

import orjson
import structlog
from redis.asyncio import Redis

from app.core.config import settings

logger = structlog.get_logger(__name__)

# TTLs (seconds)
_TTL_SEARCH = 900       # 15 minutes
_TTL_DETAIL = 3600      # 1 hour
_TTL_STRUCTURE = 86400  # 24 hours
_TTL_CALC = 600         # 10 minutes (in-progress status)


def _hash_key(*parts: str) -> str:
    """Produce a deterministic short hash from variable-length key parts."""
    raw = ":".join(str(p) for p in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _serialize(obj: Any) -> bytes:
    """Serialize to JSON bytes via orjson."""
    return orjson.dumps(obj, default=str)


def _deserialize(raw: bytes | str | None) -> Any | None:
    """Deserialize JSON bytes, returning None on failure."""
    if raw is None:
        return None
    try:
        if isinstance(raw, str):
            raw = raw.encode("utf-8")
        return orjson.loads(raw)
    except (orjson.JSONDecodeError, TypeError, ValueError):
        return None


class MoleculeCacheManager:
    """Redis-backed caching for the Molecule Engine.

    Every public method is safe to call even when Redis is down –
    failures are logged and ``None`` / silent-fail is returned.
    """

    def __init__(self, redis: Redis) -> None:
        self._r = redis

    # ═══════════════════════════════════════════
    # Search cache
    # ═══════════════════════════════════════════

    def _search_key(self, query: str, limit: int, offset: int) -> str:
        h = _hash_key(query.lower().strip(), str(limit), str(offset))
        return f"mol:search:{h}"

    async def get_search(
        self, query: str, limit: int, offset: int
    ) -> Any | None:
        """Return cached MoleculeSearchResponse dict or None."""
        try:
            key = self._search_key(query, limit, offset)
            raw = await self._r.get(key)
            if raw is None:
                return None
            data = _deserialize(raw)
            if data is None:
                return None

            # Re-hydrate into schema
            from app.schemas.molecule import MoleculeSearchResponse

            return MoleculeSearchResponse(**data)
        except Exception as exc:
            logger.warning("cache_get_search_error", error=str(exc))
            return None

    async def set_search(
        self, query: str, limit: int, offset: int, response: Any
    ) -> None:
        """Cache a search response."""
        try:
            key = self._search_key(query, limit, offset)
            data = response.model_dump(mode="json") if hasattr(response, "model_dump") else response
            await self._r.set(key, _serialize(data), ex=_TTL_SEARCH)
            logger.debug("cache_set_search", key=key)
        except Exception as exc:
            logger.warning("cache_set_search_error", error=str(exc))

    # ═══════════════════════════════════════════
    # Detail cache
    # ═══════════════════════════════════════════

    def _detail_key(self, molecule_id: uuid.UUID) -> str:
        return f"mol:detail:{molecule_id}"

    async def get_detail(self, molecule_id: uuid.UUID) -> Any | None:
        """Return cached MoleculeDetailResponse dict or None."""
        try:
            raw = await self._r.get(self._detail_key(molecule_id))
            if raw is None:
                return None
            data = _deserialize(raw)
            if data is None:
                return None

            from app.schemas.molecule import MoleculeDetailResponse

            return MoleculeDetailResponse(**data)
        except Exception as exc:
            logger.warning("cache_get_detail_error", error=str(exc))
            return None

    async def set_detail(
        self, molecule_id: uuid.UUID, response: Any
    ) -> None:
        """Cache a molecule detail response."""
        try:
            key = self._detail_key(molecule_id)
            data = response.model_dump(mode="json") if hasattr(response, "model_dump") else response
            await self._r.set(key, _serialize(data), ex=_TTL_DETAIL)
            logger.debug("cache_set_detail", key=key)
        except Exception as exc:
            logger.warning("cache_set_detail_error", error=str(exc))

    # ═══════════════════════════════════════════
    # Structure cache (large blobs – longer TTL)
    # ═══════════════════════════════════════════

    def _structure_key(self, molecule_id: uuid.UUID, fmt: str) -> str:
        return f"mol:struct:{molecule_id}:{fmt}"

    async def get_structure(
        self, molecule_id: uuid.UUID, fmt: str
    ) -> str | None:
        """Return cached raw structure string (SDF, XYZ, etc.) or None."""
        try:
            raw = await self._r.get(self._structure_key(molecule_id, fmt))
            if raw is None:
                return None
            return raw if isinstance(raw, str) else raw.decode("utf-8")
        except Exception as exc:
            logger.warning("cache_get_structure_error", error=str(exc))
            return None

    async def set_structure(
        self, molecule_id: uuid.UUID, fmt: str, data: str
    ) -> None:
        """Cache a raw structure string."""
        try:
            key = self._structure_key(molecule_id, fmt)
            await self._r.set(key, data.encode("utf-8"), ex=_TTL_STRUCTURE)
            logger.debug("cache_set_structure", key=key, fmt=fmt)
        except Exception as exc:
            logger.warning("cache_set_structure_error", error=str(exc))


    # ═══════════════════════════════════════════
    # Calculation status cache (short TTL)
    # ═══════════════════════════════════════════

    def _calc_key(self, task_id: str) -> str:
        return f"mol:calc:{task_id}"

    async def get_calc_status(self, task_id: str) -> dict | None:
        """Return cached calculation status or None."""
        try:
            raw = await self._r.get(self._calc_key(task_id))
            return _deserialize(raw)
        except Exception as exc:
            logger.warning("cache_get_calc_error", error=str(exc))
            return None

    async def set_calc_status(
        self, task_id: str, status: dict, ttl: int | None = None
    ) -> None:
        """Cache a calculation status dict."""
        try:
            key = self._calc_key(task_id)
            await self._r.set(key, _serialize(status), ex=ttl or _TTL_CALC)
        except Exception as exc:
            logger.warning("cache_set_calc_error", error=str(exc))

    # ═══════════════════════════════════════════
    # Invalidation
    # ═══════════════════════════════════════════

    async def invalidate_molecule(self, molecule_id: uuid.UUID) -> int:
        """Purge all cached data for a specific molecule.

        Returns the number of keys deleted.
        """
        deleted = 0
        try:
            # Detail
            deleted += await self._r.delete(self._detail_key(molecule_id))

            # Structures (scan pattern)
            pattern = f"mol:struct:{molecule_id}:*"
            async for key in self._r.scan_iter(match=pattern, count=100):
                deleted += await self._r.delete(key)

            logger.info(
                "cache_invalidated_molecule",
                molecule_id=str(molecule_id),
                keys_deleted=deleted,
            )
        except Exception as exc:
            logger.warning("cache_invalidate_error", error=str(exc))
        return deleted

    async def invalidate_search(self, query: str | None = None) -> int:
        """Purge search caches. If query is None, purge ALL search caches."""
        deleted = 0
        try:
            if query:
                # Only invalidate caches matching this query (any limit/offset)
                h = _hash_key(query.lower().strip())
                # hash_key only uses first part so we can't reverse; purge by prefix
                pattern = f"mol:search:*"
            else:
                pattern = "mol:search:*"

            async for key in self._r.scan_iter(match=pattern, count=200):
                deleted += await self._r.delete(key)

            logger.info("cache_invalidated_search", keys_deleted=deleted)
        except Exception as exc:
            logger.warning("cache_invalidate_search_error", error=str(exc))
        return deleted

    async def flush_all(self) -> None:
        """Purge the entire mol: namespace. Use with caution."""
        try:
            count = 0
            async for key in self._r.scan_iter(match="mol:*", count=500):
                await self._r.delete(key)
                count += 1
            logger.warning("cache_flushed_all", keys_deleted=count)
        except Exception as exc:
            logger.warning("cache_flush_error", error=str(exc))

    # ═══════════════════════════════════════════
    # Health / Stats
    # ═══════════════════════════════════════════

    async def health(self) -> dict[str, Any]:
        """Return cache health info for the /health endpoint."""
        try:
            pong = await self._r.ping()
            info = await self._r.info(section="memory")
            key_count = 0
            async for _ in self._r.scan_iter(match="mol:*", count=500):
                key_count += 1

            return {
                "status": "healthy" if pong else "degraded",
                "used_memory_human": info.get("used_memory_human", "unknown"),
                "used_memory_peak_human": info.get("used_memory_peak_human", "unknown"),
                "mol_key_count": key_count,
            }
        except Exception as exc:
            return {"status": "unhealthy", "error": str(exc)}



    # ═══════════════════════════════════════════
    # Generic raw cache (for molecule card etc.)
    # ═══════════════════════════════════════════

    async def get_raw(self, key: str) -> dict | None:
        """Get a raw JSON dict from Redis."""
        try:
            import orjson
            data = await self._r.get(key)
            if data is not None:
                return orjson.loads(data)
        except Exception as e:
            pass
        return None

    async def set_raw(self, key: str, value: dict, ttl: int = 86400) -> None:
        """Store a raw JSON dict in Redis with TTL."""
        try:
            import orjson
            await self._r.set(key, orjson.dumps(value), ex=ttl)
        except Exception as e:
            import traceback; print(f'SET_RAW ERROR: {e} {traceback.format_exc()}')

```

### File: backend/app/services/molecule_engine/drug_likeness.py

```py

"""
Drug-likeness rule evaluators.
Pure Python - no external API calls, no dependencies beyond pydantic schemas.
"""

from __future__ import annotations

from app.schemas.molecule_card import DrugLikenessResult


def evaluate_lipinski(
    mw: float | None,
    logp: float | None,
    hbd: int | None,
    hba: int | None,
) -> DrugLikenessResult:
    """Lipinski Rule of Five. Pass = at most 1 violation."""
    violations: list[str] = []
    if mw is not None and mw > 500:
        violations.append(f"MW = {mw:.1f} > 500")
    if logp is not None and logp > 5:
        violations.append(f"logP = {logp:.2f} > 5")
    if hbd is not None and hbd > 5:
        violations.append(f"HBD = {hbd} > 5")
    if hba is not None and hba > 10:
        violations.append(f"HBA = {hba} > 10")
    passed = len(violations) <= 1
    return DrugLikenessResult(
        rule_name="Lipinski (Ro5)",
        passed=passed,
        violations=violations,
        details="Pass" if passed else f"{len(violations)} violations",
    )


def evaluate_veber(
    tpsa: float | None,
    rotatable_bonds: int | None,
) -> DrugLikenessResult:
    """Veber Rules for oral bioavailability."""
    violations: list[str] = []
    if tpsa is not None and tpsa > 140:
        violations.append(f"TPSA = {tpsa:.1f} > 140")
    if rotatable_bonds is not None and rotatable_bonds > 10:
        violations.append(f"RotBonds = {rotatable_bonds} > 10")
    passed = len(violations) == 0
    return DrugLikenessResult(
        rule_name="Veber",
        passed=passed,
        violations=violations,
        details="Pass" if passed else f"{len(violations)} violations",
    )


def evaluate_ghose(
    mw: float | None,
    logp: float | None,
    atom_count: int | None = None,
    molar_refractivity: float | None = None,
) -> DrugLikenessResult:
    """Ghose Filter."""
    violations: list[str] = []
    if mw is not None:
        if mw < 160:
            violations.append(f"MW = {mw:.1f} < 160")
        elif mw > 480:
            violations.append(f"MW = {mw:.1f} > 480")
    if logp is not None:
        if logp < -0.4:
            violations.append(f"logP = {logp:.2f} < -0.4")
        elif logp > 5.6:
            violations.append(f"logP = {logp:.2f} > 5.6")
    if atom_count is not None:
        if atom_count < 20:
            violations.append(f"Atoms = {atom_count} < 20")
        elif atom_count > 70:
            violations.append(f"Atoms = {atom_count} > 70")
    if molar_refractivity is not None:
        if molar_refractivity < 40:
            violations.append(f"MR = {molar_refractivity:.1f} < 40")
        elif molar_refractivity > 130:
            violations.append(f"MR = {molar_refractivity:.1f} > 130")
    passed = len(violations) == 0
    return DrugLikenessResult(
        rule_name="Ghose",
        passed=passed,
        violations=violations,
        details="Pass" if passed else f"{len(violations)} violations",
    )


def evaluate_all(
    mw: float | None = None,
    logp: float | None = None,
    hbd: int | None = None,
    hba: int | None = None,
    tpsa: float | None = None,
    rotatable_bonds: int | None = None,
    atom_count: int | None = None,
    molar_refractivity: float | None = None,
) -> list[DrugLikenessResult]:
    """Evaluate all drug-likeness rules at once."""
    return [
        evaluate_lipinski(mw, logp, hbd, hba),
        evaluate_veber(tpsa, rotatable_bonds),
        evaluate_ghose(mw, logp, atom_count, molar_refractivity),
    ]

```

### File: backend/app/services/molecule_engine/ghs_parser.py

```py

"""
GHS safety data fetcher and parser.
Retrieves GHS classification from PubChem PUG-View API.

PUG-View JSON structure (actual):
  Record.Section[0] ("Safety and Hazards")
    .Section[0] ("Hazards Identification")
      .Section[0] ("GHS Classification")
        .Information[] — flat list, each entry is one of:
          - Pictograms  (Markup Type="Icon", Extra="Irritant" etc.)
          - Signal word (Markup Type="Color", Extra="GHSDanger"/"GHSWarning")
          - H-statements (String starts with "H" + 3 digits)
          - P-statements (String starts with "P" + 3 digits, comma-separated)
          - Meta text    (italics, source info — skip)
        Multiple notification sources repeat the same pattern.
"""

from __future__ import annotations

import re
import structlog
import httpx

from app.schemas.molecule_card import GHSSafety

logger = structlog.get_logger(__name__)

_PICTOGRAM_BASE = "https://pubchem.ncbi.nlm.nih.gov/images/ghs"

PICTOGRAM_MAP: dict[str, str] = {
    "Flammable":            "GHS02",
    "Oxidizer":             "GHS03",
    "Compressed Gas":       "GHS04",
    "Corrosive":            "GHS05",
    "Acute Toxic":          "GHS06",
    "Irritant":             "GHS07",
    "Health Hazard":        "GHS08",
    "Environmental Hazard": "GHS09",
    "Explosive":            "GHS01",
}

_H_PATTERN = re.compile(r"^H\d{3}")
_P_PATTERN = re.compile(r"^P\d{3}")


async def fetch_ghs(cid: int, client: httpx.AsyncClient | None = None) -> GHSSafety | None:
    """Fetch GHS classification for a compound from PubChem PUG-View."""
    url = (
        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug_view/data/compound/{cid}/JSON"
        f"?heading=GHS+Classification"
    )
    own_client = client is None
    if own_client:
        client = httpx.AsyncClient(timeout=8.0)
    try:
        resp = await client.get(url, timeout=8.0)
        if resp.status_code != 200:
            logger.warning("ghs_fetch_failed", cid=cid, status=resp.status_code)
            return None
        data = resp.json()
        return _parse_ghs_response(data, cid)
    except httpx.TimeoutException:
        logger.warning("ghs_fetch_timeout", cid=cid)
        return None
    except Exception as e:
        logger.warning("ghs_fetch_error", cid=cid, error=str(e))
        return None
    finally:
        if own_client:
            await client.aclose()


def _parse_ghs_response(data: dict, cid: int) -> GHSSafety:
    """Parse PUG-View GHS JSON into a GHSSafety object.

    Strategy: walk ALL Information[] entries under GHS Classification
    and classify each by inspecting its Markup and String content.
    """
    pictograms: set[str] = set()
    pictogram_urls: set[str] = set()
    h_statements: list[str] = []
    p_statements: list[str] = []
    signal_word: str | None = None

    try:
        # Navigate: Record > Section[*] > Section[*] > Section[*]
        # until we find TOCHeading == "GHS Classification"
        ghs_section = _find_ghs_section(data.get("Record", {}))
        if ghs_section is None:
            logger.info("ghs_section_not_found", cid=cid)
            return GHSSafety()

        for info in ghs_section.get("Information", []):
            value = info.get("Value", {})
            for swm in value.get("StringWithMarkup", []):
                text = swm.get("String", "").strip()
                markups = swm.get("Markup", [])

                # ── Pictograms: Markup Type="Icon" ──
                for m in markups:
                    if m.get("Type") == "Icon":
                        extra = m.get("Extra", "")
                        url = m.get("URL", "")
                        if extra in PICTOGRAM_MAP:
                            code = PICTOGRAM_MAP[extra]
                            pictograms.add(code)
                            pictogram_urls.add(
                                url if url else f"{_PICTOGRAM_BASE}/{code}.svg"
                            )

                # ── Signal word: short text "Danger" or "Warning" ──
                if text.lower() in ("danger", "warning") and signal_word is None:
                    signal_word = text.capitalize()
                    continue

                # Also detect via Markup Extra
                if signal_word is None:
                    for m in markups:
                        extra = m.get("Extra", "")
                        if extra == "GHSDanger":
                            signal_word = "Danger"
                        elif extra == "GHSWarning":
                            signal_word = "Warning"

                # ── H-statements: "H302: Harmful if swallowed ..." ──
                if _H_PATTERN.match(text):
                    # Truncate the [Warning ...] or [Danger ...] classification suffix
                    clean = _clean_statement(text)
                    if clean and clean not in h_statements:
                        h_statements.append(clean)

                # ── P-statements: comma-separated "P261, P264, ..." ──
                elif _P_PATTERN.match(text):
                    if text not in p_statements:
                        p_statements.append(text)

    except Exception as e:
        logger.warning("ghs_parse_error", cid=cid, error=str(e))

    return GHSSafety(
        signal_word=signal_word,
        pictograms=sorted(pictograms),
        pictogram_urls=sorted(pictogram_urls),
        h_statements=h_statements[:20],
        p_statements=p_statements[:10],
    )


def _find_ghs_section(record: dict) -> dict | None:
    """Recursively find the section with TOCHeading 'GHS Classification'."""
    for section in record.get("Section", []):
        if section.get("TOCHeading") == "GHS Classification":
            return section
        # Recurse into subsections
        result = _find_ghs_section(section)
        if result is not None:
            return result
    return None


def _clean_statement(text: str) -> str:
    """Remove trailing classification bracket from H-statements.

    Example: 'H302: Harmful if swallowed [Warning Acute toxicity, oral]'
          -> 'H302: Harmful if swallowed'
    """
    bracket = text.find(" [")
    if bracket > 0:
        return text[:bracket].strip()
    return text.strip()

```

### File: backend/app/services/molecule_engine/orchestrator.py

```py

"""
MoleculeOrchestrator – single facade that coordinates all three layers.

Responsibilities:
  1. Accept a free-form query (name / SMILES / InChIKey / CID / formula).
  2. Check cache → L0 search → persist to DB → L1 structure → optional L2 calc.
  3. Return a fully-hydrated ``MoleculeRecord``.

Design decisions:
  • Every public method is async and re-entrant (no mutable instance state).
  • Errors bubble up as domain exceptions (``MolChatError`` subclasses).
  • Structured logging on every significant step for observability.
  • Timeouts are enforced per-layer so a slow upstream never blocks the pipeline.
"""

from __future__ import annotations
import httpx

import asyncio
import time
import uuid
from typing import Any

import structlog
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.middleware.error_handler import (
    CalculationError,
    ExternalServiceError,
    MoleculeNotFoundError,
)
from app.models.molecule import Molecule, MoleculeProperty, MoleculeStructure
from app.schemas.molecule import (
    MoleculeDetailResponse,
    MoleculeRecord,
    MoleculeSearchResponse,
)
from app.services.molecule_engine.cache_manager import MoleculeCacheManager
from app.services.molecule_engine.query_resolver import QueryResolver
from app.services.molecule_engine.pug_rest_resolver import resolve_name_to_cid, PugRestResult
from app.services.molecule_engine.layer0_search.aggregator import SearchAggregator
from app.services.molecule_engine.layer1_structure.rdkit_handler import RDKitHandler
from app.services.molecule_engine.layer1_structure.conforge_handler import ConforgeHandler
from app.services.molecule_engine.layer1_structure.converter import FormatConverter
from app.services.molecule_engine.layer1_structure.validator import StructureValidator
from app.services.molecule_engine.layer2_calculation.property_calc import PropertyCalculator
from app.services.molecule_engine.layer2_calculation.xtb_runner import XTBRunner
from app.services.molecule_engine.layer2_calculation.task_queue import CalculationQueue

logger = structlog.get_logger(__name__)


class MoleculeOrchestrator:
    """Top-level facade for the Molecule Engine.

    Instantiated once at app startup and shared across requests
    via FastAPI's dependency injection.
    """

    def __init__(
        self,
        db: AsyncSession,
        cache: MoleculeCacheManager,
        search_aggregator: SearchAggregator | None = None,
        rdkit_handler: RDKitHandler | None = None,
        converter: FormatConverter | None = None,
        validator: StructureValidator | None = None,
        property_calc: PropertyCalculator | None = None,
        xtb_runner: XTBRunner | None = None,
        calc_queue: CalculationQueue | None = None,
    ) -> None:
        self._db = db
        self._cache = cache
        self._resolver = QueryResolver()
        self._search = search_aggregator or SearchAggregator()
        self._conforge = ConforgeHandler()
        self._rdkit = rdkit_handler or RDKitHandler()
        self._converter = converter or FormatConverter()
        self._validator = validator or StructureValidator()
        self._property_calc = property_calc or PropertyCalculator()
        self._xtb = xtb_runner or XTBRunner()
        self._calc_queue = calc_queue or CalculationQueue()

    # ═══════════════════════════════════════════
    # Public API
    # ═══════════════════════════════════════════

    async def search(
        self,
        query: str,
        *,
        limit: int = 10,
        offset: int = 0,
        sources: list[str] | None = None,
    ) -> MoleculeSearchResponse:
        """Full search pipeline: cache → L0 → persist → L1 enrich."""
        t0 = time.perf_counter()
        # ── 0. Query Resolution (Korean, typos, aliases) ──
        resolved = await self._resolver.resolve(query)
        if resolved.method != "passthrough":
            log = logger.bind(
                original_query=query,
                resolved_query=resolved.resolved_query,
                resolve_method=resolved.method,
                limit=limit,
                sources=sources,
            )
            log.info("query_resolved", suggestions=resolved.suggestions[:3])
            query = resolved.resolved_query  # Use resolved query for search
        else:
            log = logger.bind(query=query, limit=limit, sources=sources)

        log.info("search_started")

        # ── 1. Cache lookup ──
        cached = await self._cache.get_search(query, limit, offset)
        if cached is not None:
            elapsed = (time.perf_counter() - t0) * 1000
            log.info("search_cache_hit", elapsed_ms=elapsed)
            cached.cache_hit = True
            cached.elapsed_ms = elapsed
            # Restore resolve info for this specific request
            if resolved.method != "passthrough":
                cached.original_query = resolved.original
                cached.resolved_query = resolved.resolved_query
                cached.resolve_method = resolved.method
                cached.resolve_suggestions = resolved.suggestions
            else:
                cached.original_query = None
                cached.resolved_query = None
                cached.resolve_method = None
                cached.resolve_suggestions = []
            return cached

        # ── 2. L0 – Multi-source search ──
        try:
            raw_results = await asyncio.wait_for(
                self._search.search(query, limit=limit, sources=sources),
                timeout=30.0,
            )
        except asyncio.TimeoutError:
            raise ExternalServiceError("search_aggregator", "Search timed out after 30 s")

        if not raw_results.results:
            raise MoleculeNotFoundError(query)

        # ── 3. Persist to DB & enrich with L1 ──
        records: list[MoleculeRecord] = []
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        for raw in raw_results.results:
            # Persist to DB and get the actual DB ID
            db_id = None
            try:
                persisted = await self._persist_molecule(raw)
                db_id = persisted.id
            except Exception as persist_err:
                logger.warning("persist_skip", error=str(persist_err))

            # Build response record with DB ID (enables detail page navigation)
            props = raw.get("properties") or {}
            mw = props.get("molecular_weight") or raw.get("molecular_weight")
            if mw is not None:
                try:
                    mw = float(mw)
                except (ValueError, TypeError):
                    mw = None
            records.append(MoleculeRecord(
                id=db_id or uuid.uuid4(),
                cid=raw.get("cid"),
                name=raw.get("name") or "",
                canonical_smiles=raw.get("canonical_smiles") or "",
                inchi=raw.get("inchi"),
                inchikey=raw.get("inchikey"),
                molecular_formula=raw.get("molecular_formula"),
                molecular_weight=mw,
                properties=props,
                structures=[],
                computed_properties=[],
                created_at=now,
                updated_at=now,
            ))

        # ── 4. Build response ──
        response = MoleculeSearchResponse(
            query=resolved.resolved_query if resolved.method != "passthrough" else query,
            original_query=resolved.original if resolved.method != "passthrough" else None,
            resolved_query=resolved.resolved_query if resolved.method != "passthrough" else None,
            resolve_method=resolved.method if resolved.method != "passthrough" else None,
            resolve_suggestions=resolved.suggestions if resolved.method != "passthrough" else [],
            total=raw_results.total,
            limit=limit,
            offset=offset,
            results=records,
            sources_queried=raw_results.sources_queried,
            cache_hit=False,
            elapsed_ms=0,
        )

        # ── 5. Cache write ──
        await self._cache.set_search(query, limit, offset, response)

        elapsed = (time.perf_counter() - t0) * 1000
        response.elapsed_ms = elapsed
        log.info("search_completed", total=len(records), elapsed_ms=elapsed)
        return response

    async def get_detail(
        self,
        molecule_id: uuid.UUID,
        *,
        include_calculation: bool = False,
    ) -> MoleculeDetailResponse:
        """Return full detail for a molecule by ID, optionally triggering L2 calc."""
        log = logger.bind(molecule_id=str(molecule_id))
        log.info("detail_requested")

        # ── Cache ──
        cached = await self._cache.get_detail(molecule_id)
        if cached is not None:
            log.info("detail_cache_hit")
            return cached

        # ── DB lookup with eager loading (prevents greenlet issues) ──
        stmt = (
            select(Molecule)
            .where(
                Molecule.id == molecule_id,
                Molecule.is_deleted.is_(False),
            )
            .options(
                selectinload(Molecule.structures),
                selectinload(Molecule.computed_properties),
            )
        )
        result = await self._db.execute(stmt)
        molecule = result.scalar_one_or_none()

        if molecule is None:
            raise MoleculeNotFoundError(str(molecule_id))

        # ── L1 enrichment (auto-generate 3D structure if missing) ──
        record = await self._enrich_l1(molecule)

        # ── L2 calculation (async / queue) ──
        calc_status: str | None = None
        if include_calculation:
            calc_status = await self._trigger_l2(molecule)

        # ── Available formats (re-query DB after enrichment) ──
        from sqlalchemy import select as sa_select
        fmt_stmt = sa_select(MoleculeStructure.format).where(
            MoleculeStructure.molecule_id == molecule_id
        )
        fmt_result = await self._db.execute(fmt_stmt)
        formats = [row[0] for row in fmt_result.fetchall()]

        detail = MoleculeDetailResponse(
            molecule=record,
            available_formats=sorted(set(formats)),
            calculation_status=calc_status,
        )

        await self._cache.set_detail(molecule_id, detail)
        log.info("detail_completed")
        return detail

    async def calculate(
        self,
        molecule_id: uuid.UUID,
        *,
        method: str = "gfn2",
        tasks: list[str] | None = None,
    ) -> dict[str, Any]:
        """Submit an L2 quantum calculation and return the task handle."""
        log = logger.bind(molecule_id=str(molecule_id), method=method)
        log.info("calculation_requested")

        stmt = select(Molecule).where(
            Molecule.id == molecule_id,
            Molecule.is_deleted.is_(False),
        )
        result = await self._db.execute(stmt)
        molecule = result.scalar_one_or_none()

        if molecule is None:
            raise MoleculeNotFoundError(str(molecule_id))

        # Validate atom count
        atom_count = await self._rdkit.count_atoms(molecule.canonical_smiles)
        if atom_count > settings.XTB_MAX_ATOMS:
            raise CalculationError(
                f"Molecule has {atom_count} atoms (max {settings.XTB_MAX_ATOMS})"
            )

        tasks = tasks or ["optimize", "energy", "frequencies"]
        task_id = await self._calc_queue.submit(
            molecule_id=molecule_id,
            smiles=molecule.canonical_smiles,
            method=method,
            tasks=tasks,
        )

        log.info("calculation_submitted", task_id=task_id)
        return {
            "task_id": task_id,
            "molecule_id": str(molecule_id),
            "method": method,
            "tasks": tasks,
            "status": "pending",
        }

    async def get_calculation_status(self, task_id: str) -> dict[str, Any]:
        """Poll the status of a queued L2 calculation."""
        return await self._calc_queue.get_status(task_id)

    # ═══════════════════════════════════════════
    # Internal helpers
    # ═══════════════════════════════════════════

    async def _persist_molecule(self, raw: dict[str, Any]) -> Molecule:
        """Insert or update a molecule row from raw search data.

        Uses InChIKey as the natural dedup key, falling back to CID.
        """
        inchikey = raw.get("inchikey")
        cid = raw.get("cid")

        existing: Molecule | None = None

        if inchikey:
            stmt = select(Molecule).where(Molecule.inchikey == inchikey)
            result = await self._db.execute(stmt)
            existing = result.scalar_one_or_none()

        if existing is None and cid:
            stmt = select(Molecule).where(Molecule.cid == cid)
            result = await self._db.execute(stmt)
            existing = result.scalar_one_or_none()

        if existing is not None:
            # Merge any new properties
            if raw.get("properties"):
                merged = {**(existing.properties or {}), **raw["properties"]}
                existing.properties = merged
            # Save PubChem 3D SDF if not already stored
            structure_3d = raw.get("structure_3d")
            if structure_3d and isinstance(structure_3d, str) and len(structure_3d) > 10:
                from app.models.molecule import MoleculeStructure
                check_stmt = select(MoleculeStructure).where(
                    MoleculeStructure.molecule_id == existing.id,
                    MoleculeStructure.generation_method == "pubchem-3d",
                )
                check_result = await self._db.execute(check_stmt)
                if check_result.scalar_one_or_none() is None:
                    # Demote any existing primary SDF before inserting new primary
                    from sqlalchemy import update as sa_update
                    demote_stmt = (
                        sa_update(MoleculeStructure)
                        .where(
                            MoleculeStructure.molecule_id == existing.id,
                            MoleculeStructure.format == "sdf",
                            MoleculeStructure.is_primary == True,
                        )
                        .values(is_primary=False)
                    )
                    await self._db.execute(demote_stmt)
                    pubchem_struct = MoleculeStructure(
                        molecule_id=existing.id,
                        format="sdf",
                        structure_data=structure_3d,
                        generation_method="pubchem-3d",
                        is_primary=True,
                    )
                    self._db.add(pubchem_struct)
                    logger.info("pubchem_3d_saved_existing", molecule_id=str(existing.id))
            await self._db.flush()
            await self._db.refresh(existing)
            return existing

        # Ensure numeric types
        mw = raw.get("molecular_weight")
        try:
            mw = float(mw) if mw is not None else None
        except (ValueError, TypeError):
            mw = None

        raw_cid = raw.get("cid")
        try:
            raw_cid = int(raw_cid) if raw_cid is not None else None
        except (ValueError, TypeError):
            raw_cid = None

        molecule = Molecule(
            id=uuid.uuid4(),
            cid=raw_cid,
            name=raw.get("name", "Unknown"),
            canonical_smiles=raw.get("canonical_smiles", ""),
            inchi=raw.get("inchi"),
            inchikey=inchikey,
            molecular_formula=raw.get("molecular_formula"),
            molecular_weight=mw,
            properties=raw.get("properties", {}),
        )
        mol_name = raw.get("name", "Unknown")


        mol_id = molecule.id
        self._db.add(molecule)
        await self._db.flush()

        # Save PubChem 3D SDF if available in search result
        structure_3d = raw.get("structure_3d")
        if structure_3d and isinstance(structure_3d, str) and len(structure_3d) > 10:
            from app.models.molecule import MoleculeStructure
            pubchem_struct = MoleculeStructure(
                molecule_id=molecule.id,
                format="sdf",
                structure_data=structure_3d,
                generation_method="pubchem-3d",
                is_primary=True,
            )
            self._db.add(pubchem_struct)
            await self._db.flush()
            logger.info("pubchem_3d_saved", molecule_id=str(mol_id))

        logger.info(
            "molecule_persisted",
            molecule_id=str(mol_id),
            name=mol_name,
        )
        return molecule

    async def _enrich_l1(self, molecule: Molecule) -> MoleculeRecord:
        """4-stage structure generation pipeline:

        Stage 1: PubChem 3D (already saved during search, skip if exists)
        Stage 2: CONFORGE (CDPKit) — best open-source conformer quality
        Stage 3: RDKit ETKDGv3 + MMFF94 — fast fallback
        Stage 4: xTB GFN2-xTB optimization (optional, on existing structure)
        """
        try:
            has_any_sdf = any(
                s.format == "sdf" for s in (molecule.structures or [])
            )

            # ── Stage 1: PubChem 3D (already present from search) ──
            has_pubchem = any(
                s.generation_method == "pubchem-3d" for s in (molecule.structures or [])
            )

            # ── Stage 2: CONFORGE (CDPKit) ──
            has_conforge = any(
                s.generation_method == "conforge" for s in (molecule.structures or [])
            )
            if not has_conforge and molecule.canonical_smiles:
                sdf_data = await self._conforge.smiles_to_sdf(molecule.canonical_smiles)
                if sdf_data and len(sdf_data) > 10:
                    structure = MoleculeStructure(
                        molecule_id=molecule.id,
                        format="sdf",
                        structure_data=sdf_data,
                        generation_method="conforge",
                        is_primary=False,  # Never auto-promote; PubChem 3D or first-inserted is primary
                    )
                    self._db.add(structure)
                    has_conforge = True
                    has_any_sdf = True
                    logger.info("conforge_structure_saved", molecule_id=str(molecule.id))

            # ── Stage 3: RDKit ETKDGv3 + MMFF94 (fallback) ──
            has_rdkit = any(
                s.generation_method == "rdkit" for s in (molecule.structures or [])
            )
            if not has_rdkit and not has_conforge and molecule.canonical_smiles:
                sdf_data = await self._rdkit.smiles_to_sdf(molecule.canonical_smiles)
                if sdf_data:
                    structure = MoleculeStructure(
                        molecule_id=molecule.id,
                        format="sdf",
                        structure_data=sdf_data,
                        generation_method="rdkit",
                        is_primary=False,
                    )
                    self._db.add(structure)
                    has_any_sdf = True
                    logger.info("rdkit_structure_saved", molecule_id=str(molecule.id))

            # ── Stage 4: xTB GFN2-xTB optimization (best available SDF → XYZ → optimize) ──
            has_xtb = any(
                s.generation_method == "xtb-gfn2" for s in (molecule.structures or [])
            )
            if not has_xtb and has_any_sdf and molecule.canonical_smiles:
                await self._run_xtb_optimization(molecule)

            # ── RDKit descriptors ──
            has_rdkit_props = any(
                p.source == "rdkit" for p in (molecule.computed_properties or [])
            )
            if not has_rdkit_props and molecule.canonical_smiles:
                descriptors = await self._property_calc.rdkit_descriptors(
                    molecule.canonical_smiles
                )
                if descriptors:
                    prop = MoleculeProperty(
                        molecule_id=molecule.id,
                        source="rdkit",
                        data=descriptors,
                    )
                    self._db.add(prop)

            await self._db.flush()

            # Ensure exactly one primary SDF exists
            await self._db.refresh(molecule, attribute_names=["structures"])
            sdf_structs = [s for s in (molecule.structures or []) if s.format == "sdf"]
            has_primary = any(s.is_primary for s in sdf_structs)
            if not has_primary and sdf_structs:
                # Priority: pubchem-3d > conforge > rdkit > xtb-gfn2
                priority_order = ["pubchem-3d", "conforge", "rdkit", "xtb-gfn2"]
                best = None
                for method in priority_order:
                    for s in sdf_structs:
                        if s.generation_method == method:
                            best = s
                            break
                    if best:
                        break
                if best is None:
                    best = sdf_structs[0]
                best.is_primary = True
                await self._db.flush()
                logger.info("primary_promoted", molecule_id=str(molecule.id), method=best.generation_method)

        except Exception as exc:
            try:
                await self._db.rollback()
            except Exception:
                pass
            logger.warning(
                "l1_enrichment_partial_failure",
                molecule_id=str(molecule.id),
                error=str(exc),
            )

        # Build record
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        try:
            created = molecule.created_at
        except Exception:
            created = now
        try:
            updated = molecule.updated_at
        except Exception:
            updated = now
        return MoleculeRecord(
            id=molecule.id,
            cid=molecule.cid,
            name=molecule.name,
            canonical_smiles=molecule.canonical_smiles or "",
            inchi=molecule.inchi,
            inchikey=molecule.inchikey,
            molecular_formula=molecule.molecular_formula,
            molecular_weight=molecule.molecular_weight,
            properties=molecule.properties,
            structures=[],
            computed_properties=[],
            created_at=created,
            updated_at=updated,
        )

    async def _run_xtb_optimization(self, molecule: Molecule) -> None:
        """Stage 4: Run xTB GFN2-xTB geometry optimization on best available structure."""
        try:
            # Find best SDF (prefer pubchem-3d > conforge > rdkit)
            best_sdf = None
            for method in ["pubchem-3d", "conforge", "rdkit"]:
                for s in (molecule.structures or []):
                    if s.format == "sdf" and s.generation_method == method:
                        best_sdf = s.structure_data
                        break
                if best_sdf:
                    break

            if not best_sdf:
                return

            # Count atoms (check limit: <=150 for xTB to keep under 30s)
            atom_count = self._rdkit._count_atoms_sync(molecule.canonical_smiles) if molecule.canonical_smiles else 0
            if atom_count > 150:
                logger.info("xtb_skip_too_large", atoms=atom_count, molecule_id=str(molecule.id))
                return

            # Convert SDF → XYZ via converter
            xyz_data = await self._converter.convert(best_sdf, "sdf", "xyz")
            if not xyz_data:
                return

            # Run xTB optimization
            if self._xtb_runner is None:
                return

            result = await self._xtb_runner.run(
                xyz_data,
                tasks=["optimize"],
                charge=0,
                multiplicity=1,
            )

            if result.success and result.optimized_xyz:
                # Convert optimized XYZ back to SDF for storage
                opt_sdf = await self._converter.convert(result.optimized_xyz, "xyz", "sdf")
                if opt_sdf and len(opt_sdf) > 10:
                    structure = MoleculeStructure(
                        molecule_id=molecule.id,
                        format="sdf",
                        structure_data=opt_sdf,
                        generation_method="xtb-gfn2",
                        is_primary=False,  # Not primary, just an option
                    )
                    self._db.add(structure)
                    logger.info("xtb_structure_saved",
                              molecule_id=str(molecule.id),
                              energy=result.total_energy,
                              elapsed=result.elapsed_seconds)
            else:
                logger.debug("xtb_optimization_failed",
                           molecule_id=str(molecule.id),
                           error=getattr(result, 'error_message', 'unknown'))

        except Exception as exc:
            logger.debug("xtb_stage_error", molecule_id=str(molecule.id), error=str(exc))

    async def _trigger_l2(self, molecule: Molecule) -> str:
        """Enqueue an L2 xTB calculation if not already done/running."""
        # Check if we already have xTB results
        has_xtb = any(
            p.source == "xtb" for p in (molecule.computed_properties or [])
        )
        if has_xtb:
            return "completed"

        # Check atom count limit
        try:
            atom_count = await self._rdkit.count_atoms(molecule.canonical_smiles)
            if atom_count > settings.XTB_MAX_ATOMS:
                return "skipped_too_large"
        except Exception:
            return "skipped_invalid_smiles"

        await self._calc_queue.submit(
            molecule_id=molecule.id,
            smiles=molecule.canonical_smiles,
            method=settings.XTB_METHOD,
            tasks=["optimize", "energy"],
        )
        return "pending"
    # ═══════════════════════════════════════════
    # Molecule Card — comprehensive single-molecule view
    # ═══════════════════════════════════════════

    async def get_card(
        self,
        *,
        q: str | None = None,
        cid: int | None = None,
    ) -> "MoleculeCardResponse":
        """Build a comprehensive molecule card in <3 seconds.

        Pipeline:
          Layer A (required): search → core properties (<1s)
          Layer B (parallel):  GHS safety + similar molecules (<2s)
          Layer C (parallel):  AI summary (<1.5s)
          Local calc:          drug-likeness (instant)
        """
        import asyncio
        import time
        from app.schemas.molecule_card import (
            MoleculeCardResponse,
            GHSSafety,
            SimilarMolecule,
        )
        from app.services.molecule_engine.drug_likeness import (
            evaluate_lipinski,
            evaluate_veber,
            evaluate_ghose,
        )
        from app.services.molecule_engine.ghs_parser import fetch_ghs
        # [REMOVED] Old query_validator — replaced by pug_rest_resolver

        t0 = time.perf_counter()

        # --- CID-pattern safety net (patch_cid_bug) ---
        import re as _re_cid
        if q:
            _cid_m = _re_cid.match(r'^CID[:\s:\-]*?(\d+)$', q.strip(), _re_cid.IGNORECASE)
            if _cid_m:
                logger.info('cid_pattern_redirect', original_q=q, extracted_cid=int(_cid_m.group(1)))
                cid = int(_cid_m.group(1))
                q = None
        # --- end CID-pattern safety net ---

        log = logger.bind(card_query=q or str(cid))

        # ── Cache check: Redis (hot) → DB (permanent) ──
        cache_key = f"molcard:cid:{cid}" if cid else f"molcard:name:{q.lower().strip()}"
        cached = await self._cache.get_raw(cache_key)
        if cached is not None:
            log.info("card_cache_hit", source="redis")
            cached["cached"] = True
            return MoleculeCardResponse(**cached)

        # DB permanent cache fallback
        try:
            from app.core.database import async_session_factory
            from app.models.molecule_card import MoleculeCardCache
            from sqlalchemy import select
            async with async_session_factory() as db_session:
                if cid:
                    stmt = select(MoleculeCardCache).where(MoleculeCardCache.cid == cid)
                else:
                    stmt = select(MoleculeCardCache).where(
                        MoleculeCardCache.name.ilike(q.strip())
                    )
                row = (await db_session.execute(stmt)).scalar_one_or_none()
                if row is not None:
                    card_data = row.card_json
                    card_data["cached"] = True
                    # Re-warm Redis
                    try:
                        await self._cache.set_raw(cache_key, card_data, ttl=86400)
                        if row.cid:
                            await self._cache.set_raw(f"molcard:cid:{row.cid}", card_data, ttl=86400)
                    except Exception:
                        pass
                    log.info("card_cache_hit", source="db")
                    return MoleculeCardResponse(**card_data)
        except Exception as _db_err:
            log.warning("card_db_cache_read_failed", error=str(_db_err))

        # ── Layer A: resolve molecule ──
        mol = None

        # ── PUG REST: Direct name→CID exact match (NEW — replaces Autocomplete validator) ──
        if q and not cid:
            pug_result = await resolve_name_to_cid(q)
            if pug_result.found and pug_result.cid:
                # PUG REST found an exact match — use it as CID for the rest of the pipeline
                cid = pug_result.cid
                log.info("pug_rest_direct_hit", query=q, cid=cid,
                         name=pug_result.name, elapsed_ms=round(pug_result.elapsed_ms, 1))
            else:
                # PUG REST says this name doesn't exist in PubChem
                # This is a clean rejection — no fuzzy matching involved
                log.info("pug_rest_not_found", query=q, error=pug_result.error,
                         elapsed_ms=round(pug_result.elapsed_ms, 1))
                raise MoleculeNotFoundError(
                    f"'{q}' is not a recognized chemical compound in PubChem"
                )


        # CID가 직접 주어진 경우: PubChem REST로 직접 조회
        if cid and not q:
            try:
                async with httpx.AsyncClient(timeout=5.0) as _client:
                    prop_url = (
                        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}"
                        f"/property/IUPACName,MolecularFormula,MolecularWeight,"
                        f"CanonicalSMILES,InChI,InChIKey,XLogP,TPSA,"
                        f"HBondDonorCount,HBondAcceptorCount,RotatableBondCount,"
                        f"HeavyAtomCount,Complexity,ExactMass,Charge/JSON"
                    )
                    resp = await _client.get(prop_url)
                    if resp.status_code == 200:
                        p = resp.json().get("PropertyTable", {}).get("Properties", [{}])[0]

                        # Fetch synonyms
                        syn_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/synonyms/JSON"
                        syn_resp = await _client.get(syn_url, timeout=3.0)
                        synonyms = []
                        common_name = p.get("IUPACName", f"CID-{cid}")
                        if syn_resp.status_code == 200:
                            syn_data = syn_resp.json()
                            syn_list = (syn_data.get("InformationList", {})
                                        .get("Information", [{}])[0]
                                        .get("Synonym", []))
                            synonyms = syn_list[:10]
                            if syn_list:
                                common_name = syn_list[0]

                        import uuid as _uuid
                        from app.schemas.molecule import MoleculeRecord
                        from datetime import datetime, timezone
                        mol = MoleculeRecord(
                            id=_uuid.uuid4(),
                            cid=cid,
                            name=common_name,
                            canonical_smiles=p.get("CanonicalSMILES", ""),
                            inchi=p.get("InChI"),
                            inchikey=p.get("InChIKey"),
                            molecular_formula=p.get("MolecularFormula"),
                            molecular_weight=p.get("MolecularWeight"),
                            properties={
                                "iupac_name": p.get("IUPACName"),
                                "xlogp": p.get("XLogP"),
                                "tpsa": p.get("TPSA"),
                                "hbond_donor": p.get("HBondDonorCount"),
                                "hbond_acceptor": p.get("HBondAcceptorCount"),
                                "rotatable_bonds": p.get("RotatableBondCount"),
                                "heavy_atom_count": p.get("HeavyAtomCount"),
                                "complexity": p.get("Complexity"),
                                "exact_mass": str(p.get("ExactMass", "")),
                                "charge": p.get("Charge"),
                                "synonyms": synonyms,
                                "_source": "pubchem",
                                "_source_id": str(cid),
                                "_source_url": f"https://pubchem.ncbi.nlm.nih.gov/compound/{cid}",
                                "_confidence": 1.0,
                            },
                            structures=[],
                            computed_properties=[],
                            created_at=datetime.now(timezone.utc),
                            updated_at=datetime.now(timezone.utc),
                        )
            except Exception as e:
                log.warning("card_cid_direct_failed", cid=cid, error=str(e))

        # 이름/SMILES 검색 또는 CID 직접 조회 실패 시 fallback
        if mol is None:
            search_q = q if q else str(cid)
            search_result = await self.search(search_q, limit=1, sources=["pubchem"])
            if not search_result.results:
                search_result = await self.search(search_q, limit=1)
            if not search_result.results:
                raise MoleculeNotFoundError(search_q)
            mol = search_result.results[0]

        # ── Query Validation: now handled upstream by PUG REST exact match ──
        # The old Autocomplete+JW+Synonym 3-stage validator has been removed.
        # PUG REST name search (in pug_rest_resolver.py) does exact matching,
        # so no post-hoc validation is needed.

        mol_cid = mol.cid
        props = mol.properties or {}

        # ── Layer B + C: parallel enrichment ──



        async def _safe_fetch_ghs() -> GHSSafety | None:
            if not mol_cid:
                return None
            try:
                return await fetch_ghs(mol_cid)
            except Exception:
                return None

        async def _safe_fetch_similar() -> list[SimilarMolecule]:
            if not mol_cid:
                return []
            try:
                return await self._fetch_similar_molecules(mol_cid)
            except Exception:
                return []

        async def _safe_generate_summary() -> str | None:
            try:
                return await self._generate_card_summary(mol)
            except Exception:
                return None

        ghs_result, similar_result, ai_summary = await asyncio.gather(
            _safe_fetch_ghs(),
            _safe_fetch_similar(),
            _safe_generate_summary(),
        )

        # ── Drug-likeness (local, instant) ──
        drug_likeness = [
            evaluate_lipinski(
                mol.molecular_weight,
                props.get("xlogp"),
                props.get("hbond_donor"),
                props.get("hbond_acceptor"),
            ),
            evaluate_veber(
                props.get("tpsa"),
                props.get("rotatable_bonds"),
            ),
            evaluate_ghose(
                mol.molecular_weight,
                props.get("xlogp"),
            ),
        ]

        # ── Assemble response ──
        elapsed = (time.perf_counter() - t0) * 1000

        image_url = ""
        if mol_cid:
            image_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{mol_cid}/PNG"

        card = MoleculeCardResponse(
            id=mol.id,
            cid=mol_cid,
            name=mol.name,
            iupac_name=props.get("iupac_name"),
            synonyms=(props.get("synonyms") or [])[:10],
            canonical_smiles=mol.canonical_smiles,
            inchi=mol.inchi,
            inchikey=mol.inchikey,
            image_url=image_url,
            molecular_formula=mol.molecular_formula,
            molecular_weight=mol.molecular_weight,
            xlogp=props.get("xlogp"),
            tpsa=props.get("tpsa"),
            hbond_donor=props.get("hbond_donor"),
            hbond_acceptor=props.get("hbond_acceptor"),
            rotatable_bonds=props.get("rotatable_bonds"),
            heavy_atom_count=props.get("heavy_atom_count"),
            complexity=props.get("complexity"),
            exact_mass=props.get("exact_mass"),
            charge=props.get("charge"),
            drug_likeness=drug_likeness,
            ghs_safety=ghs_result,
            similar_molecules=similar_result or [],
            ai_summary=ai_summary,
            source=props.get("_source", "pubchem"),
            source_url=props.get("_source_url"),
            elapsed_ms=elapsed,
            cached=False,
        )

        # ── Cache (24h TTL) ──
        try:
            card_dict = card.model_dump(mode="json")
            await self._cache.set_raw(cache_key, card_dict, ttl=86400)
            if mol_cid and q:
                cid_key = f"molcard:cid:{mol_cid}"
                await self._cache.set_raw(cid_key, card_dict, ttl=86400)
        except Exception as _cache_err:
            logger.error('card_cache_save_failed', error=str(_cache_err))
            card_dict = card.model_dump(mode="json")

        # ── DB permanent save ──
        try:
            from app.core.database import async_session_factory
            from app.models.molecule_card import MoleculeCardCache
            from sqlalchemy import select
            async with async_session_factory() as db_session:
                existing = None
                if mol_cid:
                    existing = (await db_session.execute(
                        select(MoleculeCardCache).where(MoleculeCardCache.cid == mol_cid)
                    )).scalar_one_or_none()
                if existing:
                    existing.card_json = card_dict
                    existing.query = q or str(cid or "")
                else:
                    db_session.add(MoleculeCardCache(
                        cid=mol_cid,
                        name=card_dict.get("name", ""),
                        query=q or str(cid or ""),
                        card_json=card_dict,
                    ))
                await db_session.commit()
                log.info("card_db_saved", cid=mol_cid, name=card_dict.get("name"))
        except Exception as _db_err:
            log.warning("card_db_save_failed", error=str(_db_err))

        log.info("card_completed", elapsed_ms=round(elapsed, 1))
        return card

    async def _fetch_similar_molecules(
        self, cid: int, threshold: int = 90, max_records: int = 3
    ) -> list:
        """Fetch similar molecules from PubChem 2D similarity search."""
        from app.schemas.molecule_card import SimilarMolecule

        url = (
            f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/"
            f"fastsimilarity_2d/cid/{cid}/"
            f"property/IUPACName,MolecularFormula,CanonicalSMILES/JSON"
            f"?Threshold={threshold}&MaxRecords={max_records + 1}"
        )
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(url)
            if resp.status_code != 200:
                return []

        props_list = resp.json().get("PropertyTable", {}).get("Properties", [])

        results = []
        for p in props_list:
            result_cid = p.get("CID")
            if result_cid == cid:
                continue  # skip self
            results.append(
                SimilarMolecule(
                    cid=result_cid,
                    name=p.get("IUPACName", f"CID-{result_cid}"),
                    similarity=threshold / 100.0,
                    molecular_formula=p.get("MolecularFormula"),
                    thumbnail_url=f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{result_cid}/PNG?image_size=120x120",
                )
            )
            if len(results) >= max_records:
                break
        return results

    async def _generate_card_summary(self, mol) -> str | None:
        """Generate a 1-2 sentence AI summary of the molecule."""
        try:
            from app.core.config import settings
            if not settings.GEMINI_API_KEY:
                return None

            from google import genai

            client = genai.Client(api_key=settings.GEMINI_API_KEY)
            prompt = (
                f"In 1-2 concise sentences, describe what {mol.name} "
                f"(SMILES: {mol.canonical_smiles}) is, including its primary uses, "
                f"drug class (if applicable), and key characteristics. "
                f"Be factual and scientific. If it's not a well-known compound, "
                f"describe its chemical class based on functional groups."
            )
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=prompt,
            )
            text = response.text.strip() if response.text else None
            return text[:500] if text else None
        except Exception as e:
            logger.debug("card_summary_failed", error=str(e))
            return None

```

### File: backend/app/services/molecule_engine/pug_rest_resolver.py

```py

"""
PUG REST Resolver — PubChem Name→CID exact-match resolution.

Replaces the old Autocomplete + Jaro-Winkler + Synonym 3-stage validator.
PUG REST /compound/name/{name} does EXACT matching against PubChem's
119M+ compound synonym database. No fuzzy matching, no spell-suggest,
no false positives like "dietary fiber" → "diethyl phthalate".

Response time: typically 100-300ms.
Rate limit: 5 req/s, 400 req/min (shared with all PUG REST).
Cost: $0 (NIH public API).
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import httpx
import structlog

logger = structlog.get_logger(__name__)

_PUG_REST_BASE = "https://pubchem.ncbi.nlm.nih.gov/rest/pug"
_TIMEOUT = httpx.Timeout(connect=3.0, read=8.0, write=3.0, pool=3.0)


@dataclass
class PugRestResult:
    """Result of PUG REST name resolution."""
    found: bool
    cid: int | None = None
    name: str | None = None          # canonical name from PubChem
    iupac_name: str | None = None
    molecular_formula: str | None = None
    molecular_weight: float | None = None
    canonical_smiles: str | None = None
    inchi: str | None = None
    inchikey: str | None = None
    synonyms: list[str] | None = None
    elapsed_ms: float = 0.0
    error: str | None = None

    # Full property dict for downstream use
    properties: dict | None = None


async def resolve_name_to_cid(query: str, timeout: float = 8.0) -> PugRestResult:
    """Resolve a chemical name to PubChem CID via PUG REST exact match.

    This replaces the 3-stage validator (Autocomplete + Jaro-Winkler + Synonym).
    PUG REST name search matches against PubChem's synonym database,
    which includes common names, IUPAC names, trade names, CAS numbers, etc.

    Args:
        query: Chemical name string (e.g., "aspirin", "caffeine", "glucose")
        timeout: HTTP timeout in seconds

    Returns:
        PugRestResult with found=True and full properties, or found=False
    """
    t0 = time.perf_counter()
    query_clean = query.strip()

    if not query_clean or len(query_clean) < 2:
        return PugRestResult(
            found=False,
            error="Query too short",
            elapsed_ms=(time.perf_counter() - t0) * 1000,
        )

    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            # Step 1: Name → CID (exact match against synonym DB)
            cid_url = f"{_PUG_REST_BASE}/compound/name/{query_clean}/cids/JSON"
            cid_resp = await client.get(cid_url)

            if cid_resp.status_code != 200:
                elapsed = (time.perf_counter() - t0) * 1000
                logger.info(
                    "pug_rest_name_not_found",
                    query=query_clean,
                    status=cid_resp.status_code,
                    elapsed_ms=round(elapsed, 1),
                )
                return PugRestResult(
                    found=False,
                    error=f"Not found in PubChem (HTTP {cid_resp.status_code})",
                    elapsed_ms=elapsed,
                )

            cid_data = cid_resp.json()
            cids = cid_data.get("IdentifierList", {}).get("CID", [])
            if not cids:
                return PugRestResult(
                    found=False,
                    error="No CID returned",
                    elapsed_ms=(time.perf_counter() - t0) * 1000,
                )

            cid = cids[0]

            # Step 2: Fetch properties + synonyms in parallel
            prop_url = (
                f"{_PUG_REST_BASE}/compound/cid/{cid}"
                f"/property/IUPACName,MolecularFormula,MolecularWeight,"
                f"CanonicalSMILES,InChI,InChIKey,XLogP,TPSA,"
                f"HBondDonorCount,HBondAcceptorCount,RotatableBondCount,"
                f"HeavyAtomCount,Complexity,ExactMass,Charge/JSON"
            )
            syn_url = f"{_PUG_REST_BASE}/compound/cid/{cid}/synonyms/JSON"

            prop_resp, syn_resp = await asyncio.gather(
                client.get(prop_url),
                client.get(syn_url),
                return_exceptions=True,
            )

            # Parse properties
            props = {}
            if isinstance(prop_resp, httpx.Response) and prop_resp.status_code == 200:
                props = prop_resp.json().get("PropertyTable", {}).get("Properties", [{}])[0]

            # Parse synonyms
            synonyms = []
            canonical_name = props.get("IUPACName", query_clean)
            if isinstance(syn_resp, httpx.Response) and syn_resp.status_code == 200:
                syn_list = (
                    syn_resp.json()
                    .get("InformationList", {})
                    .get("Information", [{}])[0]
                    .get("Synonym", [])
                )
                synonyms = syn_list[:20]
                if syn_list:
                    canonical_name = syn_list[0]  # First synonym is usually the common name

            elapsed = (time.perf_counter() - t0) * 1000
            logger.info(
                "pug_rest_resolved",
                query=query_clean,
                cid=cid,
                name=canonical_name,
                elapsed_ms=round(elapsed, 1),
            )

            return PugRestResult(
                found=True,
                cid=cid,
                name=canonical_name,
                iupac_name=props.get("IUPACName"),
                molecular_formula=props.get("MolecularFormula"),
                molecular_weight=props.get("MolecularWeight"),
                canonical_smiles=props.get("CanonicalSMILES"),
                inchi=props.get("InChI"),
                inchikey=props.get("InChIKey"),
                synonyms=synonyms,
                elapsed_ms=elapsed,
                properties={
                    "iupac_name": props.get("IUPACName"),
                    "xlogp": props.get("XLogP"),
                    "tpsa": props.get("TPSA"),
                    "hbond_donor": props.get("HBondDonorCount"),
                    "hbond_acceptor": props.get("HBondAcceptorCount"),
                    "rotatable_bonds": props.get("RotatableBondCount"),
                    "heavy_atom_count": props.get("HeavyAtomCount"),
                    "complexity": props.get("Complexity"),
                    "exact_mass": str(props.get("ExactMass", "")),
                    "charge": props.get("Charge"),
                    "synonyms": synonyms,
                },
            )

    except httpx.TimeoutException:
        elapsed = (time.perf_counter() - t0) * 1000
        logger.warning("pug_rest_timeout", query=query_clean, elapsed_ms=round(elapsed, 1))
        return PugRestResult(found=False, error="PubChem timeout", elapsed_ms=elapsed)
    except Exception as exc:
        elapsed = (time.perf_counter() - t0) * 1000
        logger.warning("pug_rest_error", query=query_clean, error=str(exc), elapsed_ms=round(elapsed, 1))
        return PugRestResult(found=False, error=str(exc), elapsed_ms=elapsed)


# Need asyncio for gather
import asyncio

```

### File: backend/app/services/molecule_engine/query_resolver.py

```py

"""
QueryResolver – 3-tier intelligent query resolution pipeline.

Tier 1: Local dictionary (Korean→English, common aliases, 0ms, free)
Tier 2: PubChem Autocomplete API (fuzzy match + spell-suggest, ~100ms, free)
Tier 3: Gemini Flash LLM (complex NL queries, ~500ms, ~$0.001/query)

Usage:
    resolver = QueryResolver()
    result = await resolver.resolve("카페인")
    # result.resolved_query = "caffeine"
    # result.method = "dictionary"
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass, field
from typing import Any

import httpx
import structlog

logger = structlog.get_logger(__name__)

_PUBCHEM_AUTOCOMPLETE = "https://pubchem.ncbi.nlm.nih.gov/rest/autocomplete/compound"
_TIMEOUT = httpx.Timeout(connect=3.0, read=5.0, write=3.0, pool=3.0)


@dataclass
class ResolvedQuery:
    """Result of query resolution."""
    original: str
    resolved_query: str
    method: str  # "passthrough" | "dictionary" | "autocomplete" | "llm"
    confidence: float = 1.0
    suggestions: list[str] = field(default_factory=list)
    language: str = "en"


# ═══════════════════════════════════════════
# Tier 1: Local Korean→English + Common Alias Dictionary
# ═══════════════════════════════════════════

# Top ~300 commonly searched molecules in Korean
_KO_EN_DICT: dict[str, str] = {
    # ── 일상 화합물 ──
    "물": "water",
    "소금": "sodium chloride",
    "설탕": "sucrose",
    "포도당": "glucose",
    "과당": "fructose",
    "젖당": "lactose",
    "녹말": "starch",
    "식초": "acetic acid",
    "알코올": "ethanol",
    "에탄올": "ethanol",
    "메탄올": "methanol",
    "아세톤": "acetone",
    "벤젠": "benzene",
    "톨루엔": "toluene",
    "자일렌": "xylene",
    "글리세린": "glycerol",
    "글리세롤": "glycerol",
    "요소": "urea",
    "암모니아": "ammonia",
    "이산화탄소": "carbon dioxide",
    "일산화탄소": "carbon monoxide",
    "산소": "oxygen",
    "수소": "hydrogen",
    "질소": "nitrogen",
    "오존": "ozone",
    "과산화수소": "hydrogen peroxide",
    "염산": "hydrochloric acid",
    "황산": "sulfuric acid",
    "질산": "nitric acid",
    "인산": "phosphoric acid",
    "탄산": "carbonic acid",
    "구연산": "citric acid",
    "아세트산": "acetic acid",
    "옥살산": "oxalic acid",
    "포름산": "formic acid",
    "수산화나트륨": "sodium hydroxide",
    "수산화칼륨": "potassium hydroxide",
    "중탄산나트륨": "sodium bicarbonate",
    "베이킹소다": "sodium bicarbonate",
    "탄산칼슘": "calcium carbonate",
    "염화나트륨": "sodium chloride",
    "염화칼슘": "calcium chloride",
    "염화칼륨": "potassium chloride",

    # ── 카페인/식품 관련 ──
    "카페인": "caffeine",
    "테오브로민": "theobromine",
    "타우린": "taurine",
    "니코틴": "nicotine",
    "캡사이신": "capsaicin",
    "멘톨": "menthol",
    "바닐린": "vanillin",
    "리모넨": "limonene",

    # ── 의약품 ──
    "아스피린": "aspirin",
    "타이레놀": "acetaminophen",
    "아세트아미노펜": "acetaminophen",
    "파라세타몰": "paracetamol",
    "이부프로펜": "ibuprofen",
    "나프록센": "naproxen",
    "페니실린": "penicillin",
    "아목시실린": "amoxicillin",
    "메트포르민": "metformin",
    "인슐린": "insulin",
    "모르핀": "morphine",
    "코데인": "codeine",
    "디아제팜": "diazepam",
    "프로작": "fluoxetine",
    "옴니프라졸": "omeprazole",
    "로라타딘": "loratadine",
    "세티리진": "cetirizine",
    "실데나필": "sildenafil",
    "아토르바스타틴": "atorvastatin",
    "메토프롤롤": "metoprolol",
    "암로디핀": "amlodipine",
    "리시노프릴": "lisinopril",
    "와파린": "warfarin",
    "헤파린": "heparin",
    "독소루비신": "doxorubicin",
    "시스플라틴": "cisplatin",
    "타목시펜": "tamoxifen",
    "프레드니솔론": "prednisolone",
    "덱사메타손": "dexamethasone",
    "히드로코르티손": "hydrocortisone",
    "에피네프린": "epinephrine",
    "아드레날린": "adrenaline",
    "노르에피네프린": "norepinephrine",
    "리도카인": "lidocaine",
    "프로포폴": "propofol",
    "케타민": "ketamine",

    # ── 비타민/영양소 ──
    "비타민A": "retinol",
    "비타민B1": "thiamine",
    "비타민B2": "riboflavin",
    "비타민B3": "niacin",
    "비타민B5": "pantothenic acid",
    "비타민B6": "pyridoxine",
    "비타민B7": "biotin",
    "비타민B9": "folic acid",
    "비타민B12": "cyanocobalamin",
    "비타민C": "ascorbic acid",
    "비타민D": "cholecalciferol",
    "비타민E": "tocopherol",
    "비타민K": "phylloquinone",
    "엽산": "folic acid",
    "코엔자임Q10": "coenzyme Q10",
    "오메가3": "eicosapentaenoic acid",
    "루테인": "lutein",
    "콜라겐": "collagen",
    "글루코사민": "glucosamine",
    "콘드로이틴": "chondroitin",
    "크레아틴": "creatine",
    "카르니틴": "carnitine",

    # ── 신경전달물질/호르몬 ──
    "도파민": "dopamine",
    "세로토닌": "serotonin",
    "멜라토닌": "melatonin",
    "아세틸콜린": "acetylcholine",
    "글루탐산": "glutamic acid",
    "가바": "gamma-aminobutyric acid",
    "히스타민": "histamine",
    "옥시토신": "oxytocin",
    "테스토스테론": "testosterone",
    "에스트로겐": "estrogen",
    "프로게스테론": "progesterone",
    "코르티솔": "cortisol",
    "갑상선호르몬": "thyroxine",

    # ── 아미노산 ──
    "글리신": "glycine",
    "알라닌": "alanine",
    "발린": "valine",
    "류신": "leucine",
    "이소류신": "isoleucine",
    "프롤린": "proline",
    "페닐알라닌": "phenylalanine",
    "트립토판": "tryptophan",
    "메티오닌": "methionine",
    "세린": "serine",
    "트레오닌": "threonine",
    "시스테인": "cysteine",
    "타이로신": "tyrosine",
    "아스파르트산": "aspartic acid",
    "글루타민": "glutamine",
    "라이신": "lysine",
    "아르기닌": "arginine",
    "히스티딘": "histidine",

    # ── 핵산/생화학 ──
    "아데닌": "adenine",
    "구아닌": "guanine",
    "시토신": "cytosine",
    "티민": "thymine",
    "우라실": "uracil",
    "아데노신": "adenosine",

    # ── 지질/콜레스테롤 ──
    "콜레스테롤": "cholesterol",
    "트리글리세리드": "triglyceride",
    "스핑고미엘린": "sphingomyelin",

    # ── 산업/환경 화합물 ──
    "폼알데히드": "formaldehyde",
    "포름알데히드": "formaldehyde",
    "클로로포름": "chloroform",
    "에틸렌글리콜": "ethylene glycol",
    "프로필렌글리콜": "propylene glycol",
    "디메틸설폭사이드": "dimethyl sulfoxide",
    "나프탈렌": "naphthalene",
    "페놀": "phenol",
    "아닐린": "aniline",
    "피리딘": "pyridine",
    "퓨란": "furan",
    "다이옥신": "dioxin",
    "비스페놀A": "bisphenol A",
    "폴리에틸렌": "polyethylene",
    "나일론": "nylon",
    "실리콘": "silicone",
}

# Build a normalized lookup (lowercase, stripped)
_KO_EN_NORMALIZED: dict[str, str] = {
    k.lower().strip(): v for k, v in _KO_EN_DICT.items()
}

# Common English aliases that PubChem might not match directly
_EN_ALIAS: dict[str, str] = {
    "tylenol": "acetaminophen",
    "advil": "ibuprofen",
    "motrin": "ibuprofen",
    "aleve": "naproxen",
    "benadryl": "diphenhydramine",
    "zyrtec": "cetirizine",
    "claritin": "loratadine",
    "lipitor": "atorvastatin",
    "viagra": "sildenafil",
    "prozac": "fluoxetine",
    "zoloft": "sertraline",
    "xanax": "alprazolam",
    "valium": "diazepam",
    "adderall": "amphetamine",
    "ritalin": "methylphenidate",
    "ambien": "zolpidem",
    "nexium": "esomeprazole",
    "prilosec": "omeprazole",
    "zantac": "ranitidine",
    "vitamin c": "ascorbic acid",
    "vitamin a": "retinol",
    "vitamin d": "cholecalciferol",
    "vitamin e": "tocopherol",
    "vitamin k": "phylloquinone",
    "vitamin b1": "thiamine",
    "vitamin b2": "riboflavin",
    "vitamin b3": "niacin",
    "vitamin b6": "pyridoxine",
    "vitamin b12": "cyanocobalamin",
    "baking soda": "sodium bicarbonate",
    "table salt": "sodium chloride",
    "rubbing alcohol": "isopropanol",
    "bleach": "sodium hypochlorite",
    "lye": "sodium hydroxide",
    "atp": "adenosine triphosphate",
    "adp": "adenosine diphosphate",
    "nad": "nicotinamide adenine dinucleotide",
    "nadh": "nicotinamide adenine dinucleotide",
    "fad": "flavin adenine dinucleotide",
    "coq10": "coenzyme Q10",
    "dha": "docosahexaenoic acid",
    "epa": "eicosapentaenoic acid",
    "msg": "monosodium glutamate",
    "thc": "tetrahydrocannabinol",
    "cbd": "cannabidiol",
    "lsd": "lysergic acid diethylamide",
    "mdma": "methylenedioxymethamphetamine",
    "dmt": "dimethyltryptamine",
    "ddt": "dichlorodiphenyltrichloroethane",
    "pcb": "polychlorinated biphenyl",
    "pvc": "polyvinyl chloride",
    "tnt": "trinitrotoluene",
}

_EN_ALIAS_NORMALIZED: dict[str, str] = {
    k.lower().strip(): v for k, v in _EN_ALIAS.items()
}


def _has_korean(text: str) -> bool:
    """Check if text contains Korean characters."""
    return bool(re.search(r"[\uAC00-\uD7AF\u3131-\u3163\u1100-\u11FF]", text))


def _normalize(text: str) -> str:
    """Normalize query for dictionary lookup."""
    return re.sub(r"\s+", "", text.lower().strip())


class QueryResolver:
    """3-tier intelligent query resolution."""

    def __init__(self, gemini_client=None):
        self._gemini = gemini_client

    async def resolve(self, query: str) -> ResolvedQuery:
        """Resolve a query through the 3-tier pipeline."""
        original = query.strip()
        if not original:
            return ResolvedQuery(original=original, resolved_query=original, method="passthrough")

        # ── Tier 0: Passthrough for CID-like queries ──
        # Pure digits = CID, "CID 1234" pattern, or CAS numbers → skip resolution
        stripped = original.strip()
        if stripped.isdigit():
            # Pure number → likely a CID, pass through directly
            return ResolvedQuery(original=original, resolved_query=stripped, method="passthrough")
        if re.match(r"^(?:CID\s*)?(\d{2,})$", stripped, re.IGNORECASE):
            return ResolvedQuery(original=original, resolved_query=stripped, method="passthrough")
        if re.match(r"^\d{2,7}-\d{2}-\d$", stripped):
            # CAS number pattern → pass through
            return ResolvedQuery(original=original, resolved_query=stripped, method="passthrough")

        # ── Tier 1: Local dictionary ──
        result = self._tier1_dictionary(original)
        if result is not None:
            logger.info("query_resolved_dictionary", original=original, resolved=result.resolved_query)
            return result

        # ── Tier 2: PubChem Autocomplete (fuzzy + spell-suggest) ──
        result = await self._tier2_pug_rest(original)
        if result is not None:
            logger.info("query_resolved_autocomplete", original=original, resolved=result.resolved_query)
            return result

        # ── Tier 3: Gemini LLM (complex/unknown queries) ──
        if _has_korean(original) or not original.isascii():
            result = await self._tier3_llm(original)
            if result is not None:
                logger.info("query_resolved_llm", original=original, resolved=result.resolved_query)
                return result

        # Passthrough – use as-is
        return ResolvedQuery(original=original, resolved_query=original, method="passthrough")

    # ─── Tier 1: Dictionary ───

    def _tier1_dictionary(self, query: str) -> ResolvedQuery | None:
        """Fast local dictionary lookup."""
        normalized = _normalize(query)

        # Korean → English
        if _has_korean(query):
            en = _KO_EN_NORMALIZED.get(normalized)
            if en:
                return ResolvedQuery(
                    original=query,
                    resolved_query=en,
                    method="dictionary",
                    confidence=0.95,
                    language="ko",
                )

        # English alias → canonical name
        en = _EN_ALIAS_NORMALIZED.get(normalized)
        if en:
            return ResolvedQuery(
                original=query,
                resolved_query=en,
                method="dictionary",
                confidence=0.95,
                language="en",
            )

        return None

    # ─── Tier 2: PUG REST (primary) + Autocomplete (fallback) ───

    async def _tier2_pug_rest(self, query: str) -> ResolvedQuery | None:
        """PUG REST exact name→CID resolution (primary path).

        Unlike Autocomplete which does fuzzy/spell-suggest matching,
        PUG REST /compound/name/ does EXACT matching against PubChem's
        synonym database. This eliminates false positives like
        "dietary fiber" → "diethyl phthalate".
        """
        if _has_korean(query):
            return None  # Korean must go through dictionary or LLM first

        try:
            async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
                # Direct exact-match lookup
                url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{query}/cids/JSON"
                resp = await client.get(url)

                if resp.status_code == 200:
                    cids = resp.json().get("IdentifierList", {}).get("CID", [])
                    if cids:
                        # Found! Query is a valid PubChem name — passthrough
                        logger.info("pug_rest_exact_match", query=query, cid=cids[0])
                        return None  # None = use original query as-is (passthrough)

                # Not found via exact match — try Autocomplete as fallback
                # for genuine typos like "aspirn" → "aspirin"
                return await self._tier2_autocomplete_fallback(query)

        except Exception as exc:
            logger.debug("pug_rest_tier2_error", query=query, error=str(exc))
            return await self._tier2_autocomplete_fallback(query)

    async def _tier2_autocomplete_fallback(self, query: str) -> ResolvedQuery | None:
        """Autocomplete fallback — only for genuine typo correction.

        Used ONLY when PUG REST exact match fails. Much more conservative
        than before: only accepts autocomplete suggestions that are very
        close to the original query.
        """
        try:
            async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
                resp = await client.get(
                    f"{_PUBCHEM_AUTOCOMPLETE}/{query}/json",
                    params={"limit": 5},
                )
                if resp.status_code != 200:
                    return None

                data = resp.json()
                suggestions = data.get("dictionary_terms", {}).get("compound", [])
                if not suggestions:
                    return None

                ql = query.lower().strip()

                # Only accept if a suggestion is very close (likely a typo fix)
                for s in suggestions:
                    sl = s.lower().strip()
                    # Exact match (case difference) → passthrough
                    if sl == ql:
                        return None
                    # Starts with query and is short → likely the base compound
                    if sl.startswith(ql) and len(s) - len(query) <= 2:
                        return None

                # For genuine typo corrections: verify the suggestion works on PUG REST
                best = suggestions[0]
                try:
                    verify_url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{best}/cids/JSON"
                    verify_resp = await client.get(verify_url, timeout=3.0)
                    if verify_resp.status_code == 200:
                        cids = verify_resp.json().get("IdentifierList", {}).get("CID", [])
                        if cids:
                            logger.info("autocomplete_typo_correction",
                                       original=query, corrected=best, cid=cids[0])
                            return ResolvedQuery(
                                original=query,
                                resolved_query=best,
                                method="autocomplete",
                                confidence=0.70,
                                suggestions=suggestions[:5],
                                language="en",
                            )
                except Exception:
                    pass

                return None

        except Exception as exc:
            logger.debug("autocomplete_fallback_error", query=query, error=str(exc))
            return None

    # ─── Tier 3: Gemini LLM ───

    async def _tier3_llm(self, query: str) -> ResolvedQuery | None:
        """Use Gemini Flash to translate/resolve complex queries."""
        if self._gemini is None:
            # Try importing
            try:
                from app.services.intelligence.gemini_client import GeminiClient
                self._gemini = GeminiClient()
            except Exception:
                return None

        prompt = f"""You are a chemistry search assistant. The user entered a search query that may be in Korean,
contain typos, or use informal names. Convert it to the standard English chemical/molecule name
that would work on PubChem.

Rules:
- Return ONLY the English chemical name, nothing else.
- If it's already a valid English name, return it as-is.
- If it's Korean, translate to the standard English chemical name.
- If it's an abbreviation or brand name, expand to the generic chemical name.
- If you're not sure, return the best guess.

User query: {query}
English chemical name:"""

        try:
            result = await asyncio.wait_for(
                self._gemini.generate(
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.0,
                    max_tokens=100,
                ),
                timeout=5.0,
            )
            text = result.get("text", "").strip().strip('"').strip("'").strip()
            if text and len(text) < 200 and not _has_korean(text):
                return ResolvedQuery(
                    original=query,
                    resolved_query=text,
                    method="llm",
                    confidence=0.75,
                    language="ko" if _has_korean(query) else "en",
                )
        except Exception as exc:
            logger.debug("llm_resolve_error", query=query, error=str(exc))

        return None

```

### File: backend/app/services/molecule_engine/query_validator.py

```py

"""
Query Validation Pipeline for Molecule Card
============================================
3-stage validation to prevent false matches:
  Stage 1: PubChem Autocomplete dictionary check
  Stage 2: Jaro-Winkler string similarity
  Stage 3: Synonym reverse lookup

Stage 1 is mandatory (must pass).
Stage 2 and Stage 3 are OR-relation (either pass is OK).
"""

from __future__ import annotations

import time
import math
from dataclasses import dataclass, field

import httpx
import structlog

logger = structlog.get_logger(__name__)

AUTOCOMPLETE_URL = "https://pubchem.ncbi.nlm.nih.gov/rest/autocomplete/compound/{query}/json?limit=5"
AUTOCOMPLETE_TIMEOUT = 2.0
JARO_WINKLER_THRESHOLD = 0.75


@dataclass
class ValidationResult:
    valid: bool
    stage_failed: str | None = None
    reason: str | None = None
    autocomplete_total: int = 0
    jaro_winkler_score: float = 0.0
    synonym_matched: bool = False
    elapsed_ms: float = 0.0


# ── Jaro-Winkler (pure Python, no dependencies) ──

def _jaro_similarity(s1: str, s2: str) -> float:
    if s1 == s2:
        return 1.0
    len1, len2 = len(s1), len(s2)
    if len1 == 0 or len2 == 0:
        return 0.0

    match_distance = max(len1, len2) // 2 - 1
    if match_distance < 0:
        match_distance = 0

    s1_matches = [False] * len1
    s2_matches = [False] * len2
    matches = 0
    transpositions = 0

    for i in range(len1):
        start = max(0, i - match_distance)
        end = min(i + match_distance + 1, len2)
        for j in range(start, end):
            if s2_matches[j] or s1[i] != s2[j]:
                continue
            s1_matches[i] = True
            s2_matches[j] = True
            matches += 1
            break

    if matches == 0:
        return 0.0

    k = 0
    for i in range(len1):
        if not s1_matches[i]:
            continue
        while not s2_matches[k]:
            k += 1
        if s1[i] != s2[k]:
            transpositions += 1
        k += 1

    jaro = (matches / len1 + matches / len2 + (matches - transpositions / 2) / matches) / 3
    return jaro


def _jaro_winkler(s1: str, s2: str, prefix_weight: float = 0.1) -> float:
    jaro = _jaro_similarity(s1, s2)
    prefix = 0
    for i in range(min(4, len(s1), len(s2))):
        if s1[i] == s2[i]:
            prefix += 1
        else:
            break
    return jaro + prefix * prefix_weight * (1 - jaro)


# ── Stage 1: PubChem Autocomplete ──

async def _check_autocomplete(query: str) -> tuple[bool, int]:
    """Check if query exists in PubChem compound dictionary."""
    query_clean = query.strip().lower()
    if len(query_clean) < 3:
        return True, -1  # too short, skip

    try:
        async with httpx.AsyncClient(timeout=AUTOCOMPLETE_TIMEOUT) as client:
            url = AUTOCOMPLETE_URL.format(query=httpx.URL(query_clean).raw_path.decode() if False else query_clean)
            # Simple URL construction
            url = f"https://pubchem.ncbi.nlm.nih.gov/rest/autocomplete/compound/{query_clean}/json?limit=5"
            resp = await client.get(url)
            if resp.status_code != 200:
                return True, -1  # API error → pass (fail-open)

            data = resp.json()
            total = data.get("total", 0)
            terms = data.get("dictionary_terms", {}).get("compound", [])

            if total == 0:
                return False, 0

            # Check if any returned term is related to the query
            query_lower = query_clean.lower()
            for term in terms:
                term_lower = term.lower()
                if query_lower in term_lower or term_lower in query_lower:
                    return True, total
                # Also check Jaro-Winkler between query and autocomplete result
                if _jaro_winkler(query_lower, term_lower) >= 0.85:
                    return True, total

            # Autocomplete returned results but none match the query well
            return False, total

    except Exception as e:
        logger.warning("autocomplete_check_error", error=str(e))
        return True, -1  # fail-open on error


# ── Stage 2: Jaro-Winkler similarity ──

def _check_jaro_winkler(query: str, result_name: str, iupac_name: str | None) -> tuple[bool, float]:
    """Check string similarity between query and result names."""
    q = query.strip().lower()
    best = 0.0

    for name in [result_name, iupac_name]:
        if not name:
            continue
        n = name.strip().lower()
        score = _jaro_winkler(q, n)
        best = max(best, score)

        # Also check individual words for multi-word queries
        # e.g., "citric acid" vs "citric acid" should work
        if ' ' in q and ' ' in n:
            q_words = set(q.split())
            n_words = set(n.split())
            if q_words & n_words:  # shared words
                overlap = len(q_words & n_words) / max(len(q_words), len(n_words))
                best = max(best, overlap)

    return best >= JARO_WINKLER_THRESHOLD, best


# ── Stage 3: Synonym reverse check ──

def _check_synonyms(query: str, synonyms: list[str]) -> bool:
    """Check if query appears in the synonym list."""
    if not synonyms:
        return False

    q = query.strip().lower()
    for syn in synonyms:
        s = syn.strip().lower()
        if q in s or s in q:
            return True
        # Check Jaro-Winkler for close matches (e.g., typos)
        if _jaro_winkler(q, s) >= 0.90:
            return True
    return False


# ── Main Validation Function ──

async def validate_query_match(
    query: str,
    result_name: str,
    iupac_name: str | None = None,
    synonyms: list[str] | None = None,
    is_cid_query: bool = False,
) -> ValidationResult:
    """
    Validate that a search result actually matches the query.

    Args:
        query: Original user query string
        result_name: Name returned by PubChem search
        iupac_name: IUPAC name of the result
        synonyms: List of synonyms for the result
        is_cid_query: If True, skip all validation (CID is exact)

    Returns:
        ValidationResult with valid=True/False and diagnostics
    """
    t0 = time.perf_counter()

    # CID queries are always valid (exact identifier)
    if is_cid_query:
        return ValidationResult(
            valid=True,
            elapsed_ms=(time.perf_counter() - t0) * 1000,
        )

    synonyms = synonyms or []

    # ── Stage 1: Autocomplete ──
    ac_pass, ac_total = await _check_autocomplete(query)
    if not ac_pass:
        return ValidationResult(
            valid=False,
            stage_failed="autocomplete",
            reason=f"Query '{query}' not found in PubChem compound dictionary (total={ac_total})",
            autocomplete_total=ac_total,
            elapsed_ms=(time.perf_counter() - t0) * 1000,
        )

    # ── Stage 2 & 3: OR-relation ──
    jw_pass, jw_score = _check_jaro_winkler(query, result_name, iupac_name)
    syn_pass = _check_synonyms(query, synonyms)

    if not jw_pass and not syn_pass:
        return ValidationResult(
            valid=False,
            stage_failed="similarity_and_synonym",
            reason=f"Low similarity (JW={jw_score:.3f}) and query not in synonyms",
            autocomplete_total=ac_total,
            jaro_winkler_score=jw_score,
            synonym_matched=False,
            elapsed_ms=(time.perf_counter() - t0) * 1000,
        )

    return ValidationResult(
        valid=True,
        autocomplete_total=ac_total,
        jaro_winkler_score=jw_score,
        synonym_matched=syn_pass,
        elapsed_ms=(time.perf_counter() - t0) * 1000,
    )

```

### File: backend/app/schemas/**init**.py

```py

"""
Pydantic schemas (request / response models) for MolChat API.
"""

from app.schemas.chat import (
    ChatMessageResponse,
    ChatRequest,
    ChatResponse,
    SessionCreate,
    SessionResponse,
    SessionListResponse,
)
from app.schemas.common import (
    ErrorResponse,
    HealthResponse,
    PaginatedResponse,
    SuccessResponse,
)
from app.schemas.molecule import (
    MoleculeRecord,
    MoleculeSearchRequest,
    MoleculeSearchResponse,
    MoleculeDetailResponse,
    PropertyData,
    StructureData,
)

__all__ = [
    # Chat
    "ChatRequest",
    "ChatResponse",
    "ChatMessageResponse",
    "SessionCreate",
    "SessionResponse",
    "SessionListResponse",
    # Common
    "ErrorResponse",
    "HealthResponse",
    "PaginatedResponse",
    "SuccessResponse",
    # Molecule
    "MoleculeRecord",
    "MoleculeSearchRequest",
    "MoleculeSearchResponse",
    "MoleculeDetailResponse",
    "PropertyData",
    "StructureData",
]
```

### File: backend/app/schemas/chat.py

```py

"""
Pydantic schemas for chat / session API endpoints.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


# ═══════════════════════════════════════════════
# Session
# ═══════════════════════════════════════════════


class SessionCreate(BaseModel):
    """Request body to create a new chat session."""

    title: str | None = Field(
        default=None, max_length=512, description="Optional session title"
    )
    model_preference: str | None = Field(
        default=None, description="Preferred LLM model name"
    )


class SessionResponse(BaseModel):
    """Single session representation."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str | None
    model_used: str | None
    message_count: int
    created_at: datetime
    updated_at: datetime


class SessionListResponse(BaseModel):
    """Paginated list of sessions."""

    total: int
    limit: int
    offset: int
    sessions: list[SessionResponse]


# ═══════════════════════════════════════════════
# Chat Message
# ═══════════════════════════════════════════════


class ChatRequest(BaseModel):
    """User message sent to the chat endpoint."""

    message: str = Field(
        ...,
        min_length=1,
        max_length=4000,
        description="User's question or instruction",
    )
    session_id: uuid.UUID | None = Field(
        default=None, description="Existing session ID; omit to auto-create"
    )
    context: dict[str, Any] | None = Field(
        default=None, description="Optional context (e.g., selected molecule CID)"
    )
    stream: bool = Field(
        default=False, description="Enable streaming response via SSE"
    )


class ChatMessageResponse(BaseModel):
    """Single chat message in a response."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    session_id: uuid.UUID
    role: str  # user, assistant, system, tool
    content: str
    token_count: int | None = None
    model_used: str | None = None
    tool_calls: dict[str, Any] | None = None
    metadata_extra: dict[str, Any] | None = None
    created_at: datetime


class ChatResponse(BaseModel):
    """Response to a chat request."""

    session_id: uuid.UUID
    message: ChatMessageResponse
    molecules_referenced: list[dict[str, Any]] = Field(default_factory=list)
    tool_results: list[dict[str, Any]] = Field(default_factory=list)
    confidence: float | None = Field(
        default=None, ge=0.0, le=1.0, description="LLM confidence score"
    )
    hallucination_flags: list[str] = Field(default_factory=list)
    elapsed_ms: float

class SessionUpdate(BaseModel):
    """Request body to update a session."""
    title: str | None = Field(default=None, max_length=512)

```

### File: backend/app/schemas/common.py

```py

"""
Common Pydantic schemas shared across all API endpoints.

Provides:
  • SuccessResponse   – generic success acknowledgement
  • ErrorResponse     – RFC 7807 Problem Details error
  • HealthResponse    – structured health check output
  • PaginatedResponse – generic pagination wrapper
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class SuccessResponse(BaseModel):
    """Generic success response."""

    success: bool = True
    message: str = "OK"
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ErrorResponse(BaseModel):
    """RFC 7807 Problem Details style error response.

    Matches the format produced by ``ErrorHandlerMiddleware``.
    """

    error: str = Field(..., description="Machine-readable error code")
    message: str = Field(..., description="Human-readable error description")
    status: int = Field(..., description="HTTP status code")
    details: dict[str, Any] | None = Field(
        default=None, description="Additional error context"
    )
    request_id: str | None = Field(
        default=None, description="Request trace ID"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "error": "MOLECULE_NOT_FOUND",
                "message": "Molecule not found: aspirin123",
                "status": 404,
                "details": {"query": "aspirin123"},
                "request_id": "550e8400-e29b-41d4-a716-446655440000",
            }
        }


class HealthResponse(BaseModel):
    """Structured health check response."""

    status: str = Field(..., description="Overall status: healthy, degraded, unhealthy")
    version: str = Field(..., description="Application version")
    environment: str = Field(..., description="Runtime environment")
    checks: dict[str, Any] = Field(
        default_factory=dict,
        description="Individual dependency health checks",
    )
    elapsed_ms: float = Field(
        default=0.0, description="Health check execution time"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "status": "healthy",
                "version": "1.0.0",
                "environment": "production",
                "checks": {
                    "database": {"status": "healthy", "type": "postgresql"},
                    "cache": {"status": "healthy", "type": "redis"},
                    "ollama": {"status": "healthy", "primary_ready": True},
                },
                "elapsed_ms": 45.2,
            }
        }


class PaginatedResponse(BaseModel, Generic[T]):
    """Generic paginated list response."""

    total: int = Field(..., description="Total number of items")
    limit: int = Field(..., description="Items per page")
    offset: int = Field(..., description="Current offset")
    items: list[Any] = Field(default_factory=list, description="Page items")

    @property
    def has_next(self) -> bool:
        return self.offset + self.limit < self.total

    @property
    def has_prev(self) -> bool:
        return self.offset > 0

    @property
    def page(self) -> int:
        return (self.offset // max(self.limit, 1)) + 1

    @property
    def total_pages(self) -> int:
        if self.limit <= 0:
            return 0
        return (self.total + self.limit - 1) // self.limit
```

### File: backend/app/schemas/molecule.py

```py

"""
Pydantic schemas for molecule-related API endpoints.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


# ═══════════════════════════════════════════════
# Sub-schemas
# ═══════════════════════════════════════════════


class PropertyData(BaseModel):
    """Computed or imported property set."""

    model_config = ConfigDict(from_attributes=True)

    source: str = Field(..., description="Property source: pubchem, rdkit, xtb")
    data: dict[str, Any] = Field(default_factory=dict, description="Property key-value pairs")


class StructureData(BaseModel):
    """3D/2D structure representation."""

    model_config = ConfigDict(from_attributes=True)

    format: str = Field(..., description="Structure format: sdf, mol2, xyz, pdb")
    structure_data: str = Field(..., description="Raw structure content")
    generation_method: str = Field(..., description="How the structure was generated")
    is_primary: bool = False


# ═══════════════════════════════════════════════
# Core Record
# ═══════════════════════════════════════════════


class MoleculeRecord(BaseModel):
    """Full molecule representation returned by the API."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    cid: int | None = None
    name: str
    canonical_smiles: str
    inchi: str | None = None
    inchikey: str | None = None
    molecular_formula: str | None = None
    molecular_weight: float | None = None
    properties: dict[str, Any] | None = None
    structures: list[StructureData] = Field(default_factory=list)
    computed_properties: list[PropertyData] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime


# ═══════════════════════════════════════════════
# Request / Response
# ═══════════════════════════════════════════════


class MoleculeSearchRequest(BaseModel):
    """Query parameters for molecule search."""

    q: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description="Search query: name, SMILES, InChIKey, CID, or formula",
    )
    limit: int = Field(default=10, ge=1, le=100, description="Max results")
    offset: int = Field(default=0, ge=0, description="Pagination offset")
    sources: list[str] | None = Field(
        default=None,
        description="Filter sources: pubchem, chembl, chemspider, zinc, local",
    )


class MoleculeSearchResponse(BaseModel):
    """Paginated search results."""

    query: str
    total: int
    limit: int
    offset: int
    results: list[MoleculeRecord]
    sources_queried: list[str]
    cache_hit: bool = False
    resolved_query: str | None = None
    original_query: str | None = None
    resolve_method: str | None = None
    resolve_suggestions: list[str] = []
    elapsed_ms: float


class MoleculeDetailResponse(BaseModel):
    """Detailed molecule view with all structures and properties."""

    molecule: MoleculeRecord
    available_formats: list[str] = Field(default_factory=list)
    calculation_status: str | None = None  # pending, running, completed, failed
    related_molecules: list[MoleculeRecord] = Field(default_factory=list)
```

### File: backend/app/schemas/molecule_card.py

```py

"""
Pydantic schemas for the Molecule Card endpoint.
Comprehensive single-molecule view: properties, safety, drug-likeness, similar molecules, AI summary.
"""

from __future__ import annotations

import uuid
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class DrugLikenessResult(BaseModel):
    """Result of a single drug-likeness rule evaluation."""
    rule_name: str = Field(..., description="Rule name: Lipinski, Veber, Ghose")
    passed: bool = Field(..., description="Whether the molecule passes this rule")
    violations: list[str] = Field(default_factory=list, description="List of violated criteria")
    details: str = ""


class GHSSafety(BaseModel):
    """GHS (Globally Harmonized System) safety classification."""
    signal_word: str | None = Field(default=None, description="Danger / Warning / None")
    pictograms: list[str] = Field(default_factory=list, description="GHS pictogram codes: GHS01~GHS09")
    pictogram_urls: list[str] = Field(default_factory=list, description="PubChem pictogram image URLs")
    h_statements: list[str] = Field(default_factory=list, description="Hazard statements")
    p_statements: list[str] = Field(default_factory=list, description="Precautionary statements")
    ld50: str | None = Field(default=None, description="LD50 data if available")


class SimilarMolecule(BaseModel):
    """A molecule similar to the queried one."""
    cid: int
    name: str = "Unknown"
    similarity: float = Field(..., ge=0.0, le=1.0, description="Tanimoto similarity 0~1")
    molecular_formula: str | None = None
    thumbnail_url: str = ""


class MoleculeCardResponse(BaseModel):
    """Comprehensive molecule card - everything you need in one response."""

    model_config = ConfigDict(from_attributes=True)

    # Identity
    id: uuid.UUID
    cid: int | None = None
    name: str = Field(..., description="Common name (enriched from synonyms)")
    iupac_name: str | None = None
    synonyms: list[str] = Field(default_factory=list)

    # Structure identifiers
    canonical_smiles: str
    inchi: str | None = None
    inchikey: str | None = None
    image_url: str = Field(default="", description="PubChem 2D structure PNG URL")

    # Core properties
    molecular_formula: str | None = None
    molecular_weight: float | None = None
    xlogp: float | None = None
    tpsa: float | None = None
    hbond_donor: int | None = None
    hbond_acceptor: int | None = None
    rotatable_bonds: int | None = None
    heavy_atom_count: int | None = None
    complexity: float | None = None
    exact_mass: str | None = None
    charge: int | None = None

    # Drug-likeness
    drug_likeness: list[DrugLikenessResult] = Field(default_factory=list)

    # Safety
    ghs_safety: GHSSafety | None = None

    # Similar molecules
    similar_molecules: list[SimilarMolecule] = Field(default_factory=list)

    # AI Summary
    ai_summary: str | None = Field(default=None, description="LLM-generated 1-2 sentence summary")

    # Metadata
    source: str = "pubchem"
    source_url: str | None = None
    elapsed_ms: float = 0.0
    cached: bool = False

```

### File: backend/app/models/**init**.py

```py

"""
SQLAlchemy ORM models - central registry.
Import all models here so Alembic autogenerate can discover them.
"""

from app.models.molecule import Base, Molecule, MoleculeProperty, MoleculeStructure
from app.models.session import ChatMessage, Session
from app.models.feedback import Feedback
from app.models.audit import ApiKey, AuditLog

__all__ = [
    "Base",
    "Molecule",
    "MoleculeStructure",
    "MoleculeProperty",
    "Session",
    "ChatMessage",
    "Feedback",
    "AuditLog",
    "ApiKey",
]
from app.models.molecule_card import MoleculeCardCache  # noqa: F401

```

### File: backend/app/models/audit.py

```py

"""
AuditLog and ApiKey ORM models.
audit_logs is designed for RANGE partitioning on created_at.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.models.molecule import Base


class AuditLog(Base):
    """Immutable audit trail for security-sensitive operations."""

    __tablename__ = "audit_logs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    action: Mapped[str] = mapped_column(
        String(100), nullable=False  # e.g., api_key.created, molecule.searched
    )
    actor: Mapped[str | None] = mapped_column(
        String(256)  # user_id, api_key name, or "system"
    )
    resource_type: Mapped[str | None] = mapped_column(String(50))
    resource_id: Mapped[str | None] = mapped_column(String(256))
    details: Mapped[dict | None] = mapped_column(JSONB, default=dict)
    ip_address: Mapped[str | None] = mapped_column(String(45))
    user_agent: Mapped[str | None] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    __table_args__ = (
        Index("ix_audit_action", "action"),
        Index("ix_audit_actor", "actor"),
        Index("ix_audit_created", "created_at"),
        Index("ix_audit_resource", "resource_type", "resource_id"),
        Index("ix_audit_details_gin", "details", postgresql_using="gin"),
        # NOTE: Partitioning DDL applied via migration.
    )

    def __repr__(self) -> str:
        return f"<AuditLog(id={self.id}, action='{self.action}')>"


class ApiKey(Base):
    """Hashed API keys for client authentication."""

    __tablename__ = "api_keys"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    key_hash: Mapped[str] = mapped_column(
        String(64), unique=True, nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    rate_limit: Mapped[int] = mapped_column(Integer, default=60)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = (
        Index("ix_apikey_active", "is_active", postgresql_where=(is_active.is_(True))),
    )

    def __repr__(self) -> str:
        return f"<ApiKey(id={self.id}, name='{self.name}', active={self.is_active})>"

```

### File: backend/app/models/feedback.py

```py

"""
Feedback ORM model – user ratings & comments on assistant responses.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.models.molecule import Base


class Feedback(Base):
    """User feedback on a specific chat message."""

    __tablename__ = "feedbacks"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    message_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("chat_messages.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("sessions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    rating: Mapped[int] = mapped_column(
        Integer, nullable=False  # 1-5 scale
    )
    category: Mapped[str | None] = mapped_column(
        String(50)  # accuracy, helpfulness, speed, hallucination, other
    )
    comment: Mapped[str | None] = mapped_column(Text)
    user_identifier: Mapped[str | None] = mapped_column(String(256))
    metadata_extra: Mapped[dict | None] = mapped_column(JSONB, default=dict)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    __table_args__ = (
        Index("ix_feedback_session_rating", "session_id", "rating"),
        Index("ix_feedback_category", "category"),
    )

    def __repr__(self) -> str:
        return f"<Feedback(id={self.id}, rating={self.rating})>"
```

### File: backend/app/models/molecule.py

```py

"""
Molecule-related ORM models.
Tables: molecules, molecule_structures, molecule_properties
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, TSVECTOR, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class Molecule(Base):
    """Core molecule table – one row per unique compound."""

    __tablename__ = "molecules"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    cid: Mapped[int | None] = mapped_column(Integer, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(512), nullable=False, index=True)
    canonical_smiles: Mapped[str] = mapped_column(Text, nullable=False)
    inchi: Mapped[str | None] = mapped_column(Text)
    inchikey: Mapped[str | None] = mapped_column(
        String(27), unique=True, index=True
    )
    molecular_formula: Mapped[str | None] = mapped_column(String(256))
    molecular_weight: Mapped[float | None] = mapped_column(Float)
    properties: Mapped[dict | None] = mapped_column(JSONB, default=dict)
    search_vector: Mapped[str | None] = mapped_column(TSVECTOR)

    # Soft-delete
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    structures: Mapped[list[MoleculeStructure]] = relationship(
        "MoleculeStructure", back_populates="molecule", cascade="all, delete-orphan"
    )
    computed_properties: Mapped[list[MoleculeProperty]] = relationship(
        "MoleculeProperty", back_populates="molecule", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("ix_molecules_search_vector", "search_vector", postgresql_using="gin"),
        Index("ix_molecules_name_trgm", "name", postgresql_using="gin",
              postgresql_ops={"name": "gin_trgm_ops"}),
        Index("ix_molecules_properties_gin", "properties", postgresql_using="gin"),
        Index("ix_molecules_not_deleted", "is_deleted",
              postgresql_where=(is_deleted.is_(False))),
    )

    def __repr__(self) -> str:
        return f"<Molecule(id={self.id}, name='{self.name}', cid={self.cid})>"


class MoleculeStructure(Base):
    """3D/2D structure data for a molecule (SDF, MOL2, XYZ, etc.)."""

    __tablename__ = "molecule_structures"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    molecule_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("molecules.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    format: Mapped[str] = mapped_column(
        String(20), nullable=False  # sdf, mol2, xyz, pdb, mol
    )
    structure_data: Mapped[str] = mapped_column(Text, nullable=False)
    generation_method: Mapped[str] = mapped_column(
        String(50), nullable=False  # pubchem, rdkit, xtb-optimized
    )
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)
    metadata_extra: Mapped[dict | None] = mapped_column(JSONB, default=dict)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    # Relationships
    molecule: Mapped[Molecule] = relationship("Molecule", back_populates="structures")

    __table_args__ = (
        UniqueConstraint(
            "molecule_id", "format", "is_primary",
            name="uq_mol_struct_primary",
        ),
        Index("ix_molstruct_mol_format", "molecule_id", "format"),
    )

    def __repr__(self) -> str:
        return (
            f"<MoleculeStructure(id={self.id}, format='{self.format}', "
            f"method='{self.generation_method}')>"
        )


class MoleculeProperty(Base):
    """Computed / imported property set for a molecule."""

    __tablename__ = "molecule_properties"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    molecule_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("molecules.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    source: Mapped[str] = mapped_column(
        String(50), nullable=False  # pubchem, rdkit, xtb
    )
    data: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    # Relationships
    molecule: Mapped[Molecule] = relationship(
        "Molecule", back_populates="computed_properties"
    )

    __table_args__ = (
        Index("ix_molprop_mol_source", "molecule_id", "source"),
        Index("ix_molprop_data_gin", "data", postgresql_using="gin"),
    )

    def __repr__(self) -> str:
        return f"<MoleculeProperty(id={self.id}, source='{self.source}')>"
```

### File: backend/app/models/molecule_card.py

```py

"""
MoleculeCard DB model — permanent cache for card API results.

Redis = hot cache (24h TTL), DB = permanent storage.
Flow: check Redis → check DB → build card → save both.
"""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import Column, String, Integer, DateTime, Text, Index
from sqlalchemy.dialects.postgresql import JSONB, UUID

from app.core.database import Base


class MoleculeCardCache(Base):
    __tablename__ = "molecule_card_cache"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    cid = Column(Integer, unique=True, index=True, nullable=True)
    name = Column(String(500), index=True, nullable=False)
    query = Column(String(500), nullable=False)  # original query that created this
    card_json = Column(JSONB, nullable=False)     # full card response
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_molcard_name_lower", "name"),
        Index("ix_molcard_cid", "cid"),
    )

    def __repr__(self) -> str:
        return f"<MoleculeCardCache name={self.name!r} cid={self.cid}>"

```

### File: backend/app/models/session.py

```py

"""
Session & ChatMessage ORM models.
chat_messages is range-partitioned by month on created_at.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.molecule import Base


class Session(Base):
    """A chat session (conversation thread)."""

    __tablename__ = "sessions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    title: Mapped[str | None] = mapped_column(String(512))
    user_identifier: Mapped[str | None] = mapped_column(
        String(256), index=True
    )
    model_used: Mapped[str | None] = mapped_column(String(100))
    message_count: Mapped[int] = mapped_column(Integer, default=0)
    metadata_extra: Mapped[dict | None] = mapped_column(JSONB, default=dict)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    messages: Mapped[list[ChatMessage]] = relationship(
        "ChatMessage",
        back_populates="session",
        cascade="all, delete-orphan",
        order_by="ChatMessage.created_at",
    )

    def __repr__(self) -> str:
        return f"<Session(id={self.id}, title='{self.title}')>"


class ChatMessage(Base):
    """Individual chat message within a session.

    Designed for monthly RANGE partitioning on created_at.
    Partition management via pg_partman or manual DDL.
    """

    __tablename__ = "chat_messages"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("sessions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    role: Mapped[str] = mapped_column(
        String(20), nullable=False  # user, assistant, system, tool
    )
    content: Mapped[str] = mapped_column(Text, nullable=False)
    token_count: Mapped[int | None] = mapped_column(Integer)
    model_used: Mapped[str | None] = mapped_column(String(100))
    tool_calls: Mapped[dict | None] = mapped_column(JSONB)
    metadata_extra: Mapped[dict | None] = mapped_column(JSONB, default=dict)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    # Relationships
    session: Mapped[Session] = relationship("Session", back_populates="messages")

    __table_args__ = (
        Index("ix_chatmsg_session_created", "session_id", "created_at"),
        Index("ix_chatmsg_role", "role"),
        Index("ix_chatmsg_tool_calls_gin", "tool_calls", postgresql_using="gin"),
        # NOTE: Partitioning DDL is applied via Alembic migration, not here.
        # {"postgresql_partition_by": "RANGE (created_at)"}
    )

    def __repr__(self) -> str:
        return (
            f"<ChatMessage(id={self.id}, role='{self.role}', "
            f"session={self.session_id})>"
        )
```

### File: backend/app/core/**init**.py

```py

"""
Core module – configuration, database, redis, security, logging.
"""
```

### File: backend/app/core/config.py

```py

"""
Application settings loaded from environment variables.
Uses pydantic-settings for validation and type coercion.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, PostgresDsn, RedisDsn, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central configuration for the MolChat backend."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ──
    APP_NAME: str = "MolChat"
    APP_ENV: Literal["development", "staging", "production", "test"] = "production"
    APP_DEBUG: bool = False
    APP_VERSION: str = "1.0.0"
    APP_HOST: str = "0.0.0.0"  # noqa: S104
    APP_PORT: int = 8000
    LOG_LEVEL: str = "INFO"
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000"]

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def parse_origins(cls, v: str | list[str]) -> list[str]:
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v

    # ── PostgreSQL ──
    POSTGRES_HOST: str = "postgres"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "molchat"
    POSTGRES_USER: str = "molchat"
    POSTGRES_PASSWORD: str = ""
    DATABASE_URL: PostgresDsn | str = ""
    DB_POOL_SIZE: int = 20
    DB_MAX_OVERFLOW: int = 10
    DB_POOL_TIMEOUT: int = 30

    @field_validator("DATABASE_URL", mode="before")
    @classmethod
    def assemble_db_url(cls, v: str, info: object) -> str:
        if v:
            return v
        data = info.data if hasattr(info, "data") else {}
        user = data.get("POSTGRES_USER", "molchat")
        password = data.get("POSTGRES_PASSWORD", "")
        host = data.get("POSTGRES_HOST", "postgres")
        port = data.get("POSTGRES_PORT", 5432)
        db = data.get("POSTGRES_DB", "molchat")
        return f"postgresql+asyncpg://{user}:{password}@{host}:{port}/{db}"

    # ── Redis ──
    REDIS_HOST: str = "redis"
    REDIS_PORT: int = 6379
    REDIS_PASSWORD: str = ""
    REDIS_URL: RedisDsn | str = ""
    REDIS_CACHE_TTL: int = 3600
    REDIS_MAX_MEMORY: str = "512mb"

    @field_validator("REDIS_URL", mode="before")
    @classmethod
    def assemble_redis_url(cls, v: str, info: object) -> str:
        if v:
            return v
        data = info.data if hasattr(info, "data") else {}
        password = data.get("REDIS_PASSWORD", "")
        host = data.get("REDIS_HOST", "redis")
        port = data.get("REDIS_PORT", 6379)
        return f"redis://:{password}@{host}:{port}/0"

    # ── Gemini (Primary LLM) ──
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-2.5-flash"
    GEMINI_MAX_TOKENS: int = 8192
    GEMINI_TEMPERATURE: float = 0.3
    GEMINI_TIMEOUT: int = 30
    GEMINI_MONTHLY_COST_LIMIT: float = 50.0

    # ── Ollama (Fallback LLM) ──
    OLLAMA_BASE_URL: str = "http://ollama:11434"
    OLLAMA_MODEL_PRIMARY: str = "qwen3:32b"
    OLLAMA_MODEL_FALLBACK: str = "qwen3:8b"
    OLLAMA_TIMEOUT: int = 120
    OLLAMA_NUM_CTX: int = 8192

    # ── ChemSpider (Optional) ──
    CHEMSPIDER_API_KEY: str = ""

    # ── JWT / Auth ──
    JWT_SECRET_KEY: str = "CHANGE_ME_JWT_SECRET_AT_LEAST_32_CHARS"  # noqa: S105
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    API_KEY_HASH_ALGORITHM: str = "sha256"

    # ── xTB Worker ──
    XTB_WORKER_CONCURRENCY: int = 2
    XTB_MAX_ATOMS: int = 200
    XTB_TIMEOUT: int = 20
    XTB_METHOD: str = "gfn2"

    # ── Rate Limiting ──
    RATE_LIMIT_REQUESTS: int = 60
    RATE_LIMIT_WINDOW: int = 60

    # ── Monitoring ──
    PROMETHEUS_ENABLED: bool = True

    # ── Computed helpers ──
    @property
    def is_development(self) -> bool:
        return self.APP_ENV == "development"

    @property
    def is_production(self) -> bool:
        return self.APP_ENV == "production"

    @property
    def database_url_sync(self) -> str:
        """Synchronous DB URL for Alembic offline mode."""
        return str(self.DATABASE_URL).replace(
            "postgresql+asyncpg://", "postgresql://"
        )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Cached settings singleton."""
    return Settings()


settings = get_settings()
```

### File: backend/app/core/database.py

```py

"""
Async SQLAlchemy engine, session factory, and dependency.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.pool import AsyncAdaptedQueuePool


class Base(DeclarativeBase):
    """SQLAlchemy declarative base for all ORM models."""
    pass

from app.core.config import settings

# ── Engine ──
engine = create_async_engine(
    str(settings.DATABASE_URL),
    poolclass=AsyncAdaptedQueuePool,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_MAX_OVERFLOW,
    pool_timeout=settings.DB_POOL_TIMEOUT,
    pool_pre_ping=True,
    pool_recycle=1800,
    echo=settings.APP_DEBUG,
    future=True,
)

# ── Session Factory ──
async_session_factory = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency — yields an async DB session and handles cleanup."""
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def dispose_engine() -> None:
    """Dispose the engine pool on shutdown."""
    await engine.dispose()
```

### File: backend/app/core/logging.py

```py

"""
Structured logging setup using structlog + stdlib.
"""

from __future__ import annotations

import logging
import sys

import structlog

from app.core.config import settings


def setup_logging() -> None:
    """Configure structlog and stdlib logging for the application."""

    log_level = getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO)

    # ── Shared processors ──
    shared_processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.ExtraAdder(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
    ]

    # ── Development: colored console. Production: JSON. ──
    if settings.is_development:
        renderer: structlog.types.Processor = structlog.dev.ConsoleRenderer(
            colors=True,
        )
    else:
        renderer = structlog.processors.JSONRenderer()

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    # ── Root handler ──
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)
    root_logger.setLevel(log_level)

    # ── Suppress noisy loggers ──
    for name in ("uvicorn.access", "sqlalchemy.engine", "httpx", "httpcore"):
        logging.getLogger(name).setLevel(logging.WARNING)


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Get a named structlog logger."""
    return structlog.get_logger(name)
```

### File: backend/app/core/redis.py

```py

"""
Redis async client with connection pool, cache helpers, and dependency.
"""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator
from typing import Any

import redis.asyncio as aioredis
from redis.asyncio import ConnectionPool, Redis

from app.core.config import settings

# ── Connection Pool ──
_pool: ConnectionPool | None = None


def _get_pool() -> ConnectionPool:
    """Lazily create a shared connection pool."""
    global _pool
    if _pool is None:
        _pool = ConnectionPool.from_url(
            str(settings.REDIS_URL),
            max_connections=50,
            decode_responses=True,
            socket_timeout=5.0,
            socket_connect_timeout=5.0,
            retry_on_timeout=True,
        )
    return _pool


def get_redis_client() -> Redis:
    """Return a Redis client bound to the shared pool."""
    return aioredis.Redis(connection_pool=_get_pool())


async def get_redis() -> AsyncGenerator[Redis, None]:
    """FastAPI dependency — yields a Redis client."""
    client = get_redis_client()
    try:
        yield client
    finally:
        await client.aclose()


# ═══════════════════════════════════════════════
# Cache Helpers
# ═══════════════════════════════════════════════


class CacheService:
    """Thin wrapper over Redis for JSON cache operations."""

    def __init__(self, client: Redis, default_ttl: int | None = None) -> None:
        self.client = client
        self.default_ttl = default_ttl or settings.REDIS_CACHE_TTL

    # ── Key helpers ──
    @staticmethod
    def _key(namespace: str, key: str) -> str:
        return f"molchat:{namespace}:{key}"

    # ── Get / Set ──
    async def get(self, namespace: str, key: str) -> Any | None:
        raw = await self.client.get(self._key(namespace, key))
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return raw

    async def set(
        self,
        namespace: str,
        key: str,
        value: Any,
        ttl: int | None = None,
    ) -> None:
        ttl = ttl or self.default_ttl
        serialized = json.dumps(value, default=str)
        await self.client.set(self._key(namespace, key), serialized, ex=ttl)

    async def delete(self, namespace: str, key: str) -> None:
        await self.client.delete(self._key(namespace, key))

    async def exists(self, namespace: str, key: str) -> bool:
        return bool(await self.client.exists(self._key(namespace, key)))

    # ── Bulk ──
    async def clear_namespace(self, namespace: str) -> int:
        pattern = f"molchat:{namespace}:*"
        count = 0
        async for k in self.client.scan_iter(match=pattern, count=200):
            await self.client.delete(k)
            count += 1
        return count

    # ── Health ──
    async def ping(self) -> bool:
        try:
            return await self.client.ping()
        except Exception:
            return False


async def close_redis_pool() -> None:
    """Close the pool on application shutdown."""
    global _pool
    if _pool is not None:
        await _pool.disconnect()
        _pool = None
```

### File: backend/app/core/security.py

```py

"""
Authentication & authorization utilities.
API-key hashing, JWT creation/verification, dependency guards.
"""

from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader, HTTPBearer
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db

# ── Schemes ──
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)
bearer_scheme = HTTPBearer(auto_error=False)


# ═══════════════════════════════════════════════
# API Key
# ═══════════════════════════════════════════════


def hash_api_key(raw_key: str) -> str:
    """SHA-256 hash of an API key (one-way)."""
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


def generate_api_key(prefix: str = "mc") -> str:
    """Generate a secure random API key with prefix."""
    token = secrets.token_urlsafe(32)
    return f"{prefix}-{token}"


async def verify_api_key(
    api_key: str | None = Security(api_key_header),
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    """Dependency — validate the X-API-Key header against the database."""
    if api_key is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing API key",
        )

    key_hash = hash_api_key(api_key)

    # Import here to avoid circular imports
    from app.models.audit import ApiKey

    stmt = select(ApiKey).where(
        ApiKey.key_hash == key_hash,
        ApiKey.is_active.is_(True),
    )
    result = await db.execute(stmt)
    db_key = result.scalar_one_or_none()

    if db_key is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key",
        )

    return {
        "key_id": str(db_key.id),
        "name": db_key.name,
        "rate_limit": db_key.rate_limit,
    }


# ═══════════════════════════════════════════════
# JWT
# ═══════════════════════════════════════════════


def create_access_token(
    data: dict[str, Any],
    expires_delta: timedelta | None = None,
) -> str:
    """Create a signed JWT access token."""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire, "iat": datetime.now(timezone.utc)})
    return jwt.encode(
        to_encode,
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM,
    )


def decode_access_token(token: str) -> dict[str, Any]:
    """Decode and verify a JWT token."""
    try:
        payload = jwt.decode(
            token,
            settings.JWT_SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        return payload
    except JWTError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
        ) from exc


async def get_current_user(
    credentials: Any = Security(bearer_scheme),
) -> dict[str, Any]:
    """Dependency — extract user info from the Bearer token."""
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authentication token",
        )
    return decode_access_token(credentials.credentials)

def create_api_key(prefix: str = "mc") -> tuple[str, str]:
    """Generate a new API key and return (raw_key, hashed_key) tuple."""
    raw_key = generate_api_key(prefix)
    hashed_key = hash_api_key(raw_key)
    return raw_key, hashed_key

```

### File: backend/app/middleware/auth.py

```py

"""
Authentication middleware.

Strategy:
  1. Public paths bypass authentication entirely.
  2. If ``X-API-Key`` header is present → validate against DB.
  3. If ``Authorization: Bearer <token>`` → validate JWT.
  4. If neither is provided and the path is protected → 401.

Validated identity is attached to ``request.state`` so downstream
handlers and middleware (e.g., rate limiter) can use it.
"""

from __future__ import annotations

import hashlib
from typing import Any

import structlog
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app.core.config import settings

logger = structlog.get_logger(__name__)

# ── Paths that do not require authentication ──
PUBLIC_PATHS: set[str] = {
    "/api/v1/health",
    "/docs",
    "/redoc",
    "/openapi.json",
    "/metrics",
}

PUBLIC_PREFIXES: tuple[str, ...] = (
    "/api/v1/molecules/search",
)


def _is_public(path: str) -> bool:
    """Check if the request path is publicly accessible."""
    if path in PUBLIC_PATHS:
        return True
    for prefix in PUBLIC_PREFIXES:
        if path.startswith(prefix):
            return True
    return False


def _unauthorized(message: str = "Authentication required") -> JSONResponse:
    return JSONResponse(
        status_code=401,
        content={
            "error": "UNAUTHORIZED",
            "message": message,
            "status": 401,
        },
    )


class AuthMiddleware(BaseHTTPMiddleware):
    """Lightweight authentication middleware."""

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        # Initialize auth state
        request.state.authenticated = False
        request.state.auth_method = None
        request.state.api_key_name = None
        request.state.user_info = None
        request.state.rate_limit = settings.RATE_LIMIT_REQUESTS

        path = request.url.path

        # Skip auth for public paths
        if _is_public(path):
            return await call_next(request)

        # Skip auth for WebSocket upgrade (handled at router level)
        if request.headers.get("upgrade", "").lower() == "websocket":
            return await call_next(request)

        # ── Try API Key ──
        api_key = request.headers.get("x-api-key")
        if api_key:
            key_info = await self._validate_api_key(api_key)
            if key_info is not None:
                request.state.authenticated = True
                request.state.auth_method = "api_key"
                request.state.api_key_name = key_info.get("name")
                request.state.rate_limit = key_info.get(
                    "rate_limit", settings.RATE_LIMIT_REQUESTS
                )
                return await call_next(request)
            return _unauthorized("Invalid API key")

        # ── Try Bearer JWT ──
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            user_info = self._validate_jwt(token)
            if user_info is not None:
                request.state.authenticated = True
                request.state.auth_method = "jwt"
                request.state.user_info = user_info
                return await call_next(request)
            return _unauthorized("Invalid or expired token")

        # ── No credentials provided ──
        # In development mode, allow unauthenticated access
        if settings.is_development:
            logger.debug("dev_mode_no_auth", path=path)
            return await call_next(request)

        return _unauthorized()

    async def _validate_api_key(self, raw_key: str) -> dict[str, Any] | None:
        """Validate an API key against the database.

        Returns key metadata dict or None on failure.
        """
        try:
            from app.core.database import async_session_factory
            from app.models.audit import ApiKey
            from sqlalchemy import select, update
            from datetime import datetime, timezone

            key_hash = hashlib.sha256(raw_key.encode("utf-8")).hexdigest()

            async with async_session_factory() as session:
                stmt = select(ApiKey).where(
                    ApiKey.key_hash == key_hash,
                    ApiKey.is_active.is_(True),
                )
                result = await session.execute(stmt)
                db_key = result.scalar_one_or_none()

                if db_key is None:
                    return None

                # Update last_used_at
                await session.execute(
                    update(ApiKey)
                    .where(ApiKey.id == db_key.id)
                    .values(last_used_at=datetime.now(timezone.utc))
                )
                await session.commit()

                return {
                    "key_id": str(db_key.id),
                    "name": db_key.name,
                    "rate_limit": db_key.rate_limit,
                }

        except Exception as exc:
            logger.error("api_key_validation_error", error=str(exc))
            return None

    def _validate_jwt(self, token: str) -> dict[str, Any] | None:
        """Validate a JWT token and return the payload."""
        try:
            from app.core.security import decode_access_token

            return decode_access_token(token)
        except Exception:
            return None
```

### File: frontend/src/lib/api.ts

```ts
const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8333";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options?.headers as Record<string, string>),
    },
    ...options,
  });
  if (!res.ok) {
    const err = await res
      .json()
      .catch(() => ({ message: `HTTP ${res.status}` }));
    throw new Error(
      err.detail || err.message || `Request failed: ${res.status}`,
    );
  }
  return res.json();
}

async function requestText(path: string): Promise<string> {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed: ${res.status}`);
  return res.text();
}

/* ── Types ── */
export interface MoleculeRecord {
  id: string;
  cid: number | null;
  name: string;
  canonical_smiles: string;
  inchi?: string | null;
  inchikey?: string | null;
  molecular_formula?: string | null;
  molecular_weight?: number | null;
  properties?: Record<string, any>;
  structures?: any[];
  computed_properties?: any[];
}

export interface SearchResponse {
  query: string;
  total: number;
  results: MoleculeRecord[];
  sources_queried: string[];
  cache_hit: boolean;
  elapsed_ms: number;
  resolved_query?: string;
  original_query?: string;
  resolve_method?: string;
  resolve_suggestions?: string[];
}

export interface DetailResponse {
  molecule: MoleculeRecord;
  available_formats: string[];
  calculation_status?: string | null;
}

export interface StructureInfo {
  id: string;
  format: string;
  generation_method: string;
  is_primary: boolean;
  data_length: number;
}

export interface SessionItem {
  id: string;
  title: string | null;
  model_used: string | null;
  message_count: number;
  created_at: string;
  updated_at: string;
}

export interface SessionListResponse {
  total: number;
  limit: number;
  offset: number;
  sessions: SessionItem[];
}

export interface ChatMessageResponse {
  id: string;
  session_id: string;
  role: string;
  content: string;
  token_count?: number;
  model_used?: string;
  tool_calls?: Record<string, any>;
  metadata_extra?: Record<string, any>;
  created_at: string;
}

export interface ChatApiResponse {
  session_id: string;
  message: ChatMessageResponse;
  molecules_referenced: Record<string, any>[];
  tool_results: {
    tool: string;
    success: boolean;
    result_preview: string;
    elapsed_ms: number;
  }[];
  confidence?: number;
  hallucination_flags: string[];
  elapsed_ms: number;
}

/* ── API methods ── */
export const api = {
  // Molecules
  searchMolecules: (query: string, limit = 10) =>
    request<SearchResponse>(
      `/api/v1/molecules/search?q=${encodeURIComponent(query)}&limit=${limit}`,
    ),

  getMoleculeDetail: (id: string) =>
    request<DetailResponse>(`/api/v1/molecules/${id}`),

  getStructures: (id: string) =>
    request<StructureInfo[]>(`/api/v1/molecules/${id}/structures`),

  downloadStructure: (id: string, format: string) =>
    requestText(`/api/v1/molecules/${id}/structure/${format}`),

  // Chat
  sendMessage: (message: string, sessionId?: string) =>
    request<ChatApiResponse>("/api/v1/chat", {
      method: "POST",
      body: JSON.stringify({ message, session_id: sessionId }),
    }),

  // Sessions
  listSessions: (params?: { q?: string; limit?: number; offset?: number }) => {
    const sp = new URLSearchParams();
    if (params?.q) sp.set("q", params.q);
    if (params?.limit) sp.set("limit", String(params.limit));
    if (params?.offset) sp.set("offset", String(params.offset));
    const qs = sp.toString();
    return request<SessionListResponse>(
      `/api/v1/chat/sessions${qs ? `?${qs}` : ""}`,
    );
  },

  getSession: (sessionId: string) =>
    request<SessionItem>(`/api/v1/chat/sessions/${sessionId}`),

  getHistory: (sessionId: string, limit = 50) =>
    request<ChatMessageResponse[]>(
      `/api/v1/chat/${sessionId}/history?limit=${limit}`,
    ),

  updateSession: (sessionId: string, title: string) =>
    request<SessionItem>(`/api/v1/chat/sessions/${sessionId}`, {
      method: "PUT",
      body: JSON.stringify({ title }),
    }),

  deleteSession: (sessionId: string) =>
    request<void>(`/api/v1/chat/sessions/${sessionId}`, { method: "DELETE" }),

  healthCheck: () => request<any>("/health"),

  // 3D Structure Generation
  generate3D: (
    smiles: string,
    format: string = "sdf",
    optimizeXtb: boolean = false,
  ) =>
    request<{
      smiles: string;
      format: string;
      structure_data: string;
      generation_method: string;
      atom_count: number;
      properties: Record<string, any> | null;
    }>("/api/v1/molecules/generate-3d", {
      method: "POST",
      body: JSON.stringify({ smiles, format, optimize_xtb: optimizeXtb }),
    }),

  generate3DSdf: (smiles: string) =>
    requestText(
      `/api/v1/molecules/generate-3d/sdf?smiles=\${encodeURIComponent(smiles)}`,
    ),

  // Molecule Card
  getMoleculeCard: (params: { q?: string; cid?: number }) => {
    const sp = new URLSearchParams();
    if (params.q) sp.set("q", params.q);
    if (params.cid) sp.set("cid", String(params.cid));
    return request<import("@/types/moleculeCard").MoleculeCardData>(
      `/api/v1/molecules/card?${sp.toString()}`,
    );
  },
};

// Legacy alias — expose all api methods
// Legacy alias — expose all api methods
export const apiClient = {
  ...api,
};
```

### File: frontend/src/types/chat.ts

```ts
export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system" | "tool";
  content: string;
  timestamp: string;
  model_used?: string;
  token_count?: number;
  toolCalls?: ToolCall[];
  confidence?: number;
  hallucination_flags?: string[];
  moleculeCard?: import("@/types/moleculeCard").MoleculeCardData;
}

export interface ToolCall {
  name: string;
  success?: boolean;
  arguments?: Record<string, any>;
  resultPreview?: string;
  elapsed_ms?: number;
}

export interface ChatResponse {
  session_id: string;
  message: {
    id: string;
    session_id: string;
    role: string;
    content: string;
    token_count?: number;
    model_used?: string;
    tool_calls?: Record<string, any>;
    created_at: string;
  };
  molecules_referenced: Record<string, any>[];
  tool_results: {
    tool: string;
    success: boolean;
    result_preview: string;
    elapsed_ms: number;
  }[];
  confidence?: number;
  hallucination_flags: string[];
  moleculeCard?: import("@/types/moleculeCard").MoleculeCardData;
  elapsed_ms: number;
}

export interface Session {
  id: string;
  title: string | null;
  model_used: string | null;
  message_count: number;
  created_at: string;
  updated_at: string;
}

export interface SessionListResponse {
  total: number;
  limit: number;
  offset: number;
  sessions: Session[];
}
```

### File: frontend/src/types/molecule.ts

```ts
export interface MoleculeRecord {
  id: string;
  cid: number | null;
  name: string;
  canonical_smiles: string;
  inchi?: string | null;
  inchikey?: string | null;
  molecular_formula?: string | null;
  molecular_weight?: number | null;
  properties?: Record<string, any>;
  structures?: any[];
  computed_properties?: any[];
}

export interface MoleculeDetail {
  molecule: MoleculeRecord;
  available_formats: string[];
  calculation_status?: string | null;
}

export interface MoleculeSearchResult {
  query: string;
  total: number;
  limit: number;
  offset: number;
  results: MoleculeRecord[];
  sources_queried: string[];
  cache_hit: boolean;
  elapsed_ms: number;
}
```

### File: frontend/src/types/moleculeCard.ts

```ts
export interface DrugLikenessResult {
  rule_name: string;
  passed: boolean;
  violations: string[];
  details: string;
}

export interface GHSSafety {
  signal_word: string | null;
  pictograms: string[];
  pictogram_urls: string[];
  h_statements: string[];
  p_statements: string[];
  ld50: string | null;
}

export interface SimilarMolecule {
  cid: number;
  name: string;
  similarity: number;
  molecular_formula: string;
  thumbnail_url: string;
}

export interface MoleculeCardData {
  id: string;
  cid: number | null;
  name: string;
  iupac_name: string | null;
  synonyms: string[];
  canonical_smiles: string;
  inchi: string | null;
  inchikey: string | null;
  image_url: string | null;
  molecular_formula: string | null;
  molecular_weight: number | null;
  xlogp: number | null;
  tpsa: number | null;
  hbond_donor: number | null;
  hbond_acceptor: number | null;
  rotatable_bonds: number | null;
  heavy_atom_count: number | null;
  complexity: number | null;
  exact_mass: string | null;
  charge: number | null;
  drug_likeness: DrugLikenessResult[];
  ghs_safety: GHSSafety | null;
  similar_molecules: SimilarMolecule[];
  ai_summary: string | null;
  source: string | null;
  source_url: string | null;
  elapsed_ms: number;
  cached: boolean;
}
```

# MOLCHAT_API_SPEC_V3_FULL.md - Comprehensive Project Specification & Source Archive

> **Status:** Final Audited Version (Enterprise-Grade).
> This document is a complete standalone reference containing the full API specification, business logic, and the **entire source code** of all core components.

---

## 1. API Lookup Table (23 Endpoints)

| #   | Method | Path                                   | Description          | Request Body        | Response Body            | Auth |
| --- | ------ | -------------------------------------- | -------------------- | ------------------- | ------------------------ | :--: |
| 1   | POST   | `/api/v1/chat`                         | General Chat (Sync)  | `ChatRequest`       | `ChatResponse`           |  O   |
| 2   | POST   | `/api/v1/chat/stream`                  | Streaming Chat (SSE) | `ChatRequest`       | SSE (text/event-stream)  |  O   |
| 3   | GET    | `/api/v1/chat/{sid}/history`           | History              | -                   | `list[ChatMessage]`      |  O   |
| 4   | GET    | `/api/v1/chat/sessions`                | List Sessions        | -                   | `SessionListResponse`    |  O   |
| 5   | GET    | `/api/v1/sessions`                     | List (Legacy)        | -                   | `SessionListResponse`    |  O   |
| 6   | POST   | `/api/v1/sessions`                     | Create Session       | `SessionCreate`     | `SessionResponse`        |  O   |
| 7   | PATCH  | `/api/v1/sessions/{id}`                | Rename Session       | `SessionCreate`     | `SessionResponse`        |  O   |
| 8   | DELETE | `/api/v1/sessions/{id}`                | Delete Session       | -                   | `SuccessResponse`        |  O   |
| 9   | GET    | `/api/v1/molecules/search`             | Multi-source Search  | -                   | `MoleculeSearchResponse` |  X   |
| 10  | GET    | `/api/v1/molecules/card`               | Molecule Card        | -                   | `MoleculeCardResponse`   |  O   |
| 11  | POST   | `/api/v1/molecules/generate-3d`        | SMILES -> 3D         | `Generate3DRequest` | `Generate3DResponse`     |  O   |
| 12  | GET    | `/api/v1/molecules/generate-3d/sdf`    | SMILES -> SDF        | -                   | `text/plain`             |  O   |
| 13  | GET    | `/api/v1/molecules/resolve`            | Name -> CID          | -                   | `{"resolved": [...]}`    |  O   |
| 14  | GET    | `/api/v1/molecules/{id}`               | Detail by ID         | -                   | `MoleculeDetailResponse` |  O   |
| 15  | GET    | `/api/v1/molecules/{id}/structures`    | List Versions        | -                   | `list[StructureInfo]`    |  O   |
| 16  | GET    | `/api/v1/molecules/{id}/structure/{f}` | Download File        | -                   | `text/plain`             |  O   |
| 17  | POST   | `/api/v1/molecules/{id}/calculate`     | Submit xTB           | -                   | `{"task_id": "..."}`     |  O   |
| 18  | GET    | `/api/v1/molecules/calculations/{tid}` | Poll Status          | -                   | `{"status": "..."}`      |  O   |
| 19  | POST   | `/api/v1/molecules/compare`            | Multi-Compare        | `smiles_list`       | `ComparisonResult`       |  O   |
| 20  | POST   | `/api/v1/feedback`                     | Submit Feedback      | `FeedbackCreate`    | `SuccessResponse`        |  O   |
| 21  | GET    | `/api/v1/feedback/{sid}`               | Session Feedback     | -                   | `list[Feedback]`         |  O   |
| 22  | GET    | `/api/v1/health`                       | System Health        | -                   | `HealthResponse`         |  X   |
| 23  | GET    | `/api/v1/health/live`                  | Liveness             | -                   | `{"status": "alive"}`    |  X   |

---

## 2. Business Logic & Architecture

### 2.1. The 3-Layer Molecule Engine

- **Layer 0 (Search):** Query -> `QueryResolver` -> `SearchAggregator`.
- **Layer 1 (Structure):** `ConforgeHandler` -> `RDKitHandler` fallback.
- **Layer 2 (Calculation):** `XTBRunner` via `CalculationQueue`.

### 2.2. AI Intelligence (`MolChatAgent`)

- Uses `FallbackRouter` (Gemini -> Ollama).
- Implements `HallucinationGuard` to validate numerical facts.

아 맞다, 다시 이해했습니다. 정정합니다.

**목적이 "API 연동용 룩업테이블"이 아니라, "molchat 프로젝트 자체를 완전히 해부한 기술 보고서"**인 거죠.

즉: AI Agent가 molchat 폴더 전체를 읽고 → 그 내용을 기반으로 → **다른 LLM에게 "이 프로젝트의 모든 것을 분석한 보고서를 써라"라고 시킬 프롬프트**를 생성하게 하는 메타 프롬프트.

---

## 메타 작업지시 프롬프트 (Gemini CLI에 붙여넣기)

````markdown
# 작업지시: molchat 프로젝트 완전 해부 보고서 작성을 위한 프롬프트 생성

## 목적

너는 molchat 프로젝트의 모든 소스코드를 읽고, 그 내용을 바탕으로
**다른 LLM(Claude, GPT 등)에게 붙여넣어서 "molchat 프로젝트 완전 해부 기술 보고서"를 작성시킬 프롬프트**를 생성해야 한다.

최종 산출물은 "프롬프트 1개 (마크다운)"이다. 코드를 수정하거나 고도화하는 것이 아니다.

---

## 1단계: 프로젝트 전체 파일 수집

1. 현재 디렉토리 또는 아래 후보에서 molchat 프로젝트 루트를 찾아라:
   - 현재 위치 (cwd)
   - `~/molchat/`, `~/projects/molchat/`, `~/psid-molchat/`
   - 못 찾으면: `find ~ -maxdepth 4 -name "main.py" -path "*molchat*" 2>/dev/null`

2. 파일 목록 수집:
   ```bash
   find . -type f \( -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.jsx" -o -name "*.tsx" -o -name "*.yaml" -o -name "*.yml" -o -name "*.json" -o -name "*.toml" -o -name "*.env*" -o -name "*.md" -o -name "*.html" -o -name "*.css" -o -name "*.sh" -o -name "Dockerfile*" -o -name "docker-compose*" \) | grep -v node_modules | grep -v __pycache__ | grep -v .git | grep -v dist/ | grep -v build/ | sort
   ```
````

3. 위에서 나온 **모든 파일을 빠짐없이 cat** 해라. 파일 하나당 아래 포맷으로 저장:

   ```
   ===== FILE: [상대경로/파일명] =====
   [파일 내용 전체]
   ===== END FILE =====
   ```

4. 바이너리, 이미지, .pyc, lock 파일은 건너뛰되, 건너뛴 파일 목록은 별도로 기록해라.

---

## 2단계: 프롬프트 생성

1단계에서 수집한 **모든 파일 내용**을 첨부하여, 아래 구조의 프롬프트를 생성해라.
이 프롬프트를 받는 LLM은 molchat 프로젝트에 대해 아무것도 모르는 상태이다.
따라서 **소스코드 전문을 프롬프트 안에 포함**시켜야 한다.

---

### 생성할 프롬프트 템플릿:

```
# 작업지시: molchat 프로젝트 완전 해부 기술 보고서 작성

아래에 molchat이라는 프로젝트의 전체 소스코드가 첨부되어 있다.
이 코드를 완전히 분석하여 아래 구조의 기술 보고서를 작성해라.
추측하지 말고, 코드에서 확인된 사실만 기재하라. 불확실한 부분은 [미확인]으로 표기.

---

## 보고서 구조

### 1. 프로젝트 개요
- 프로젝트명, 목적, 한 줄 요약
- 사용 프레임워크 및 언어 (버전 포함)
- 의존성 패키지 전체 목록 (requirements.txt / pyproject.toml / package.json 기반)
- 실행 방법 (어떻게 서버를 띄우는지)
- 배포 구조 (Docker 사용 여부, 포트, 환경)

### 2. 아키텍처 전체도
- 시스템 구성도 (어떤 컴포넌트가 있고 어떻게 연결되는지)
- 디렉토리 구조와 각 폴더/파일의 역할
- 데이터 흐름: 사용자 입력 → 처리 → 응답까지의 전체 파이프라인
- 프론트엔드 ↔ 백엔드 ↔ 외부서비스 간 통신 구조

### 3. API 엔드포인트 전수 목록
모든 HTTP 엔드포인트를 빠짐없이 나열:

| # | Method | Path | 함수명 | 설명 | Request 스키마 | Response 스키마 | 인증 |
|---|--------|------|--------|------|---------------|----------------|------|

### 4. WebSocket 엔드포인트 (있는 경우)
모든 WS 엔드포인트와 메시지 타입:

| Path | 방향 | type 값 | Payload 구조 | 설명 |
|------|------|---------|-------------|------|

### 5. 데이터 모델 / 스키마
- Pydantic 모델, TypedDict, dataclass, DB 모델 전부
- 각 모델의 필드명, 타입, 필수여부, 설명

### 6. 핵심 알고리즘 및 비즈니스 로직
- 분자 구조 처리 로직 (파싱, 변환, 생성)
- 계산 엔진 연동 방식 (PySCF, RDKit 등)
- LLM 연동 방식 (어떤 모델, 어떤 프롬프트, function calling 사용 여부)
- 자연어 → 구조화 명령 변환 로직 (NLU 파이프라인)
- 캐싱 전략
- 작업 큐 / 비동기 처리 방식

### 7. 외부 서비스 연동
코드에서 호출하는 모든 외부 URL/API:

| 서비스 | URL | 용도 | 호출 위치 (파일:줄) |
|--------|-----|------|-------------------|

### 8. 환경변수 전수 목록

| 변수명 | 용도 | 기본값 | 사용 위치 (파일:줄) |
|--------|------|--------|-------------------|

### 9. 프론트엔드 구조 (있는 경우)
- UI 컴포넌트 구조
- 상태 관리 방식
- 이벤트 흐름 (커스텀 이벤트, 콜백 체인)
- 외부 라이브러리 (3Dmol.js 등)

### 10. 보안 / 인증
- 인증 메커니즘 (JWT, 세션, API key 등)
- 입력 검증 / 새니타이징
- CORS 설정
- 알려진 취약점

### 11. 테스트
- 테스트 파일 목록과 커버리지
- 테스트 실행 방법

### 12. 한계점 및 기술 부채
- 코드에서 발견된 TODO, FIXME, HACK 주석
- 하드코딩된 값
- 미완성 기능
- 성능 병목 후보

---

## 첨부: 소스코드 전문

[여기에 ===== FILE: ... ===== 포맷으로 모든 파일 내용 삽입]
```

---

## 중요 규칙

1. 프롬프트 안에 소스코드 전문이 반드시 포함되어야 한다. 다른 LLM은 이 프로젝트에 접근할 수 없다.
2. 파일을 하나라도 빠뜨리지 마라. `find` 결과와 실제 cat한 파일 수가 일치하는지 끝에 검증 로그를 넣어라.
3. 코드가 너무 길어서 한 번에 못 넣을 경우, "Part 1/N", "Part 2/N" 형태로 분할하되 분할 지점을 명시해라.
4. 프롬프트 생성이 끝나면 맨 끝에 아래 통계를 추가:
   ```
   --- 수집 통계 ---
   총 파일 수: X개
   총 라인 수: X줄
   건너뛴 파일: X개 (목록: ...)
   예상 토큰 수: ~X (1줄 ≈ 15토큰으로 추정)
   분할 필요 여부: 예/아니오
   ```
5. 결과물은 마크다운 코드블록 안에 출력해라. 복사-붙여넣기 한 번으로 끝나게.
   전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ전체 작ㅇ버 엔터프라이즈급으로 ㄱㄱ
