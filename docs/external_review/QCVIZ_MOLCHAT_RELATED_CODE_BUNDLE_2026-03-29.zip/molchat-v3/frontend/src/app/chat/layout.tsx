"use client";
import { useState, useEffect } from "react";
import { PanelLeftClose, PanelLeft } from "lucide-react";
import ChatSidebar from "@/components/chat/ChatSidebar";

export default function ChatLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Detect mobile
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  // Desktop: default open
  useEffect(() => {
    if (!isMobile) setSidebarOpen(true);
  }, [isMobile]);

  // Close sidebar on mobile when session selected
  useEffect(() => {
    if (!isMobile) return;
    const handler = () => setSidebarOpen(false);
    window.addEventListener("molchat:session-changed", handler);
    return () => window.removeEventListener("molchat:session-changed", handler);
  }, [isMobile]);

  return (
    <div className="flex h-[100dvh] overflow-hidden bg-white">
      {/* Mobile overlay */}
      {isMobile && sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/30 animate-fade-in"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={`
          ${isMobile
            ? `fixed inset-y-0 left-0 z-50 w-[280px] transform transition-transform duration-300 ease-out
               ${sidebarOpen ? "translate-x-0 animate-slide-in-left" : "-translate-x-full"}`
            : `${sidebarOpen ? "w-72" : "w-0"} flex-shrink-0 transition-all duration-300 ease-in-out overflow-hidden`
          }
          border-r border-navy-100 bg-white
        `}
      >
        <ChatSidebar onClose={() => setSidebarOpen(false)} />
      </div>

      {/* Main area */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Toggle button */}
        {!sidebarOpen && (
          <button
            onClick={() => setSidebarOpen(true)}
            className="absolute left-2 top-[3.25rem] sm:top-16 z-30 rounded-lg border border-navy-200
                       bg-white p-1.5 text-navy-500 hover:bg-navy-50 hover:text-navy-700
                       transition-colors shadow-sm"
            title="사이드바 열기"
          >
            <PanelLeft size={16} />
          </button>
        )}
        {children}
      </div>
    </div>
  );
}
