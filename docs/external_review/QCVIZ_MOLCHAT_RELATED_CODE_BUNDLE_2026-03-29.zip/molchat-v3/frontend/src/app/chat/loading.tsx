export default function ChatLoading() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-white">
      <div className="flex flex-col items-center gap-4">
        <div className="h-10 w-10 animate-spin rounded-full border-3 border-navy-200 border-t-navy-600" />
        <p className="text-sm text-navy-500 animate-pulse">AI Chat 로딩 중...</p>
      </div>
    </div>
  );
}
