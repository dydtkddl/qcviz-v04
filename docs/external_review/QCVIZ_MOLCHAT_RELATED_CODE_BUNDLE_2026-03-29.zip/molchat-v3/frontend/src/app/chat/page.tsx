"use client";
import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Loader2, Beaker, Atom, ExternalLink, Layers } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import Script from "next/script";
import Header from "@/components/common/Header";
import { api } from "@/lib/api";
import { getApiBase } from "@/lib/runtime-config";
import { SIDEBAR_EVENTS } from "@/components/chat/ChatSidebar";
import MoleculePanel from "@/components/chat/MoleculePanel";
import MoleculeCardFull from "@/components/molecule/MoleculeCardFull";
import type { MoleculeCardData } from "@/types/moleculeCard";

/* ── Types ── */
interface Message {
  id?: string;
  role: "user" | "assistant";
  content: string;
  elapsed?: number;
  molecules?: MolRef[];
  moleculeCard?: MoleculeCardData;
  moleculeCards?: MoleculeCardData[];
  cardsLoading?: number;  // how many cards still loading
  cardLoading?: boolean;
  cardQuery?: string;
  cardError?: string;
  timestamp?: string;
}
interface MolRef {
  name: string;
  cid?: number;
  smiles?: string;
  id?: string;
  familiar_name?: string;
  professional_name?: string;
}

const PROMPTS = [
  "What is the structure of caffeine?",
  "Compare aspirin and ibuprofen",
  "카페인의 분자 구조를 알려줘",
  "Explain the properties of ethanol",
];

/* ── Markdown Components ── */
const mdComponents = {
  table: (props: any) => (
    <div className="my-3 overflow-x-auto rounded-lg border border-navy-200 -mx-1">
      <table className="min-w-full text-xs" {...props} />
    </div>
  ),
  thead: (props: any) => <thead className="bg-navy-50 text-navy-700" {...props} />,
  th: (props: any) => (
    <th className="px-2 sm:px-3 py-1.5 sm:py-2 text-left font-semibold border-b border-navy-200 text-[11px] sm:text-xs" {...props} />
  ),
  td: (props: any) => <td className="px-2 sm:px-3 py-1.5 sm:py-2 border-b border-navy-100 text-[11px] sm:text-xs" {...props} />,
  code: ({ node, inline, className, children, ...props }: any) => {
    const isBlock = !inline && (className || String(children).includes("\n"));
    if (isBlock) {
      return (
        <div className="my-2 overflow-x-auto rounded-lg bg-navy-900 p-2 sm:p-3 text-xs -mx-1">
          <pre className="m-0"><code className={`text-green-300 font-mono ${className || ""}`} {...props}>
            {children}
          </code></pre>
        </div>
      );
    }
    return (
      <code className="rounded bg-navy-100 px-1 py-0.5 text-[11px] sm:text-xs font-mono text-navy-800 break-all" {...props}>
        {children}
      </code>
    );
  },
  ul: (props: any) => <ul className="my-1 ml-3 sm:ml-4 list-disc space-y-0.5" {...props} />,
  ol: (props: any) => <ol className="my-1 ml-3 sm:ml-4 list-decimal space-y-0.5" {...props} />,
  li: (props: any) => <li className="text-xs sm:text-sm leading-relaxed" {...props} />,
  h1: (props: any) => <h1 className="text-base sm:text-lg font-bold mt-3 mb-1 text-navy-900" {...props} />,
  h2: (props: any) => <h2 className="text-sm sm:text-base font-bold mt-3 mb-1 text-navy-900" {...props} />,
  h3: (props: any) => <h3 className="text-xs sm:text-sm font-bold mt-2 mb-1 text-navy-800" {...props} />,
  p: ({ node, children, ...props }: any) => {
    const hasBlock = node?.children?.some((c: any) =>
      c.tagName === "div" || c.tagName === "pre" || c.tagName === "img"
    );
    if (hasBlock) return <div className="text-xs sm:text-sm leading-relaxed mb-2" {...props}>{children}</div>;
    return <p className="text-xs sm:text-sm leading-relaxed mb-2" {...props}>{children}</p>;
  },
  strong: (props: any) => <strong className="font-semibold text-navy-900" {...props} />,
  a: (props: any) => (
    <a className="text-blue-600 underline hover:text-blue-800 break-all" target="_blank" rel="noopener" {...props} />
  ),
  blockquote: (props: any) => (
    <blockquote className="border-l-3 border-navy-300 pl-3 italic text-navy-600 my-2" {...props} />
  ),
  hr: () => <hr className="my-3 border-navy-200" />,
};

/* ── Molecule Mini Chip ── */
function MoleculeChip({ mol }: { mol: MolRef }) {
  const [loading, setLoading] = useState(false);

  const handleClick = async () => {
    if (mol.id) { window.open(`/molchat/molecule/${mol.id}`, "_blank"); return; }
    if (mol.name) {
      setLoading(true);
      try {
        const res = await api.searchMolecules(mol.name, 1);
        if (res.results?.[0]?.id) window.open(`/molchat/molecule/${res.results[0].id}`, "_blank");
      } catch {}
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleClick}
      className="inline-flex items-center gap-1 sm:gap-1.5 rounded-lg border border-cyan-200 bg-cyan-50
                 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-medium text-cyan-800
                 hover:bg-cyan-100 hover:border-cyan-300 transition-all cursor-pointer group
                 active:scale-95"
    >
      <Atom size={12} className="text-cyan-600 group-hover:rotate-180 transition-transform duration-500" />
      <span className="truncate max-w-[120px] sm:max-w-none">{mol.familiar_name || mol.name}</span>
      {mol.cid && <span className="text-cyan-500 text-[9px] sm:text-[10px] hidden sm:inline">CID:{mol.cid}</span>}
      {loading ? (
        <Loader2 size={10} className="animate-spin text-cyan-500" />
      ) : (
        <ExternalLink size={10} className="text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity hidden sm:block" />
      )}
    </button>
  );
}

/* ── Extract molecules from text (for history) ── */
// === Enterprise Molecule Extraction v2 (name-only + backend CID resolution) ===
const SKIP_CATS = new Set([
  'vitamin','vitamins','비타민','mineral','minerals','미네랄','electrolyte','전해질',
  'amino acid','아미노산','protein','단백질','carbohydrate','탄수화물','fat','지방',
  'sugar','당류','nutrient','영양소','antioxidant','항산화제','비타민 B군','비타민 C',
  '비타민 B3','비타민 B5','비타민 B6','비타민 B12','비타민 A','비타민 D','비타민 E','비타민 K',
  '수용성 비타민','지용성 비타민','무기질','유기산','과당','자당','포도당','설탕',
  '칼륨','마그네슘','나트륨','칼슘','인','아연','철','구리','망간','셀레늄','요오드',
]);

interface MolRef {
  name: string;
  cid?: number;
}


// 화면 표시용: MOLECULES 블록 제거

// Enterprise v2: MoleculePanel 용 필터 — 카테고리/개념어 제거
const SKIP_PANEL_NAMES = new Set([
  'polydextrose','polymer','synthetic flavors','tribasic acid','sugar alcohol',
  'lactone ring','lactone','monosaccharide','disaccharide','polysaccharide',
  'carboxylic acid','hydroxyl','amino acid','fatty acid','organic acid',
  'prostaglandin','cox','enzyme','receptor','inhibitor','nsaid',
  '폴리덱스트로스','합성 향료','고분자','삼염기산','당알코올','고리',
  '유기산','단당류','이당류','다당류','카르복실기','수산기','산미료',
  '감미료','비타민','미네랄','전해질','항산화제','보존제','착색료',
  '향료','색소','산화방지제','영양소','수용성','지용성',
  'water','sugar','flavor','coenzyme','cofactor','antioxidant',
  'preservative','sweetener','colorant','nutrient','dietary fiber',
  'vitamin','mineral','electrolyte','ingredient',
]);

function filterPanelMolecules(molecules: any[]): any[] {
  if (!molecules) return [];
  return molecules.filter((mol: any) => {
    const name = (mol.professional_name || mol.name || '').toString();
    const nameLower = name.toLowerCase();
    // 한글만 있는 이름 제외
    if (/^[가-힣\s]+$/.test(name)) return false;
    // 2글자 이하 제외
    if (name.length <= 2) return false;
    // SKIP 목록 제외
    if (SKIP_PANEL_NAMES.has(nameLower)) return false;
    // 일반적인 화학 용어 제외 (영문 소문자로 끝나는 일반 단어)
    if (/^(a |an |the |any )/.test(nameLower)) return false;
    // CID가 있으면 유효한 분자일 가능성 높음 → 통과
    if (mol.cid && Number(mol.cid) > 0) return true;
    // 영문 이름이 3글자 이상이면 통과
    if (/^[A-Za-z]/.test(name) && name.length >= 4) return true;
    return false;
  });
}

function stripMoleculesBlock(text: string): string {
  if (!text) return text;
  return text.replace(/<!--MOLECULES[\s\S]*?MOLECULES-->/g, '').trim();
}

function extractMoleculesFromText(text: string): MolRef[] {
  const molecules: MolRef[] = [];
  const seen = new Set<string>();

  // 1) Primary: Parse structured <!--MOLECULES ... MOLECULES--> block
  const blockMatch = text.match(/<!--MOLECULES\s*([\s\S]*?)\s*MOLECULES-->/);
  if (blockMatch) {
    try {
      const jsonStr = blockMatch[1].trim();
      const arr = JSON.parse(jsonStr);
      if (Array.isArray(arr)) {
        for (const item of arr) {
          const name = (item.name || '').trim();
          const key = name.toLowerCase();
          if (name && !seen.has(key) && !SKIP_CATS.has(key)) {
            seen.add(key);
            // If AI accidentally included CID, ignore it (hallucination risk)
            molecules.push({ name });
          }
        }
        console.log(`[MolParse] structured block: ${molecules.length} molecules`);
      }
    } catch (e) {
      console.warn('[MolParse] JSON parse error in MOLECULES block:', e);
    }
  }

  // 2) Fallback: Extract CID references from text (these are reliable when present in text)
  if (molecules.length === 0) {
    const cidPattern = /(?:PubChem\s+)?CID[:\s]*(\d{3,})/gi;
    let m;
    while ((m = cidPattern.exec(text)) !== null) {
      const cid = parseInt(m[1], 10);
      const key = `cid_${cid}`;
      if (!seen.has(key)) {
        seen.add(key);
        molecules.push({ name: `CID ${cid}`, cid });
      }
    }
    console.log(`[MolParse] fallback CID extraction: ${molecules.length} molecules`);
  }

  return molecules.slice(0, 10); // Max 10 molecules
}

// Resolve molecule names to CIDs via backend (which queries PubChem)
async function resolveMoleculeNames(mols: MolRef[]): Promise<MolRef[]> {
  const needsResolution = mols.filter(m => !m.cid);
  const alreadyResolved = mols.filter(m => m.cid);

  if (needsResolution.length === 0) return mols;

  try {
    const names = needsResolution.map(m => m.name).join(',');
    const resp = await fetch(
      `${getApiBase()}/api/v1/molecules/resolve?names=${encodeURIComponent(names)}`
    );
    if (resp.ok) {
      const data = await resp.json();
      const resolvedMap = new Map<string, number>();
      for (const item of data.resolved || []) {
        resolvedMap.set(item.name.toLowerCase(), item.cid);
      }
      // Merge resolution results
      const resolved: MolRef[] = [];
      for (const mol of needsResolution) {
        const cid = resolvedMap.get(mol.name.toLowerCase());
        if (cid) {
          resolved.push({ name: mol.name, cid });
        } else {
          // Keep name-only for name-based card fetch fallback
          resolved.push({ name: mol.name });
        }
      }
      console.log(`[MolResolve] ${resolved.filter(m => m.cid).length}/${needsResolution.length} names resolved to CIDs`);
      return [...alreadyResolved, ...resolved];
    }
  } catch (e) {
    console.warn('[MolResolve] Backend resolution failed, falling back to name-based fetch:', e);
  }
  return mols; // Return original on failure
}
// === End Enterprise Molecule Extraction v2 ===

function CardCarousel({ cards, isLoading = false, totalExpected = 0, onMoleculeClick }: { cards: MoleculeCardData[]; isLoading?: boolean; totalExpected?: number; onMoleculeClick?: (cid: number) => void }) {
  const [idx, setIdx] = useState(0);
  const total = cards.length;
  const hasPrev = idx > 0;
  const hasNext = idx < total - 1;

  return (
    <div className="relative">
            {isLoading && totalExpected > cards.length && (
              <div className="absolute inset-0 z-20 flex items-center justify-center bg-white/60 backdrop-blur-sm rounded-2xl">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-6 h-6 border-2 border-navy-200 border-t-cyan-500 rounded-full animate-spin" />
                  <span className="text-xs text-navy-500">{cards.length}/{totalExpected} 카드 로딩중...</span>
                </div>
              </div>
            )}
            
      {/* Left arrow */}
      {hasPrev && (
        <button
          onClick={() => setIdx((i) => Math.max(0, i - 1))}
          className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 z-10 w-8 h-8 rounded-full bg-white/90 border border-navy-200 shadow-md flex items-center justify-center hover:bg-navy-50 transition-colors"
          aria-label="이전 분자"
        >
          <svg className="w-4 h-4 text-navy-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        </button>
      )}

      {/* Right arrow */}
      {hasNext && (
        <button
          onClick={() => setIdx((i) => Math.min(total - 1, i + 1))}
          className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 z-10 w-8 h-8 rounded-full bg-white/90 border border-navy-200 shadow-md flex items-center justify-center hover:bg-navy-50 transition-colors"
          aria-label="다음 분자"
        >
          <svg className="w-4 h-4 text-navy-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
        </button>
      )}

      {/* Card */}
      <MoleculeCardFull
        data={cards[idx]}
        onMoleculeClick={onMoleculeClick}
      />

      {/* Dot indicators */}
      {total > 1 && (
        <div className="flex items-center justify-center gap-1.5 mt-2">
          {cards.map((c, i) => (
            <button
              key={c.cid || i}
              onClick={() => setIdx(i)}
              className={`transition-all duration-200 rounded-full ${
                i === idx
                  ? "w-6 h-2 bg-navy-500"
                  : "w-2 h-2 bg-navy-200 hover:bg-navy-300"
              }`}
              aria-label={c.name || `분자 ${i + 1}`}
              title={c.name || `분자 ${i + 1}`}
            />
          ))}
          <span className="ml-2 text-[10px] text-navy-400">{idx + 1} / {total}</span>
        </div>
      )}
    </div>
  );
}

function extractAllMolecules(messages: Message[]): MolRef[] {
  const seen = new Set<string>();
  const SKIP_CATEGORIES = new Set([
    "vitamins","minerals","electrolytes","nutrients","supplements",
    "b vitamins","amino acids","proteins","enzymes","hormones",
    "당류","미네랄","비타민","비타민 b군","전해질","영양소",
    "sweeteners","colorants","natural flavors","천연 향료","색소",
    "water","물","dietary fiber","식이섬유","antioxidants",
  ]);
  const result: MolRef[] = [];
  for (const msg of messages) {
    if (msg.molecules) {
      for (const mol of msg.molecules) {
        const key = mol.name?.toLowerCase() || mol.smiles || "";
        if (key && !seen.has(key)) { seen.add(key); result.push(mol); }
      }
    }
  }
  return result;
}

/* ── Main Chat Page ── */
export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const messagesRef = useRef<any[]>([]);

  const allMolecules = extractAllMolecules(messages).map(m => {
    // "CID 938" 같은 이름은 MoleculePanel에서 CID로 직접 조회하도록 유지
    // 하지만 displayName은 카드 응답에서 가져온 이름으로 업데이트
    const cards = messages.flatMap(msg => msg.moleculeCards || []);
    if (m.cid) {
      const card = cards.find(c => c.cid === Number(m.cid));
      if (card?.name) {
        return { ...m, name: card.name, familiar_name: card.name, professional_name: card.name };
      }
    }
    return m;
  });

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const loadHistory = useCallback(async (sid: string) => {
    console.log("[loadHistory] called with sid:", sid);
    setLoadingHistory(true);
    try {
      const history = await api.getHistory(sid);
      const msgs: Message[] = history.map((m) => ({
        id: m.id,
        role: m.role as "user" | "assistant",
        content: m.content,
        timestamp: m.created_at,
        molecules: m.role === "assistant" ? extractMoleculesFromText(m.content || "") : undefined,
      }));
      console.log("[loadHistory] msgs loaded:", msgs.length, msgs.map(m => m.role));
      setMessages(msgs);

        // Enterprise v2: Restore molecule cards from history
        // Parse MOLECULES blocks from assistant messages and fetch cards
        setTimeout(async () => {
          try {
            // Get current messages from state via a temporary getter
            let historyMsgs: any[] = [];
            setMessages(prev => { historyMsgs = prev; return prev; });
            // Small delay to ensure state is settled
            await new Promise(r => setTimeout(r, 100));
            if (historyMsgs.length === 0) {
              setMessages(prev => { historyMsgs = prev; return prev; });
            }
            for (let i = 0; i < historyMsgs.length; i++) {
              const msg = historyMsgs[i];
              if (msg.role === 'assistant' && msg.content && !msg.moleculeCards?.length) {
                const histMols = extractMoleculesFromText(msg.content);
                if (histMols.length > 0) {
                  const resolved = await resolveMoleculeNames(histMols);
                  const targets = resolved.filter(m => m.cid || m.name);
                  if (targets.length > 0) {
                    const cardPromises = targets.map(t =>
                      t.cid
                        ? api.getMoleculeCard({ cid: t.cid }).catch(() => null)
                        : api.getMoleculeCard({ q: t.name }).catch(() => null)
                    );
                    const results = await Promise.allSettled(cardPromises);
                    const cards = results
                      .filter((r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled' && Boolean(r.value))
                      .map(r => r.value);
                    if (cards.length > 0) {
                      setMessages(prev => prev.map((m, idx) =>
                        idx === i ? { ...m, moleculeCards: cards, moleculeCard: cards[0] } : m
                      ));
                      console.log(`[loadHistory] Restored ${cards.length} cards for message ${i}`);
                    }
                  }
                }
              }
            }
          } catch (e) {
            console.warn('[loadHistory] Card restoration error:', e);
          }
        }, 500);

      // Restore molecule card for the LAST assistant message
      for (let idx = msgs.length - 1; idx >= 0; idx--) {
        const msg = msgs[idx];
        if (msg.role !== "assistant") continue;
        const text = msg.content || "";

        // Build candidate list: CID from text → molecules with CID → user query
        const candidates: { q?: string; cid?: number }[] = [];

        // 1. CID from text
        const cidMatch = text.match(/(?:PubChem\s+)?CID[:\s]*[*`]*(\d{2,})/i);
        if (cidMatch) candidates.push({ cid: Number(cidMatch[1]) });

        // 2. Molecules with CID
        const mols = msg.molecules || [];
        for (const mol of mols) {
          if (mol.cid) candidates.push({ cid: Number(mol.cid), q: mol.professional_name || mol.name });
        }

        // 3. Molecule names (filtered)
        const SKIP = new Set(["donor","acceptor","purine","pyrimidine","enzyme","protein","receptor","inhibitor","fiber","water","sugar","syrup"]);
        for (const mol of mols) {
          const name = mol.professional_name || mol.name || "";
          if (name.length >= 3 && !SKIP.has(name.toLowerCase())) {
            candidates.push({ q: name });
          }
        }

        // 4. User query fallback
        const userQ = msgs.find((m) => m.role === "user")?.content?.trim() || "";
        if (userQ) {
          const words = userQ.replace(/[가-힣\s]+/g, " ").trim().split(/\s+/);
          const eng = words.find((w) => /^[A-Za-z]{3,}/.test(w));
          if (eng && !SKIP.has(eng.toLowerCase())) candidates.push({ q: eng });
        }

        if (candidates.length === 0) continue;

        // Try candidates sequentially until one succeeds
        const restoreIdx = idx;
        const loadingName = candidates[0]?.q || (candidates[0]?.cid ? `CID ${candidates[0].cid}` : "");
        setMessages((prev) =>
          prev.map((m, i) => (i === restoreIdx ? { ...m, cardLoading: true, cardQuery: loadingName } : m))
        );

        const tryCandidate = async (i: number) => {
          if (i >= candidates.length) {
            // All failed — show error
            setMessages((prev) =>
              prev.map((m, j) => (j === restoreIdx ? { ...m, cardLoading: false, cardError: "이 대화의 분자 카드를 불러올 수 없습니다" } : m))
            );
            return;
          }
          try {
            const cardData = await api.getMoleculeCard(candidates[i]);
            if (cardData && cardData.cid) {
              setMessages((prev) =>
                prev.map((m, j) =>
                  j === restoreIdx && m.role === "assistant"
                    ? { ...m, moleculeCard: cardData, cardLoading: false }
                    : m
                )
              );
            } else {
              await tryCandidate(i + 1);
            }
          } catch {
            await tryCandidate(i + 1);
          }
        };
        tryCandidate(0);
        break; // only restore the last one
      }
    } catch (err) { console.error("[loadHistory] FAILED:", err); setMessages([]); }
    finally { setLoadingHistory(false); }
  }, []);

  useEffect(() => {
    const handleSessionChanged = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      const newSessionId = detail?.sessionId || null;
      setSessionId(newSessionId);
      setPanelOpen(false);
      if (newSessionId) loadHistory(newSessionId);
      else setMessages([]);
    };
    window.addEventListener(SIDEBAR_EVENTS.SESSION_CHANGED, handleSessionChanged as EventListener);
    return () => window.removeEventListener(SIDEBAR_EVENTS.SESSION_CHANGED, handleSessionChanged as EventListener);
  }, [loadHistory]);

  const send = async (text?: string) => {
    const msg = (text || input).trim();
    if (!msg || loading) return;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: msg }]);
    setLoading(true);

    try {
      const t0 = performance.now();
      const res = await api.sendMessage(msg, sessionId || undefined);
      const elapsed = performance.now() - t0;

      const newSessionId = res.session_id;
      if (!sessionId && newSessionId) {
        setSessionId(newSessionId);
        window.dispatchEvent(new CustomEvent(SIDEBAR_EVENTS.SESSION_CREATED, { detail: { sessionId: newSessionId } }));
      } else {
        window.dispatchEvent(new CustomEvent(SIDEBAR_EVENTS.REFRESH_SIDEBAR));
      }

      let content = "No response";
      if (res?.message?.content && typeof res.message.content === "string") content = res.message.content;

      const molecules: MolRef[] = (res?.molecules_referenced || []).map((m: any) => ({
        name: m.name || m.canonical_smiles || "Unknown",
        familiar_name: m.familiar_name || m.name || "Unknown",
        professional_name: m.professional_name || m.name || "",
        cid: m.cid, smiles: m.canonical_smiles, id: m.id,
      }));

      // Enterprise v2: Resolve server-provided molecule names to verified CIDs
      let resolvedMolecules = molecules;
      try {
        const serverNeedResolve = molecules.filter(m => !m.cid && m.name);
        if (serverNeedResolve.length > 0) {
          resolvedMolecules = await resolveMoleculeNames(molecules);
          console.log('[MolResolve] server molecules resolved:', resolvedMolecules.map(m => ({name:m.name,cid:m.cid})));
        }
      } catch (e) {
        console.warn('[MolResolve] server resolution failed:', e);
      }

      setMessages((prev) => [...prev, { role: "assistant", content: displayContent, elapsed, molecules }]);

      // Fetch Molecule Card — find the first molecule with a CID, or try the first one      // === Fetch ALL molecule cards in parallel (v2) ===
      // 소스 1: 서버의 molecules_referenced (CID 포함)
      // 소스 2: AI 응답 텍스트에서 CID 추출
      
      // ── MOLECULES 블록을 사용자 표시 텍스트에서 제거 ──
      const displayContent = content.replace(/<!--MOLECULES[\s\S]*?MOLECULES-->/g, "").trim();
      const textCidMols = extractMoleculesFromText(content);

      // Enterprise v2: Resolve names to verified PubChem CIDs
      let resolvedTextMols = textCidMols;
      try {
        const needResolve = textCidMols.filter(m => !m.cid && m.name);
        if (needResolve.length > 0) {
          resolvedTextMols = await resolveMoleculeNames(textCidMols);
          console.log('[MolResolve] text molecules resolved:', resolvedTextMols.map(m => ({name:m.name,cid:m.cid})));
        }
      } catch (e) {
        console.warn('[MolResolve] resolution failed, using original:', e);
      }
      const allMols = [...resolvedMolecules, ...textCidMols];

      // 중복 제거 (CID 기준)
      const cidSet = new Set<number>();
      const nameSet = new Set<string>();
      const dedupedMols: MolRef[] = [];
      for (const mol of allMols) {
        if (mol.cid) {
          if (!cidSet.has(Number(mol.cid))) {
            cidSet.add(Number(mol.cid));
            dedupedMols.push(mol);
          }
        } else {
          const n = (mol.professional_name || mol.name || "").toLowerCase();
          // Enterprise v2: 강화된 필터
          // 1) CAS 번호 패턴 제외 (예: 51146-56-6, 58560-75-1)
          const isCAS = /^\d{2,7}-\d{2}-\d$/.test(n);
          // 2) 한글 이름 제외
          const isKorean = /[가-힣]/.test(n);
          // 3) 순수 숫자 제외
          const isNumeric = /^\d+$/.test(n);
          // 4) 너무 짧거나 일반적인 용어 제외
          const SKIP_QUERY = new Set(["b vitamins","vitamins","minerals","electrolytes","nutrients","supplements","compounds","proteins","enzymes","hormones","acids","salts","potassium","zinc","calcium","magnesium","sodium","selenium","iron","coenzyme","cofactor","antioxidant","collagen","dietary fiber","polydextrose","ingredient","ingredients","water","sugar","glucose","fructose","sucrose"]);
          if (n.length >= 3 && /^[a-z]/.test(n) && !isKorean && !isCAS && !isNumeric && !nameSet.has(n) && !SKIP_QUERY.has(n)) {
            nameSet.add(n);
            dedupedMols.push(mol);
          }
        }
      }

      const fetchTargets = dedupedMols.slice(0, 8);
      console.log("[CardFetch] molecules:", molecules.length, "textCids:", textCidMols.length, "deduped:", fetchTargets.length);
      console.log("[CardFetch] targets:", fetchTargets.map(m => ({name:m.name,cid:m.cid})));

      if (fetchTargets.length > 0) {
        // Show loading state
        setMessages((prev) =>
          prev.map((m, idx) =>
            idx === prev.length - 1 && m.role === "assistant"
              ? { ...m, cardLoading: true, cardsLoading: fetchTargets.length, cardQuery: fetchTargets[0]?.name || `CID ${fetchTargets[0]?.cid}` }
              : m
          )
        );

        // Fetch all cards in parallel
        // CID가 있는 것만 우선 fetch (CID 없는 이름 기반은 별도 처리)
        const cidTargets = fetchTargets.filter((mol) => mol.cid && Number(mol.cid) > 0);
        const nameTargets = fetchTargets.filter((mol) => !mol.cid && (mol.professional_name || mol.name));
        
        // CID 기반 fetch (가장 신뢰할 수 있음)
        const cidPromises = cidTargets.map((mol) =>
          api.getMoleculeCard({ cid: Number(mol.cid) }).catch((err) => {
            console.warn("[CardFetch] CID fetch failed:", mol.cid, err.message);
            return null;
          })
        );
        
        // 이름 기반 fetch (fallback, 최대 3개만)
        const namePromises = nameTargets.slice(0, 3).map((mol) =>
          api.getMoleculeCard({ q: mol.professional_name || mol.name }).catch((err) => {
            console.warn("[CardFetch] name fetch failed:", mol.name, err.message);
            return null;
          })
        );
        
        const cardPromises = [...cidPromises, ...namePromises];

        Promise.allSettled(cardPromises).then((results) => {
          console.log("[CardFetch] results:", results.length, results.map(r => r.status));
          const cards: MoleculeCardData[] = results
            .map((r) => r.status === "fulfilled" ? r.value : null)
            .filter((c): c is MoleculeCardData => c !== null && !!c.cid);

          // Deduplicate by CID
          const seenCids = new Set<number>();
          const uniqueCards = cards.filter((c) => {
            if (seenCids.has(c.cid!)) return false;
            seenCids.add(c.cid!);
            return true;
          });

          console.log("[CardFetch] uniqueCards:", uniqueCards.length, uniqueCards.map(c => ({name:c.name,cid:c.cid})));
          setMessages((prev) =>
            prev.map((m, idx) =>
              idx === prev.length - 1 && m.role === "assistant"
                ? {
                    ...m,
                    moleculeCard: uniqueCards[0] || undefined,
                    moleculeCards: uniqueCards.length > 0 ? uniqueCards : undefined,
                    cardLoading: false,
                    cardsLoading: 0,
                  }
                : m
            )
          );
        });
      }
    } catch (err: any) {
      const errMsg = typeof err?.message === "string" ? err.message : "Unknown error";
      setMessages((prev) => [...prev, { role: "assistant", content: `Error: ${errMsg}` }]);
    } finally { setLoading(false); }
  };

  return (
    <>
      <Script src="https://3Dmol.org/build/3Dmol-min.js" strategy="lazyOnload" />

      <div className="flex h-full flex-col bg-white">
        <Header />
        <div className="flex flex-1 flex-col mx-auto w-full max-w-3xl min-h-0">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-3 sm:px-4 py-4 sm:py-6 space-y-3 sm:space-y-4 overscroll-contain">
            {loadingHistory ? (
              <div className="flex flex-col items-center justify-center gap-3 py-20">
                <Loader2 size={24} className="animate-spin text-cyan-500" />
                <p className="text-sm text-navy-400">대화 기록 불러오는 중...</p>
              </div>
            ) : messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center gap-4 sm:gap-6 py-12 sm:py-20">
                <div className="flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-2xl bg-navy-900">
                  <Beaker className="text-cyan-400" size={24} />
                </div>
                <div className="text-center px-4">
                  <h2 className="text-lg sm:text-xl font-bold text-navy-900">MolChat AI</h2>
                  <p className="mt-1.5 sm:mt-2 text-xs sm:text-sm text-navy-500">
                    분자 구조, 특성, 비교 등 무엇이든 물어보세요.
                  </p>
                </div>
                <div className="grid gap-2 grid-cols-1 sm:grid-cols-2 max-w-lg w-full px-4">
                  {PROMPTS.map((p) => (
                    <button
                      key={p}
                      onClick={() => send(p)}
                      className="rounded-lg border border-navy-200 px-3 py-2 sm:py-2.5 text-left text-xs sm:text-sm text-navy-600
                                 hover:bg-navy-50 hover:border-navy-300 transition-colors active:scale-[0.98]"
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((msg, i) => (
                <div key={msg.id || i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[95%] sm:max-w-[90%] rounded-xl px-3 py-2.5 sm:px-4 sm:py-3 ${
                      msg.role === "user"
                        ? "bg-navy-800 text-white rounded-br-md"
                        : "bg-white text-navy-900 border border-navy-100 rounded-bl-md shadow-sm"
                    }`}
                  >
                    {msg.role === "user" ? (
                      <p className="text-xs sm:text-sm whitespace-pre-wrap">{stripMoleculesBlock(msg.content || "")}</p>
                    ) : (
                      <div className="prose-sm max-w-none">
                        <ReactMarkdown remarkPlugins={[remarkGfm]} components={mdComponents}>
                          {stripMoleculesBlock(msg.content || "")}
                        </ReactMarkdown>
                      </div>
                    )}

                    {/* Molecule Card Full / Loading / Error */}
                    {(msg.moleculeCards || msg.moleculeCard || msg.cardLoading || msg.cardError) && (
                      <div className="mt-3 sm:mt-4">
                        {(msg.moleculeCards && msg.moleculeCards.length > 1) ? (
                          <CardCarousel
                            cards={msg.moleculeCards}
                  isLoading={msg.cardLoading || false}
                  totalExpected={msg.cardsLoading || 0}
                            onMoleculeClick={(cid) => {
                              window.open(`/molchat/molecule/${cid}`, "_blank");
                            }}
                          />
                        ) : (msg.moleculeCards?.[0] || msg.moleculeCard) ? (
                          <MoleculeCardFull
                            data={msg.moleculeCards?.[0] || msg.moleculeCard}
                            onMoleculeClick={(cid) => {
                              window.open(`/molchat/molecule/${cid}`, "_blank");
                            }}
                          />
                        ) : msg.cardLoading ? (
                          <div>
                            <MoleculeCardFull loading={true} />
                            {(msg.cardsLoading ?? 0) > 1 && (
                              <p className="text-[10px] text-navy-400 text-center mt-1">
                                {msg.cardsLoading}개 분자 카드 로딩 중...
                              </p>
                            )}
                          </div>
                        ) : msg.cardError ? (
                          <div className="bg-navy-50/50 rounded-xl border border-navy-200/50 p-3 flex items-center gap-2">
                            <svg className="w-4 h-4 text-navy-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <span className="text-xs text-navy-500">{msg.cardError}</span>
                          </div>
                        ) : null}
                      </div>
                    )}

                    {/* Referenced Molecules chips (fallback if no card) */}
                    {!msg.moleculeCards && !msg.moleculeCard && !msg.cardLoading && msg.molecules && msg.molecules.length > 0 && (
                      <div className="mt-2 sm:mt-3 pt-2 sm:pt-3 border-t border-navy-100">
                        <p className="text-[9px] sm:text-[10px] font-medium text-navy-400 uppercase tracking-wide mb-1.5 sm:mb-2">
                          Referenced Molecules
                        </p>
                        <div className="flex flex-wrap gap-1 sm:gap-1.5">
                          {msg.molecules.map((mol, j) => (
                            <MoleculeChip key={j} mol={mol} />
                          ))}
                        </div>
                      </div>
                    )}

                    {msg.elapsed != null && (
                      <p className="mt-1.5 sm:mt-2 text-[9px] sm:text-[10px] text-navy-400">
                        {(msg.elapsed / 1000).toFixed(1)}s
                      </p>
                    )}
                  </div>
                </div>
              ))
            )}

            {loading && (
              <div className="flex justify-start">
                <div className="rounded-xl bg-white border border-navy-100 px-3 sm:px-4 py-2.5 sm:py-3 rounded-bl-md shadow-sm">
                  <div className="flex items-center gap-2">
                    <Loader2 size={14} className="animate-spin text-cyan-500" />
                    <span className="text-xs text-navy-400">분석 중...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Input area */}
          <div className="border-t border-navy-100 px-3 sm:px-4 py-2.5 sm:py-3 bg-white safe-bottom">
            <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-1.5 sm:gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="분자에 대해 물어보세요..."
                className="flex-1 rounded-xl border border-navy-200 bg-navy-50 px-3 sm:px-4 py-2.5
                           text-sm placeholder:text-navy-400 focus:outline-none focus:ring-2
                           focus:ring-cyan-500/30 focus:border-cyan-400 transition-colors"
                disabled={loading}
              />

              {allMolecules.length > 0 && (
                <button
                  type="button"
                  onClick={() => setPanelOpen(true)}
                  className="relative rounded-xl border border-cyan-300 bg-cyan-50 px-2.5 sm:px-3 py-2.5
                             text-cyan-700 hover:bg-cyan-100 hover:border-cyan-400 transition-colors
                             flex items-center gap-1 active:scale-95"
                  title="구조 확인"
                >
                  <Layers size={16} />
                  <span className="text-xs font-medium hidden sm:inline">구조</span>
                  <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center
                                   rounded-full bg-cyan-500 text-[9px] font-bold text-white shadow-sm">
                    {allMolecules.length}
                  </span>
                </button>
              )}

              <button
                type="submit"
                disabled={loading || !input.trim()}
                className="rounded-xl bg-navy-800 px-3 sm:px-4 py-2.5 text-white hover:bg-navy-700
                           disabled:opacity-40 disabled:cursor-not-allowed transition-colors active:scale-95"
              >
                <Send size={16} />
              </button>
            </form>
            {sessionId && (
              <p className="mt-1 sm:mt-1.5 text-center text-[9px] sm:text-[10px] text-navy-300">
                세션: {sessionId.slice(0, 8)}...
              </p>
            )}
          </div>
        </div>
      </div>

      <MoleculePanel
        molecules={filterPanelMolecules(
          allMolecules.filter((m) => {
            const n = (m.name || m.familiar_name || "").toLowerCase();
            const SKIP_MOL = new Set([
              "vitamins", "minerals", "electrolytes", "nutrients", "supplements",
              "b vitamins", "amino acids", "proteins", "enzymes", "hormones",
              "당류", "미네랄", "비타민", "비타민 b군", "전해질", "영양소",
              "sweeteners", "colorants", "natural flavors", "천연 향료", "색소",
              "water", "물",
            ]);
            return !SKIP_MOL.has(n);
          })
        )}
        open={panelOpen}
        onClose={() => setPanelOpen(false)}
      />
    </>
  );
}
