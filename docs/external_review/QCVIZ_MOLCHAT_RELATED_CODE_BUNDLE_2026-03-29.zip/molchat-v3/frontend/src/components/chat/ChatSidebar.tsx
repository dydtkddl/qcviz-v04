"use client";
import { useEffect, useState, useCallback, useRef } from "react";
import {
  Plus, MessageCircle, Search, Trash2,
  PanelLeftClose, X, Pencil, Check,
} from "lucide-react";
import { api, SessionItem } from "@/lib/api";

function getDateGroup(dateStr: string): string {
  const d = new Date(dateStr);
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - d.getTime()) / 86400000);
  if (diffDays === 0) return "오늘";
  if (diffDays === 1) return "어제";
  if (diffDays <= 7) return "지난 7일";
  if (diffDays <= 30) return "지난 30일";
  return d.toLocaleDateString("ko-KR", { year: "numeric", month: "long" });
}

function groupSessions(sessions: SessionItem[]): Map<string, SessionItem[]> {
  const groups = new Map<string, SessionItem[]>();
  for (const s of sessions) {
    const group = getDateGroup(s.updated_at);
    if (!groups.has(group)) groups.set(group, []);
    groups.get(group)!.push(s);
  }
  return groups;
}

interface ChatSidebarProps { onClose: () => void; }

const SIDEBAR_EVENTS = {
  SESSION_CHANGED: "molchat:session-changed",
  SESSION_CREATED: "molchat:session-created",
  REFRESH_SIDEBAR: "molchat:refresh-sidebar",
};
export { SIDEBAR_EVENTS };

export default function ChatSidebar({ onClose }: ChatSidebarProps) {
  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const loadSessions = useCallback(async (q?: string) => {
    try {
      setLoading(true);
      const data = await api.listSessions({ q: q || undefined, limit: 50 });
      setSessions(data.sessions);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => {
    loadSessions();
    const handleRefresh = () => loadSessions();
    const handleCreated = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail?.sessionId) setActiveSessionId(detail.sessionId);
      loadSessions();
    };
    window.addEventListener(SIDEBAR_EVENTS.REFRESH_SIDEBAR, handleRefresh);
    window.addEventListener(SIDEBAR_EVENTS.SESSION_CREATED, handleCreated as EventListener);
    return () => {
      window.removeEventListener(SIDEBAR_EVENTS.REFRESH_SIDEBAR, handleRefresh);
      window.removeEventListener(SIDEBAR_EVENTS.SESSION_CREATED, handleCreated as EventListener);
    };
  }, [loadSessions]);

  useEffect(() => {
    const timer = setTimeout(() => loadSessions(searchQuery), 300);
    return () => clearTimeout(timer);
  }, [searchQuery, loadSessions]);

  useEffect(() => {
    if (searchOpen) searchInputRef.current?.focus();
  }, [searchOpen]);

  const handleSelect = (session: SessionItem) => {
    setActiveSessionId(session.id);
    window.dispatchEvent(
      new CustomEvent(SIDEBAR_EVENTS.SESSION_CHANGED, {
        detail: { sessionId: session.id, title: session.title },
      })
    );
  };

  const handleNewChat = () => {
    setActiveSessionId(null);
    window.dispatchEvent(
      new CustomEvent(SIDEBAR_EVENTS.SESSION_CHANGED, {
        detail: { sessionId: null, title: null },
      })
    );
  };

  const handleRename = async (id: string) => {
    if (!editTitle.trim()) { setEditingId(null); return; }
    try {
      await api.updateSession(id, editTitle.trim());
      setSessions((prev) => prev.map((s) => (s.id === id ? { ...s, title: editTitle.trim() } : s)));
    } catch {}
    setEditingId(null);
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteSession(id);
      setSessions((prev) => prev.filter((s) => s.id !== id));
      if (activeSessionId === id) handleNewChat();
    } catch {}
    setDeletingId(null);
  };

  const grouped = groupSessions(sessions);

  return (
    <div className="flex h-full w-[280px] md:w-72 flex-col bg-slate-50">
      {/* Header */}
      <div className="flex items-center justify-between px-3 pt-3 pb-2">
        <h2 className="text-sm font-semibold text-navy-800">대화 기록</h2>
        <button
          onClick={onClose}
          className="rounded-md p-1.5 text-navy-400 hover:bg-navy-100 hover:text-navy-600
                     transition-colors active:scale-95"
          title="사이드바 닫기"
        >
          <PanelLeftClose size={16} />
        </button>
      </div>

      {/* New chat + Search */}
      <div className="px-3 pb-2 space-y-2">
        <button
          onClick={handleNewChat}
          className="flex w-full items-center gap-2 rounded-lg border border-navy-200 bg-white
                     px-3 py-2.5 text-sm font-medium text-navy-700 transition-colors
                     hover:border-cyan-400 hover:bg-cyan-50 hover:text-cyan-700
                     active:scale-[0.98] shadow-sm"
        >
          <Plus size={15} />
          새 대화
        </button>

        <div className="relative">
          {searchOpen ? (
            <div className="flex items-center gap-1.5 rounded-lg border border-navy-200 bg-white px-2.5 py-2">
              <Search size={13} className="text-navy-400 shrink-0" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="대화 검색..."
                className="flex-1 bg-transparent text-xs text-navy-800 placeholder:text-navy-400 focus:outline-none"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery("")} className="text-navy-400 hover:text-navy-600 p-0.5">
                  <X size={12} />
                </button>
              )}
              <button onClick={() => { setSearchOpen(false); setSearchQuery(""); }} className="text-navy-400 hover:text-navy-600 p-0.5">
                <X size={13} />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setSearchOpen(true)}
              className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs
                         text-navy-500 hover:bg-navy-100 hover:text-navy-700 transition-colors"
            >
              <Search size={13} />
              대화 검색
            </button>
          )}
        </div>
      </div>

      {/* Session list */}
      <div className="flex-1 overflow-y-auto px-2 pb-3 overscroll-contain">
        {loading && sessions.length === 0 ? (
          <div className="flex items-center justify-center py-8">
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-navy-300 border-t-cyan-500" />
          </div>
        ) : sessions.length === 0 ? (
          <p className="px-3 py-6 text-center text-xs text-navy-400">
            {searchQuery ? `"${searchQuery}" 검색 결과 없음` : "대화 기록이 없습니다"}
          </p>
        ) : (
          Array.from(grouped.entries()).map(([group, items]) => (
            <div key={group} className="mb-3">
              <p className="px-2 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-navy-400">
                {group}
              </p>
              <div className="space-y-0.5">
                {items.map((session) => (
                  <div
                    key={session.id}
                    className={`group relative flex items-center rounded-lg transition-colors cursor-pointer ${
                      activeSessionId === session.id
                        ? "bg-cyan-50 border border-cyan-200"
                        : "hover:bg-navy-100 border border-transparent"
                    }`}
                  >
                    {editingId === session.id ? (
                      <div className="flex w-full items-center gap-1 px-2 py-2">
                        <input
                          type="text" value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") handleRename(session.id);
                            if (e.key === "Escape") setEditingId(null);
                          }}
                          className="flex-1 rounded bg-white border border-navy-200 px-2 py-1
                                     text-xs text-navy-800 focus:outline-none focus:ring-1 focus:ring-cyan-400"
                          autoFocus
                        />
                        <button onClick={() => handleRename(session.id)} className="rounded p-1 text-green-600 hover:bg-green-50">
                          <Check size={13} />
                        </button>
                        <button onClick={() => setEditingId(null)} className="rounded p-1 text-navy-400 hover:bg-navy-100">
                          <X size={13} />
                        </button>
                      </div>
                    ) : deletingId === session.id ? (
                      <div className="flex w-full items-center gap-1 px-2 py-2">
                        <span className="flex-1 text-xs text-red-600">삭제하시겠습니까?</span>
                        <button onClick={() => handleDelete(session.id)}
                          className="rounded px-2 py-1 text-[10px] font-medium bg-red-500 text-white hover:bg-red-600">
                          삭제
                        </button>
                        <button onClick={() => setDeletingId(null)}
                          className="rounded px-2 py-1 text-[10px] font-medium bg-navy-200 text-navy-600 hover:bg-navy-300">
                          취소
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => handleSelect(session)}
                        role="button" tabIndex={0}
                        onKeyDown={(e) => { if (e.key === "Enter") handleSelect(session); }}
                        className="flex w-full items-center gap-2 px-2.5 py-2.5 text-left min-w-0 cursor-pointer"
                      >
                        <MessageCircle size={14}
                          className={`shrink-0 ${activeSessionId === session.id ? "text-cyan-600" : "text-navy-400"}`}
                        />
                        <div className="flex-1 min-w-0">
                          <p className={`text-xs truncate ${
                            activeSessionId === session.id ? "font-semibold text-cyan-800" : "text-navy-700"
                          }`}>
                            {session.title || "새 대화"}
                          </p>
                          <p className="text-[10px] text-navy-400 mt-0.5">{session.message_count}개 메시지</p>
                        </div>
                        <div className="shrink-0 flex gap-0.5 opacity-0 group-hover:opacity-100 md:transition-opacity">
                          <button
                            onClick={(e) => { e.stopPropagation(); setEditingId(session.id); setEditTitle(session.title || ""); }}
                            className="rounded p-1.5 text-navy-400 hover:bg-navy-200 hover:text-navy-600"
                          >
                            <Pencil size={11} />
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); setDeletingId(session.id); }}
                            className="rounded p-1.5 text-navy-400 hover:bg-red-50 hover:text-red-500"
                          >
                            <Trash2 size={11} />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      <div className="border-t border-navy-100 px-3 py-2">
        <p className="text-center text-[10px] text-navy-400">
          {sessions.length}개의 대화 · MolChat v1.0
        </p>
      </div>
    </div>
  );
}
