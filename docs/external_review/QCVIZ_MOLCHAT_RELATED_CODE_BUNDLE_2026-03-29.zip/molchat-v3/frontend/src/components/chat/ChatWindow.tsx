'use client';

import { AnimatePresence, motion } from 'framer-motion';
import MessageBubble from './MessageBubble';
import StreamingIndicator from './StreamingIndicator';
import { useChatStore } from '@/stores/chatStore';

export default function ChatWindow() {
  const { messages, isStreaming, streamingContent } = useChatStore();

  return (
    <div className="space-y-4">
      <AnimatePresence initial={false}>
        {messages.map((msg) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
          >
            <MessageBubble message={msg} />
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Streaming bubble */}
      {isStreaming && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {streamingContent ? (
            <MessageBubble
              message={{
                id: 'streaming',
                role: 'assistant',
                content: streamingContent,
                timestamp: new Date().toISOString(),
              }}
              isStreaming
            />
          ) : (
            <StreamingIndicator />
          )}
        </motion.div>
      )}
    </div>
  );
}