'use client';

import { useRef, useState, KeyboardEvent } from 'react';
import TextareaAutosize from 'react-textarea-autosize';
import { Send, Loader2, Paperclip, Mic } from 'lucide-react';
import clsx from 'clsx';
import { useChatStore } from '@/stores/chatStore';

export default function InputBar() {
  const [value, setValue] = useState('');
  const { sendMessage, isStreaming } = useChatStore();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    const trimmed = value.trim();
    if (!trimmed || isStreaming) return;
    sendMessage(trimmed);
    setValue('');
    textareaRef.current?.focus();
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const canSend = value.trim().length > 0 && !isStreaming;

  return (
    <div className="relative flex items-end gap-2 rounded-2xl border border-surface-800/60 bg-surface-900/70 px-4 py-3 shadow-lg shadow-black/20 backdrop-blur-sm transition-colors focus-within:border-brand-500/40 focus-within:shadow-brand-500/5">
      {/* Textarea */}
      <TextareaAutosize
        ref={textareaRef}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="분자에 대해 무엇이든 물어보세요..."
        maxRows={6}
        className="flex-1 resize-none bg-transparent text-sm text-surface-100 placeholder-surface-600 outline-none"
        disabled={isStreaming}
      />

      {/* Send button */}
      <button
        onClick={handleSend}
        disabled={!canSend}
        className={clsx(
          'flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-all',
          canSend
            ? 'bg-brand-500 text-white shadow-md shadow-brand-500/30 hover:bg-brand-400 active:scale-95'
            : 'bg-surface-800 text-surface-600'
        )}
      >
        {isStreaming ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Send className="h-4 w-4" />
        )}
      </button>
    </div>
  );
}