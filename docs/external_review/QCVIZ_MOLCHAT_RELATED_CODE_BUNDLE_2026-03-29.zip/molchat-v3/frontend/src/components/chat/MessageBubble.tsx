'use client';

import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { User, Bot, Copy, Check, ThumbsUp, ThumbsDown } from 'lucide-react';
import clsx from 'clsx';
import ToolCallCard from './ToolCallCard';
import MoleculeCardFull from '../molecule/MoleculeCardFull';
import type { ChatMessage } from '@/types/chat';

interface Props {
  message: ChatMessage;
  isStreaming?: boolean;
}

export default function MessageBubble({ message, isStreaming = false }: Props) {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={clsx('group flex gap-3', isUser && 'flex-row-reverse')}>
      {/* Avatar */}
      <div
        className={clsx(
          'flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-white',
          isUser
            ? 'bg-gradient-to-br from-brand-500 to-brand-700'
            : 'bg-gradient-to-br from-chem-600 to-chem-800'
        )}
      >
        {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
      </div>

      {/* Bubble */}
      <div className={clsx('max-w-[85%] min-w-0', isUser && 'text-right')}>
        <div className={clsx(isUser ? 'msg-user' : 'msg-assistant', 'relative')}>
          {/* Markdown content */}
          <div className="prose prose-invert prose-sm max-w-none prose-pre:bg-surface-950 prose-pre:border prose-pre:border-surface-700 prose-code:text-chem-400 prose-a:text-brand-400">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {message.content}
            </ReactMarkdown>
          </div>

          {/* Streaming cursor */}
          {isStreaming && (
            <span className="ml-0.5 inline-block h-4 w-[2px] animate-pulse-soft bg-chem-400" />
          )}
        </div>

        {/* Tool calls */}
        {message.toolCalls && message.toolCalls.length > 0 && (
          <div className="mt-2 space-y-2">
            {message.toolCalls.map((tc, i) => (
              <ToolCallCard key={i} toolCall={tc} />
            ))}
          </div>
        )}

        {/* Molecule Card Full — 채팅에서 분자 카드 표시 */}
        {message.moleculeCard && (
          <div className="mt-3">
            <MoleculeCardFull
              data={message.moleculeCard}
              onMoleculeClick={(cid) => {
                // 유사 분자 클릭 시 새 카드 (향후 확장)
                console.log('Similar molecule clicked:', cid);
              }}
            />
          </div>
        )}

        {/* Actions */}
        {!isUser && !isStreaming && (
          <div className="mt-1.5 flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
            <button
              onClick={handleCopy}
              className="rounded-md p-1.5 text-surface-500 transition hover:bg-surface-800 hover:text-surface-300"
              title="복사"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
            </button>
            <button
              className="rounded-md p-1.5 text-surface-500 transition hover:bg-surface-800 hover:text-green-400"
              title="좋아요"
            >
              <ThumbsUp className="h-3.5 w-3.5" />
            </button>
            <button
              className="rounded-md p-1.5 text-surface-500 transition hover:bg-surface-800 hover:text-red-400"
              title="싫어요"
            >
              <ThumbsDown className="h-3.5 w-3.5" />
            </button>
            {message.confidence !== undefined && (
              <span className="ml-2 text-2xs text-surface-600">
                신뢰도 {Math.round(message.confidence * 100)}%
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
