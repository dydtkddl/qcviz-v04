'use client';

import React, { useState, useEffect } from 'react';
import { ExternalLink, ChevronDown, ChevronUp, FlaskConical } from 'lucide-react';

interface MoleculeInfo {
  name: string;
  familiar_name?: string;
  professional_name?: string;
  smiles?: string;
  cid?: number | string;
  formula?: string;
  id?: string;
}

interface PubchemProps {
  IUPACName?: string;
  MolecularFormula?: string;
  MolecularWeight?: number;
  CanonicalSMILES?: string;
  CID?: number;
}

export default function MoleculeCard({ molecule }: { molecule: MoleculeInfo }) {
  const [expanded, setExpanded] = useState(false);
  const [pubData, setPubData] = useState<PubchemProps | null>(null);
  const [loading, setLoading] = useState(false);
  const [imgErr, setImgErr] = useState(false);

  const familiar = molecule.familiar_name || molecule.name;
  const professional = molecule.professional_name || molecule.name;
  const showBoth = familiar.toLowerCase() !== professional.toLowerCase();

  // Use professional name for PubChem lookups (more reliable)
  const lookupName = professional !== familiar ? professional : molecule.name;

  const imgUrl = molecule.cid
    ? `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${molecule.cid}/PNG?image_size=150x150`
    : `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/${encodeURIComponent(lookupName)}/PNG?image_size=150x150`;

  const pubchemLink = molecule.cid
    ? `https://pubchem.ncbi.nlm.nih.gov/compound/${molecule.cid}`
    : `https://pubchem.ncbi.nlm.nih.gov/#query=${encodeURIComponent(lookupName)}`;

  useEffect(() => {
    if (expanded && !pubData && !loading) {
      setLoading(true);
      const url = molecule.cid
        ? `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${molecule.cid}/property/MolecularFormula,MolecularWeight,IUPACName,CanonicalSMILES/JSON`
        : `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/${encodeURIComponent(lookupName)}/property/MolecularFormula,MolecularWeight,IUPACName,CanonicalSMILES/JSON`;
      fetch(url)
        .then(r => r.ok ? r.json() : null)
        .then(data => {
          const props = data?.PropertyTable?.Properties?.[0];
          if (props) setPubData(props);
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, [expanded]);

  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700
                    rounded-xl shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden">
      {/* Header row */}
      <div className="flex items-start gap-3 p-3">
        {/* Thumbnail */}
        <div className="flex-shrink-0 w-14 h-14 bg-gray-50 dark:bg-gray-700 rounded-lg
                       flex items-center justify-center overflow-hidden border border-gray-100 dark:border-gray-600">
          {!imgErr ? (
            <img src={imgUrl} alt={familiar}
                 className="w-full h-full object-contain p-0.5"
                 onError={() => setImgErr(true)} />
          ) : (
            <FlaskConical className="w-7 h-7 text-gray-300 dark:text-gray-500" />
          )}
        </div>

        {/* Names */}
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-gray-900 dark:text-white text-sm leading-tight truncate">
            {familiar}
          </h4>
          {showBoth && (
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 truncate italic">
              {professional}
            </p>
          )}
          {molecule.formula && (
            <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5 font-mono">
              {molecule.formula}
            </p>
          )}
        </div>

        {/* Buttons */}
        <div className="flex-shrink-0 flex items-center gap-0.5">
          <a href={pubchemLink} target="_blank" rel="noopener noreferrer"
             className="p-1.5 text-gray-400 hover:text-blue-500 rounded-md
                       hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
             title="PubChem">
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <button onClick={() => setExpanded(!expanded)}
                  className="p-1.5 text-gray-400 hover:text-gray-600 rounded-md
                            hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  title={expanded ? "접기" : "상세 보기"}>
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Expanded detail */}
      {expanded && (
        <div className="px-3 pb-3 border-t border-gray-100 dark:border-gray-700">
          <div className="pt-2.5 space-y-1.5">
            {loading && (
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <div className="w-3 h-3 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
                PubChem 데이터 로딩...
              </div>
            )}
            {pubData && (
              <>
                {pubData.IUPACName && (
                  <div className="text-xs">
                    <span className="text-gray-500">IUPAC: </span>
                    <span className="text-gray-700 dark:text-gray-300 font-mono text-[11px]">{pubData.IUPACName}</span>
                  </div>
                )}
                {pubData.MolecularFormula && (
                  <div className="text-xs">
                    <span className="text-gray-500">분자식: </span>
                    <span className="text-gray-700 dark:text-gray-300 font-mono">{pubData.MolecularFormula}</span>
                  </div>
                )}
                {pubData.MolecularWeight && (
                  <div className="text-xs">
                    <span className="text-gray-500">분자량: </span>
                    <span className="text-gray-700 dark:text-gray-300">{pubData.MolecularWeight} g/mol</span>
                  </div>
                )}
                {pubData.CanonicalSMILES && (
                  <div className="text-xs">
                    <span className="text-gray-500">SMILES: </span>
                    <span className="text-gray-700 dark:text-gray-300 font-mono text-[11px] break-all">{pubData.CanonicalSMILES}</span>
                  </div>
                )}
              </>
            )}
            {!loading && !pubData && (
              <p className="text-xs text-gray-400 italic">PubChem에서 정보를 가져올 수 없습니다.</p>
            )}
            {/* Larger structure image */}
            {!imgErr && (
              <div className="mt-2 bg-white dark:bg-gray-900 rounded-lg p-1.5 border border-gray-100 dark:border-gray-600">
                <img src={molecule.cid
                  ? `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${molecule.cid}/PNG?image_size=280x280`
                  : `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/${encodeURIComponent(lookupName)}/PNG?image_size=280x280`}
                  alt={`${familiar} structure`}
                  className="w-full max-w-[260px] mx-auto" />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
