"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import {
  X, Atom, Maximize2, Minimize2, Download, RotateCw,
  Loader2, Layers, AlertCircle, RefreshCw, Zap,
} from "lucide-react";
import { api } from "@/lib/api";

/* ── Types ── */
interface MolRef {
  name: string;
  cid?: number;
  smiles?: string;
  id?: string;
  familiar_name?: string;
  professional_name?: string;
}

interface MoleculeData extends MolRef {
  sdfData?: string;
  formula?: string | null;
  weight?: number | null;
  iupacName?: string | null;
  loading: boolean;
  error?: string;
  displayName?: string;
  source?: "pubchem" | "backend" | "rdkit-3d" | "smiles-render";
  generationMethod?: string;
  properties?: Record<string, any> | null;
}

interface MoleculePanelProps {
  molecules: MolRef[];
  open: boolean;
  onClose: () => void;
}

/* ── Cache ── */
const cache = new Map<string, {
  sdf?: string; formula?: string; weight?: number;
  iupac?: string; cid?: number; smiles?: string;
  source: string; generationMethod?: string;
  properties?: Record<string, any> | null;
}>();

/* ═══════════════════════════════════════════════════════
   Flexible Name Variants — 이름 변형 자동 생성
   "Helicenes" → ["Helicenes","Helicene","helicene",...]
   ═══════════════════════════════════════════════════════ */
function generateNameVariants(name: string): string[] {
  const variants: string[] = [name.trim()];
  const trimmed = name.trim();

  // 1. 복수형 → 단수형
  if (trimmed.endsWith("enes")) {
    variants.push(trimmed.slice(0, -1));          // Helicenes → Helicene
    variants.push(trimmed.replace(/enes$/, "ene")); // 동일
  }
  if (trimmed.endsWith("anes")) {
    variants.push(trimmed.slice(0, -1));
    variants.push(trimmed.replace(/anes$/, "ane"));
  }
  if (trimmed.endsWith("ines")) {
    variants.push(trimmed.slice(0, -1));
    variants.push(trimmed.replace(/ines$/, "ine"));
  }
  if (trimmed.endsWith("acids")) {
    variants.push(trimmed.replace(/acids$/, "acid"));
  }
  if (trimmed.endsWith("s") && !trimmed.endsWith("ss")) {
    variants.push(trimmed.slice(0, -1));
  }

  // 2. 대표적 접두사 변형 (예: [6]Helicene)
  const singularBase = trimmed.replace(/s$/, "");
  if (/^[A-Z]/.test(singularBase)) {
    variants.push(`[6]${singularBase}`);   // Helicene → [6]Helicene
    variants.push(`[4]${singularBase}`);   // Calixarene → [4]Calixarene
  }

  // 3. 괄호/접두사 제거
  const noBrackets = trimmed.replace(/^\[.*?\]/, "").trim();
  if (noBrackets !== trimmed) variants.push(noBrackets);

  // 4. 하이픈 변형
  if (trimmed.includes("-")) {
    variants.push(trimmed.replace(/-/g, " "));
    variants.push(trimmed.replace(/-/g, ""));
  }

  // 5. 소문자
  variants.push(trimmed.toLowerCase());

  // 6. "acid" 추가/제거
  if (trimmed.toLowerCase().endsWith(" acid")) {
    variants.push(trimmed.replace(/ acid$/i, ""));
  } else if (!trimmed.toLowerCase().includes("acid")) {
    variants.push(`${trimmed} acid`);
  }

  // 중복 제거 + 빈 문자열 제거
  return [...new Set(variants)].filter(v => v.length > 0);
}

/* ═══════════════════════════════════════════════════════
   PubChem fetch helpers
   ═══════════════════════════════════════════════════════ */
async function fetchPubChemByCid(cid: number) {
  const [sdfRes, propRes] = await Promise.all([
    fetch(`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${cid}/SDF?record_type=3d`).then(r => {
      if (!r.ok) return fetch(`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${cid}/SDF`);
      return r;
    }),
    fetch(`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${cid}/property/MolecularFormula,MolecularWeight,IUPACName,CanonicalSMILES/JSON`).catch(() => null),
  ]);

  if (!sdfRes.ok) throw new Error("SDF download failed");
  const sdf = await sdfRes.text();

  let formula: string | undefined, weight: number | undefined,
      iupac: string | undefined, smiles: string | undefined;

  if (propRes?.ok) {
    try {
      const props = (await propRes.json())?.PropertyTable?.Properties?.[0];
      if (props) {
        formula = props.MolecularFormula;
        weight = props.MolecularWeight;
        iupac = props.IUPACName;
        smiles = props.CanonicalSMILES;
      }
    } catch { /* ignore */ }
  }

  return { sdf, formula, weight, iupac, cid, smiles, source: "pubchem" as const };
}

async function getCidByName(name: string): Promise<number | null> {
  // ── CID 문자열 감지: "CID 938" → 938 직접 반환 ──
  const cidMatch = name.match(/^CID\s*(\d+)$/i);
  if (cidMatch) return Number(cidMatch[1]);
  
  // ── 숫자만으로 된 이름 → CID로 간주 ──
  if (/^\d{3,}$/.test(name.trim())) return Number(name.trim());

  try {
    const res = await fetch(
      `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/${encodeURIComponent(name)}/cids/JSON`
    );
    if (!res.ok) return null;
    const data = await res.json();
    return data?.IdentifierList?.CID?.[0] ?? null;
  } catch {
    return null;
  }
}

async function getCidBySmiles(smiles: string): Promise<number | null> {
  try {
    const res = await fetch(
      `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/smiles/${encodeURIComponent(smiles)}/cids/JSON`
    );
    if (!res.ok) return null;
    const data = await res.json();
    return data?.IdentifierList?.CID?.[0] ?? null;
  } catch {
    return null;
  }
}

/* ── Flexible PubChem search: try multiple name variants ── */
async function fetchPubChemFlexible(names: string[], smiles?: string) {
  // ── CID 패턴이면 바로 CID fetch ──
  for (const name of names) {
    const cidMatch = name.match(/^CID\s*(\d+)$/i);
    const pureCid = cidMatch ? Number(cidMatch[1]) : (/^\d{3,}$/.test(name.trim()) ? Number(name.trim()) : null);
    if (pureCid && pureCid > 0) {
      try {
        const [sdfRes, propRes] = await Promise.all([
          fetch(`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${pureCid}/SDF?record_type=3d`).then(r => {
            if (!r.ok) return fetch(`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${pureCid}/SDF`);
            return r;
          }),
          fetch(`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${pureCid}/property/MolecularFormula,MolecularWeight,IUPACName,CanonicalSMILES/JSON`).catch(() => null),
        ]);
        if (sdfRes.ok) {
          const sdf = await sdfRes.text();
          let formula, weight, iupac, smilesStr;
          if (propRes?.ok) {
            const pj = await propRes.json();
            const p = pj?.PropertyTable?.Properties?.[0];
            if (p) { formula = p.MolecularFormula; weight = p.MolecularWeight; iupac = p.IUPACName; smilesStr = p.CanonicalSMILES; }
          }
          return { sdf, formula, weight, iupac, cid: pureCid, smiles: smilesStr, source: "pubchem" as const };
        }
      } catch {}
    }
  }

  // CID 패턴 감지 — "CID 938" 같은 이름이면 직접 CID로 조회
  for (const name of names) {
    const cidMatch = name.match(/^(?:\[\d+\])?\s*CID\s*(\d+)/i);
    if (cidMatch) {
      const directCid = parseInt(cidMatch[1], 10);
      if (directCid > 0) return fetchPubChemByCid(directCid);
    }
  }

  // Try each name variant
  for (const name of names) {
    // Skip names that look like CID patterns
    if (/^(?:\[\d+\])?\s*CID\s*\d+/i.test(name)) continue;
    const cid = await getCidByName(name);
    if (cid) return fetchPubChemByCid(cid);
  }

  // Try by SMILES
  if (smiles) {
    const cid = await getCidBySmiles(smiles);
    if (cid) return fetchPubChemByCid(cid);
  }

  throw new Error("PubChem: not found");
}

/* ── Backend DB search (also flexible) ── */
async function fetchFromBackendFlexible(names: string[]) {
  for (const name of names) {
    try {
      const searchRes = await api.searchMolecules(name, 1);
      if (searchRes.results?.[0]) {
        const result = searchRes.results[0];
        let sdf: string | undefined;
        try { sdf = await api.downloadStructure(result.id, "sdf"); } catch { /* ignore */ }

        return {
          sdf,
          formula: result.molecular_formula || undefined,
          weight: result.molecular_weight || undefined,
          cid: result.cid || undefined,
          id: result.id,
          smiles: result.canonical_smiles,
          source: "backend" as const,
        };
      }
    } catch { /* try next variant */ }
  }
  throw new Error("Backend: not found");
}

/* ── Backend RDKit 3D generation ── */
async function fetchFromRDKit3D(smiles: string) {
  const result = await api.generate3D(smiles, "sdf", false);
  return {
    sdf: result.structure_data,
    smiles: result.smiles,
    source: "rdkit-3d" as const,
    generationMethod: result.generation_method,
    properties: result.properties,
    formula: result.properties?.molecular_formula,
    weight: result.properties?.molecular_weight,
  };
}

/* ═══════════════════════════════════════════════════════
   Master fetch: 4-level fallback with flexible naming
   ═══════════════════════════════════════════════════════ */
async function fetchMoleculeData(mol: MolRef): Promise<{
  sdf?: string; smiles?: string; formula?: string;
  weight?: number; iupac?: string; cid?: number; id?: string;
  source: string; generationMethod?: string;
  properties?: Record<string, any> | null;
}> {
  const primaryName = mol.professional_name || mol.name || mol.familiar_name || "";
  const cacheKey = (primaryName + (mol.smiles || "")).toLowerCase().trim();

  if (cache.has(cacheKey)) return cache.get(cacheKey)!;

  // Generate flexible name variants
  const nameVariants = generateNameVariants(primaryName);

  // Also add familiar_name variants if different
  if (mol.familiar_name && mol.familiar_name !== primaryName) {
    nameVariants.push(...generateNameVariants(mol.familiar_name));
  }
  if (mol.name && mol.name !== primaryName && mol.name !== mol.familiar_name) {
    nameVariants.push(...generateNameVariants(mol.name));
  }

  const uniqueVariants = [...new Set(nameVariants)];

  // Level 1: PubChem (flexible name search)
  try {
    const result = await fetchPubChemFlexible(uniqueVariants, mol.smiles);
    cache.set(cacheKey, result);
    return result;
  } catch { /* continue */ }

  // Level 2: Backend DB (flexible name search)
  try {
    const result = await fetchFromBackendFlexible(uniqueVariants);
    if (result.sdf) {
      cache.set(cacheKey, result);
      return result;
    }
    if (result.smiles) {
      try {
        const rdkitResult = await fetchFromRDKit3D(result.smiles);
        const merged = {
          ...rdkitResult,
          formula: rdkitResult.formula || result.formula,
          weight: rdkitResult.weight || result.weight,
          cid: result.cid,
          id: result.id,
        };
        cache.set(cacheKey, merged);
        return merged;
      } catch { /* continue */ }
    }
  } catch { /* continue */ }

  // Level 3: Backend RDKit 3D (from SMILES)
  if (mol.smiles) {
    try {
      const result = await fetchFromRDKit3D(mol.smiles);
      cache.set(cacheKey, result);
      return result;
    } catch { /* continue */ }
  }

  // Level 4: Direct SMILES render
  if (mol.smiles) {
    const result = { smiles: mol.smiles, source: "smiles-render" as const };
    cache.set(cacheKey, result);
    return result;
  }

  throw new Error("구조를 찾을 수 없습니다");
}

/* ── Source badge ── */
function sourceBadge(source?: string, generationMethod?: string) {
  switch (source) {
    case "pubchem": return { label: "PubChem 3D", cls: "bg-blue-100 text-blue-700" };
    case "backend": return { label: "MolChat DB", cls: "bg-green-100 text-green-700" };
    case "rdkit-3d": return {
      label: generationMethod === "xtb-optimized" ? "xTB 최적화" : "RDKit 3D",
      cls: generationMethod === "xtb-optimized"
        ? "bg-orange-100 text-orange-700"
        : "bg-purple-100 text-purple-700",
    };
    case "smiles-render": return { label: "SMILES", cls: "bg-amber-100 text-amber-700" };
    default: return null;
  }
}

/* ═══════════════════════════════════════════════════════
   3D Viewer Card
   ═══════════════════════════════════════════════════════ */
function Mol3DCard({
  mol, expanded, onToggleExpand, onRetry,
}: {
  mol: MoleculeData; expanded: boolean;
  onToggleExpand: () => void; onRetry: () => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<any>(null);
  const [viewStyle, setViewStyle] = useState<"stick" | "sphere" | "line">("stick");
  const [spinning, setSpinning] = useState(false);
  const [showProps, setShowProps] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;
    if (!mol.sdfData && !mol.smiles) return;

    const init = () => {
      const $3Dmol = (window as any).$3Dmol;
      if (!$3Dmol) { setTimeout(init, 500); return; }

      if (viewerRef.current) {
        try { viewerRef.current.clear(); } catch { /* ignore */ }
      }
      containerRef.current!.innerHTML = "";

      const viewer = $3Dmol.createViewer(containerRef.current, {
        backgroundColor: "0xffffff",
        antialias: true,
      });

      if (mol.sdfData) {
        viewer.addModel(mol.sdfData, "sdf");
      } else if (mol.smiles) {
        viewer.addModel(mol.smiles, "smi");
      }

      applyStyle(viewer, viewStyle);
      viewer.zoomTo();
      viewer.render();
      if (spinning) viewer.spin(true);
      viewerRef.current = viewer;
    };

    init();
    return () => {
      if (viewerRef.current) {
        try { viewerRef.current.clear(); } catch { /* ignore */ }
        viewerRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mol.sdfData, mol.smiles, expanded]);

  useEffect(() => {
    if (!viewerRef.current) return;
    applyStyle(viewerRef.current, viewStyle);
    viewerRef.current.render();
  }, [viewStyle]);

  useEffect(() => {
    if (!viewerRef.current) return;
    viewerRef.current.spin(spinning);
  }, [spinning]);

  function applyStyle(viewer: any, style: string) {
    viewer.setStyle({}, {});
    switch (style) {
      case "stick":
        viewer.setStyle({}, { stick: { radius: 0.15 }, sphere: { scale: 0.25 } });
        break;
      case "sphere":
        viewer.setStyle({}, { sphere: { scale: 0.6 } });
        break;
      case "line":
        viewer.setStyle({}, { line: { linewidth: 2 } });
        break;
    }
  }

  const handleDownload = () => {
    if (!mol.sdfData) return;
    const blob = new Blob([mol.sdfData], { type: "chemical/x-mdl-sdfile" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${mol.displayName || mol.familiar_name || mol.name || "molecule"}.sdf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const title = mol.displayName || mol.familiar_name || mol.name;
  const subtitle = mol.professional_name && mol.professional_name !== title
    ? mol.professional_name : mol.iupacName || null;
  const badge = sourceBadge(mol.source, mol.generationMethod);
  const hasViewer = mol.sdfData || mol.smiles;
  const props = mol.properties;

  return (
    <div className={`bg-white rounded-xl border border-navy-200 shadow-lg overflow-hidden transition-all duration-300 ${
      expanded ? "col-span-full" : ""
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-gradient-to-r from-navy-50 to-cyan-50 border-b border-navy-100">
        <div className="flex items-center gap-2 min-w-0">
          <Atom size={14} className="text-cyan-600 shrink-0" />
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <p className="text-xs font-semibold text-navy-800 truncate">{title}</p>
              {badge && (
                <span className={`shrink-0 text-[8px] sm:text-[9px] font-medium px-1.5 py-0.5 rounded-full ${badge.cls}`}>
                  {badge.label}
                </span>
              )}
            </div>
            {subtitle && <p className="text-[10px] text-navy-400 truncate">{subtitle}</p>}
            {mol.cid && (
              <a href={`https://pubchem.ncbi.nlm.nih.gov/compound/${mol.cid}`}
                target="_blank" rel="noopener noreferrer"
                className="text-[10px] text-cyan-500 hover:text-cyan-700 hover:underline">
                CID: {mol.cid}
              </a>
            )}
          </div>
        </div>
        <div className="flex items-center gap-0.5 shrink-0">
          <button onClick={() => setSpinning(!spinning)}
            className={`rounded p-1 transition-colors ${spinning ? "bg-cyan-100 text-cyan-600" : "text-navy-400 hover:bg-navy-100"}`}
            title="회전"><RotateCw size={12} /></button>
          {mol.sdfData && (
            <button onClick={handleDownload}
              className="rounded p-1 text-navy-400 hover:bg-navy-100 transition-colors"
              title="SDF 다운로드"><Download size={12} /></button>
          )}
          {props && (
            <button onClick={() => setShowProps(!showProps)}
              className={`rounded p-1 transition-colors ${showProps ? "bg-purple-100 text-purple-600" : "text-navy-400 hover:bg-navy-100"}`}
              title="물성 정보"><Zap size={12} /></button>
          )}
          <button onClick={onToggleExpand}
            className="rounded p-1 text-navy-400 hover:bg-navy-100 transition-colors"
            title={expanded ? "축소" : "확대"}>
            {expanded ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
          </button>
        </div>
      </div>

      {/* 3D Viewer */}
      <div className="relative">
        {mol.loading ? (
          <div className={`flex items-center justify-center bg-navy-50 ${expanded ? "h-60 sm:h-80" : "h-36 sm:h-44"}`}>
            <div className="flex flex-col items-center gap-2">
              <Loader2 size={20} className="animate-spin text-cyan-500" />
              <span className="text-[10px] text-navy-400">구조 로딩 중...</span>
            </div>
          </div>
        ) : mol.error ? (
          <div className={`flex items-center justify-center bg-red-50/50 ${expanded ? "h-60 sm:h-80" : "h-36 sm:h-44"}`}>
            <div className="flex flex-col items-center gap-2 px-4 text-center">
              <AlertCircle size={18} className="text-red-400" />
              <p className="text-xs text-red-500">{mol.error}</p>
              <button onClick={onRetry}
                className="flex items-center gap-1 text-[10px] text-cyan-600 hover:text-cyan-800 transition-colors">
                <RefreshCw size={10} /> 다시 시도
              </button>
            </div>
          </div>
        ) : hasViewer ? (
          <div ref={containerRef}
            className={`w-full cursor-grab active:cursor-grabbing ${expanded ? "h-60 sm:h-80" : "h-36 sm:h-44"}`}
            style={{ position: "relative" }} />
        ) : (
          <div className={`flex items-center justify-center bg-navy-50 ${expanded ? "h-60 sm:h-80" : "h-36 sm:h-44"}`}>
            <p className="text-xs text-navy-400">구조 데이터 없음</p>
          </div>
        )}

        {/* Style selector */}
        {!mol.loading && !mol.error && hasViewer && (
          <div className="absolute bottom-1.5 left-1.5 flex gap-0.5 bg-white/90 backdrop-blur-sm rounded-md border border-navy-100 p-0.5">
            {(["stick", "sphere", "line"] as const).map((s) => (
              <button key={s} onClick={() => setViewStyle(s)}
                className={`px-1.5 py-0.5 rounded text-[9px] font-medium transition-colors ${
                  viewStyle === s ? "bg-cyan-500 text-white" : "text-navy-500 hover:bg-navy-100"
                }`}>
                {s === "stick" ? "Stick" : s === "sphere" ? "Space" : "Wire"}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* RDKit Properties */}
      {showProps && props && (
        <div className="px-3 py-2 bg-purple-50/50 border-t border-purple-100 space-y-1">
          <p className="text-[10px] font-semibold text-purple-700 mb-1">물성 정보</p>
          <div className="grid grid-cols-2 gap-x-4 gap-y-0.5">
            {props.molecular_weight != null && (
              <p className="text-[10px] text-navy-600"><span className="font-medium">MW:</span> {props.molecular_weight.toFixed(2)}</p>
            )}
            {props.logp != null && (
              <p className="text-[10px] text-navy-600"><span className="font-medium">LogP:</span> {props.logp.toFixed(2)}</p>
            )}
            {props.tpsa != null && (
              <p className="text-[10px] text-navy-600"><span className="font-medium">TPSA:</span> {props.tpsa.toFixed(1)}</p>
            )}
            {props.hbd != null && (
              <p className="text-[10px] text-navy-600"><span className="font-medium">HBD:</span> {props.hbd}</p>
            )}
            {props.hba != null && (
              <p className="text-[10px] text-navy-600"><span className="font-medium">HBA:</span> {props.hba}</p>
            )}
            {props.rotatable_bonds != null && (
              <p className="text-[10px] text-navy-600"><span className="font-medium">RotBonds:</span> {props.rotatable_bonds}</p>
            )}
            {props.qed != null && (
              <p className="text-[10px] text-navy-600"><span className="font-medium">QED:</span> {props.qed.toFixed(3)}</p>
            )}
            {props.lipinski_violations != null && (
              <p className="text-[10px] text-navy-600"><span className="font-medium">Lipinski:</span> {props.lipinski_violations === 0 ? "✓ Pass" : `${props.lipinski_violations} violations`}</p>
            )}
          </div>
        </div>
      )}

      {/* Basic Properties Footer */}
      {!mol.loading && !mol.error && (mol.formula || mol.weight || mol.smiles) && !showProps && (
        <div className="px-3 py-2 bg-navy-50/50 border-t border-navy-100 space-y-0.5">
          {mol.formula && (
            <p className="text-[10px] text-navy-600">
              <span className="font-medium">Formula:</span> {mol.formula}
            </p>
          )}
          {mol.weight && (
            <p className="text-[10px] text-navy-600">
              <span className="font-medium">MW:</span> {Number(mol.weight).toFixed(2)} g/mol
            </p>
          )}
          {mol.smiles && (
            <p className="text-[10px] text-navy-500 truncate font-mono" title={mol.smiles}>
              {mol.smiles}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   Main Panel
   ═══════════════════════════════════════════════════════ */

// Enterprise v2: Filter out category/non-molecule terms
const SKIP_PANEL_TERMS = new Set([
  'vitamin','vitamins','비타민','mineral','minerals','미네랄','electrolyte','전해질',
  'amino acid','아미노산','protein','단백질','carbohydrate','탄수화물',
  'sugar','당류','nutrient','영양소','antioxidant','항산화제',
  '비타민 B군','비타민 C','비타민 B3','비타민 B5','비타민 B6','비타민 B12',
  '수용성 비타민','지용성 비타민','무기질','유기산',
  '과당','자당','포도당','설탕','칼륨','마그네슘','나트륨','칼슘',
]);

export default function MoleculePanel({ molecules, open, onClose }: MoleculePanelProps) {
  const [molData, setMolData] = useState<MoleculeData[]>([]);
  const [expandedIdx, setExpandedIdx] = useState<number | null>(null);

  const fetchOne = useCallback(async (mol: MolRef, idx: number) => {
    setMolData((prev) => {
      const u = [...prev];
      if (u[idx]) u[idx] = { ...u[idx], loading: true, error: undefined };
      return u;
    });

    try {
      const result = await fetchMoleculeData(mol);

      setMolData((prev) => {
        const u = [...prev];
        u[idx] = {
          ...u[idx],
          sdfData: result.sdf,
          formula: result.formula,
          weight: result.weight,
          iupacName: result.iupac,
          cid: result.cid || u[idx]?.cid,
          smiles: result.smiles || u[idx]?.smiles || mol.smiles,
          id: result.id || u[idx]?.id,
          displayName: mol.familiar_name || mol.name,
          source: result.source as any,
          generationMethod: result.generationMethod,
          properties: result.properties,
          loading: false,
          error: undefined,
        };
        return u;
      });
    } catch (err: any) {
      setMolData((prev) => {
        const u = [...prev];
        u[idx] = { ...u[idx], loading: false, error: err.message || "구조를 불러올 수 없습니다" };
        return u;
      });
    }
  }, []);

  useEffect(() => {
    if (!open || molecules.length === 0) return;

    const initial: MoleculeData[] = molecules.map((m) => ({
      ...m, displayName: m.familiar_name || m.name, loading: true,
    }));
    setMolData(initial);

    molecules.forEach((mol, idx) => fetchOne(mol, idx));
  }, [open, molecules, fetchOne]);

  if (!open) return null;

  const loadingCount = molData.filter((m) => m.loading).length;
  const loadedCount = molData.filter((m) => !m.loading && !m.error).length;

  return (
    <>
      <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40" onClick={onClose} />

      <div className="fixed z-50 bg-slate-50 shadow-2xl flex flex-col
                      max-md:inset-x-0 max-md:bottom-0 max-md:top-[15vh] max-md:rounded-t-2xl max-md:border-t max-md:border-navy-200 max-md:animate-slide-up
                      md:right-0 md:top-0 md:bottom-0 md:w-[420px] md:max-w-[90vw] md:border-l md:border-navy-200 md:animate-slide-in-right">
        <div className="md:hidden flex justify-center py-2">
          <div className="w-10 h-1 rounded-full bg-navy-300" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-4 py-2.5 sm:py-3 bg-white border-b border-navy-100">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-cyan-500">
              <Layers size={14} className="text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-navy-900">구조 확인</h3>
              <p className="text-[10px] text-navy-400">
                {loadingCount > 0
                  ? `${loadedCount}/${molData.length}개 로드됨...`
                  : `${molData.length}개 분자`}
              </p>
            </div>
          </div>
          <button onClick={onClose}
            className="rounded-lg p-1.5 text-navy-400 hover:bg-navy-100 hover:text-navy-600 transition-colors">
            <X size={18} />
          </button>
        </div>

        {loadingCount > 0 && (
          <div className="h-0.5 bg-navy-100">
            <div className="h-full bg-cyan-500 transition-all duration-500 ease-out"
              style={{ width: `${(loadedCount / molData.length) * 100}%` }} />
          </div>
        )}

        {/* Cards */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3 overscroll-contain">
          {molData.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Atom size={32} className="text-navy-300 mb-3" />
              <p className="text-sm font-medium text-navy-500">대화에서 언급된 분자가 없습니다</p>
              <p className="text-xs text-navy-400 mt-1">분자에 대해 질문하면 여기에 3D 구조가 표시됩니다</p>
            </div>
          ) : (
            <div className="grid gap-3 grid-cols-1">
              {molData.map((mol, idx) => (
                <Mol3DCard key={`${mol.name}-${idx}`} mol={mol}
                  expanded={expandedIdx === idx}
                  onToggleExpand={() => setExpandedIdx(expandedIdx === idx ? null : idx)}
                  onRetry={() => fetchOne(molecules[idx], idx)} />
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-navy-100 px-4 py-2 bg-white safe-bottom">
          <div className="flex flex-wrap gap-2 justify-center mb-1">
            <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-700">PubChem</span>
            <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-green-100 text-green-700">DB</span>
            <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-purple-100 text-purple-700">RDKit</span>
            <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700">SMILES</span>
          </div>
          <p className="text-[10px] text-navy-400 text-center">
            드래그하여 회전 · 스크롤하여 확대/축소
          </p>
        </div>
      </div>
    </>
  );
}
