'use client';

import { Bot } from 'lucide-react';

export default function StreamingIndicator() {
  return (
    <div className="flex gap-3">
      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-chem-600 to-chem-800 text-white">
        <Bot className="h-4 w-4" />
      </div>
      <div className="msg-assistant inline-flex items-center gap-1.5">
        <span className="h-2 w-2 animate-pulse-soft rounded-full bg-chem-400" style={{ animationDelay: '0ms' }} />
        <span className="h-2 w-2 animate-pulse-soft rounded-full bg-chem-400" style={{ animationDelay: '300ms' }} />
        <span className="h-2 w-2 animate-pulse-soft rounded-full bg-chem-400" style={{ animationDelay: '600ms' }} />
      </div>
    </div>
  );
}