'use client';

import { useState } from 'react';
import { ChevronDown, ChevronRight, Wrench, Check, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import clsx from 'clsx';
import type { ToolCall } from '@/types/chat';

interface Props {
  toolCall: ToolCall;
}

const toolLabels: Record<string, string> = {
  search_molecule: '🔍 분자 검색',
  get_molecule_detail: '🧬 상세 조회',
  compute_properties: '⚗️ 속성 계산',
  compare_molecules: '📊 분자 비교',
  submit_calculation: '🧮 양자 계산',
  check_calculation: '📋 계산 확인',
  generate_conformers: '🔄 컨포머 생성',
};

export default function ToolCallCard({ toolCall }: Props) {
  const [expanded, setExpanded] = useState(false);

  const label = toolLabels[toolCall.name] || `🔧 ${toolCall.name}`;
  const isSuccess = toolCall.success !== false;

  return (
    <div className="overflow-hidden rounded-xl border border-surface-800/50 bg-surface-900/30 text-xs">
      <button
        onClick={() => setExpanded((p) => !p)}
        className="flex w-full items-center gap-2 px-3 py-2 text-left transition hover:bg-surface-800/30"
      >
        <Wrench className="h-3.5 w-3.5 text-surface-500" />
        <span className="flex-1 font-medium text-surface-300">{label}</span>
        {isSuccess ? (
          <Check className="h-3.5 w-3.5 text-green-500" />
        ) : (
          <X className="h-3.5 w-3.5 text-red-500" />
        )}
        {expanded ? (
          <ChevronDown className="h-3.5 w-3.5 text-surface-500" />
        ) : (
          <ChevronRight className="h-3.5 w-3.5 text-surface-500" />
        )}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="overflow-hidden"
          >
            <div className="border-t border-surface-800/40 bg-surface-950/40 px-3 py-2">
              <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-surface-500">
                Arguments
              </p>
              <pre className="max-h-32 overflow-auto whitespace-pre-wrap break-all font-mono text-2xs text-surface-400">
                {JSON.stringify(toolCall.arguments, null, 2)}
              </pre>
              {toolCall.resultPreview && (
                <>
                  <p className="mb-1 mt-2 text-2xs font-semibold uppercase tracking-wide text-surface-500">
                    Result preview
                  </p>
                  <pre className="max-h-32 overflow-auto whitespace-pre-wrap break-all font-mono text-2xs text-surface-400">
                    {toolCall.resultPreview}
                  </pre>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}