"use client";
import { ArrowUpRight } from "lucide-react";
import type { MoleculeRecord } from "@/lib/api";

interface Props {
  molecule: MoleculeRecord;
  onClick?: () => void;
}

function ScoreBadge({ score }: { score: number }) {
  const pct = Math.round(score * 100);
  const color =
    pct >= 90 ? "text-emerald-700 bg-emerald-50 border-emerald-200" :
    pct >= 70 ? "text-sky-700 bg-sky-50 border-sky-200" :
    pct >= 50 ? "text-amber-700 bg-amber-50 border-amber-200" :
               "text-navy-500 bg-navy-50 border-navy-200";

  return (
    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[11px] font-semibold border ${color}`}>
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
      </svg>
      {pct}%
    </span>
  );
}

export default function MoleculeCard({ molecule, onClick }: Props) {
  const props = molecule.properties || {};
  const source = props._source || "unknown";
  const relevanceScore = props._relevance_score as number | undefined;

  const sourceColors: Record<string, string> = {
    pubchem: "badge-blue",
    chembl: "badge-green",
    chemspider: "badge-cyan",
    zinc: "badge-gray",
  };

  return (
    <div
      onClick={onClick}
      className="card group cursor-pointer transition-all hover:shadow-elevated hover:border-navy-200"
    >
      <div className="card-body space-y-3">
        {/* Top row: source + score */}
        <div className="flex items-center justify-between">
          <span className={sourceColors[source] || "badge-gray"}>{source}</span>
          <div className="flex items-center gap-2">
            {relevanceScore != null && <ScoreBadge score={relevanceScore} />}
            {molecule.cid && (
              <span className="text-xs text-navy-400 font-mono">CID {molecule.cid}</span>
            )}
          </div>
        </div>

        {/* Name */}
        <h3 className="text-base font-semibold text-navy-900 leading-snug line-clamp-2 group-hover:text-accent-blue transition-colors">
          {molecule.name || "Unknown compound"}
        </h3>

        {/* SMILES */}
        {molecule.canonical_smiles && (
          <p className="truncate font-mono text-xs text-navy-400" title={molecule.canonical_smiles}>
            {molecule.canonical_smiles}
          </p>
        )}

        {/* Properties row */}
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-navy-500 pt-1 border-t border-navy-50">
          {molecule.molecular_formula && (
            <span><b className="text-navy-700">Formula</b> {molecule.molecular_formula}</span>
          )}
          {molecule.molecular_weight && (
            <span><b className="text-navy-700">MW</b> {molecule.molecular_weight.toFixed(2)}</span>
          )}
          {props.xlogp != null && (
            <span><b className="text-navy-700">LogP</b> {props.xlogp}</span>
          )}
          {(props.hbond_donor ?? props.hbd) != null && (
            <span><b className="text-navy-700">HBD</b> {props.hbond_donor ?? props.hbd}</span>
          )}
          {(props.hbond_acceptor ?? props.hba) != null && (
            <span><b className="text-navy-700">HBA</b> {props.hbond_acceptor ?? props.hba}</span>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-1">
          {molecule.inchikey && (
            <span className="truncate font-mono text-[10px] text-navy-300 max-w-[200px]">
              {molecule.inchikey}
            </span>
          )}
          <ArrowUpRight size={14} className="text-navy-300 group-hover:text-accent-blue transition-colors ml-auto" />
        </div>
      </div>
    </div>
  );
}
