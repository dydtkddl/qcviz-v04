'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ExternalLink, Copy, Check, Download, ChevronDown, ChevronUp, Atom,
  Shield, FlaskConical, AlertTriangle, Beaker, FileText,
  ArrowRight, Loader2, X,
} from 'lucide-react';
import type { MoleculeCardData, GHSSafety, DrugLikenessResult, SimilarMolecule } from '@/types/moleculeCard';
import { api } from '@/lib/api';

/* ─── GHS pictogram descriptions ─── */
const GHS_LABELS: Record<string, string> = {
  GHS01: '폭발성', GHS02: '인화성', GHS03: '산화성', GHS04: '고압가스',
  GHS05: '부식성', GHS06: '급성독성', GHS07: '자극성', GHS08: '건강유해성', GHS09: '환경유해성',
};

/* ─── Property item ─── */
function PropItem({ label, value, unit, mono }: { label: string; value: any; unit?: string; mono?: boolean }) {
  if (value === null || value === undefined) return null;
  return (
    <div className="flex items-baseline justify-between py-1.5 border-b border-navy-100/50 last:border-0">
      <span className="text-xs text-navy-500">{label}</span>
      <span className={`text-sm font-medium text-navy-900 ${mono ? 'font-mono text-xs' : ''}`}>
        {value}{unit && <span className="text-navy-400 ml-0.5 text-xs">{unit}</span>}
      </span>
    </div>
  );
}

/* ─── Drug-likeness badge ─── */
function RuleBadge({ rule }: { rule: DrugLikenessResult }) {
  return (
    <div className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium
      ${rule.passed
        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
        : 'bg-red-50 text-red-700 border border-red-200'
      }`}>
      {rule.passed ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
      {rule.rule_name}
    </div>
  );
}

/* ─── GHS Section ─── */
function GHSSection({ safety }: { safety: GHSSafety }) {
  const [showAll, setShowAll] = useState(false);
  const visibleH = showAll ? safety.h_statements : safety.h_statements.slice(0, 4);

  return (
    <div className="space-y-3">
      {/* Signal word */}
      {safety.signal_word && (
        <div className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-bold
          ${safety.signal_word === 'Danger'
            ? 'bg-red-100 text-red-800 border border-red-300'
            : 'bg-amber-100 text-amber-800 border border-amber-300'
          }`}>
          <AlertTriangle className="w-4 h-4" />
          {safety.signal_word}
        </div>
      )}

      {/* Pictograms */}
      {safety.pictograms.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {safety.pictogram_urls.map((url, i) => (
            <div key={i} className="group relative flex flex-col items-center">
              <div className="w-12 h-12 border-2 border-red-400 rounded-md p-0.5 bg-white
                            hover:border-red-600 transition-colors">
                <img src={url} alt={safety.pictograms[i]} className="w-full h-full" />
              </div>
              <span className="text-[10px] text-navy-500 mt-0.5">
                {GHS_LABELS[safety.pictograms[i]] || safety.pictograms[i]}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* H-statements */}
      {safety.h_statements.length > 0 && (
        <div className="space-y-1">
          <p className="text-xs font-semibold text-navy-600 mb-1">위험 문구 (H)</p>
          {visibleH.map((h, i) => (
            <p key={i} className="text-xs text-navy-600 leading-relaxed pl-2 border-l-2 border-amber-300">
              {h}
            </p>
          ))}
          {safety.h_statements.length > 4 && (
            <button
              onClick={() => setShowAll(!showAll)}
              className="text-xs text-accent-blue hover:underline mt-1"
            >
              {showAll ? '접기' : `+${safety.h_statements.length - 4}개 더 보기`}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

/* ─── Similar molecule card ─── */
function SimilarCard({ mol, onClick }: { mol: SimilarMolecule; onClick: () => void }) {
  const [imgErr, setImgErr] = useState(false);
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1.5 p-2 rounded-xl border border-navy-100
                 hover:border-accent-blue hover:shadow-card transition-all min-w-[100px] bg-white"
    >
      <div className="w-16 h-16 bg-navy-50 rounded-lg flex items-center justify-center overflow-hidden">
        {!imgErr ? (
          <img src={mol.thumbnail_url} alt={mol.name} className="w-full h-full object-contain p-1"
               onError={() => setImgErr(true)} />
        ) : (
          <FlaskConical className="w-6 h-6 text-navy-300" />
        )}
      </div>
      <span className="text-[11px] font-medium text-navy-700 text-center leading-tight line-clamp-2">
        {mol.name}
      </span>
      <span className="text-[10px] text-navy-400 font-mono">{mol.molecular_formula}</span>
      <span className="text-[10px] text-accent-blue font-medium">{Math.round(mol.similarity * 100)}% 유사</span>
    </button>
  );
}

/* ═══════════════════════════════════════════
   Main Component
   ═══════════════════════════════════════════ */
interface Props {
  query?: string;
  cid?: number;
  data?: MoleculeCardData;
  onMoleculeClick?: (cid: number) => void;
  compact?: boolean;
  loading?: boolean;
}

export default function MoleculeCardFull({ query, cid, data: initialData, onMoleculeClick, compact = false, loading: externalLoading = false,
}: Props) {
  const [data, setData] = useState<MoleculeCardData | null>(initialData || null);
  const [loading, setLoading] = useState(externalLoading ?? !initialData);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    properties: true,
    druglikeness: true,
    safety: false,
    similar: false,
  });
  const [imgErr, setImgErr] = useState(false);

  useEffect(() => {
    // data prop이 있으면 절대 fetch 하지 않음
    if (initialData) { setData(initialData); setLoading(false); return; }
    // query도 cid도 없으면 fetch 안 함
    if (!query && !cid) { setLoading(false); return; }
    // "CID XXX" 형태의 query는 cid로 변환
    if (query && !cid) {
      const cidMatch = query.match(/^CID\s*(\d+)$/i);
      if (cidMatch) {
        const parsedCid = Number(cidMatch[1]);
        setLoading(true);
        setError(null);
        api.getMoleculeCard({ cid: parsedCid })
          .then(setData)
          .catch((e) => setError(e.message))
          .finally(() => setLoading(false));
        return;
      }
    }

    setLoading(true);
    setError(null);
    api.getMoleculeCard({ q: query, cid: cid })
      .then(setData)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [query, cid, initialData]);

  const toggleSection = (key: string) => {
    setExpandedSections((s) => ({ ...s, [key]: !s[key] }));
  };

  const copyToClipboard = async (text: string, label: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 1500);
  };

    /* ── Error ── */
  if (error) {
    return (
      <div className="bg-white rounded-2xl border border-red-200/50 p-4 text-center">
        <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-2">
          <AlertTriangle className="w-5 h-5 text-red-400" />
        </div>
        <p className="text-sm text-navy-700 font-medium mb-1">카드를 불러올 수 없습니다</p>
        <p className="text-xs text-navy-400">{error}</p>
      </div>
    );
  }

  /* ── Loading Skeleton ── */
  if (loading) {
    return (
      <div className="bg-white rounded-2xl border border-navy-200 overflow-hidden">
        {/* Header skeleton */}
        <div className="bg-gradient-to-r from-navy-50 to-blue-50 p-4 sm:p-5">
          <div className="flex items-start gap-4">
            <div className="w-[100px] h-[100px] rounded-xl bg-navy-200/50 animate-pulse" />
            <div className="flex-1 space-y-2.5">
              <div className="h-5 w-32 bg-navy-200/50 rounded animate-pulse" />
              <div className="h-3 w-48 bg-navy-200/30 rounded animate-pulse" />
              <div className="h-3 w-40 bg-navy-200/30 rounded animate-pulse" />
              <div className="flex gap-2 mt-3">
                <div className="h-6 w-16 bg-navy-200/30 rounded-full animate-pulse" />
                <div className="h-6 w-20 bg-navy-200/30 rounded-full animate-pulse" />
              </div>
            </div>
          </div>
        </div>
        {/* Properties skeleton */}
        <div className="p-4 sm:p-5 space-y-3">
          <div className="h-4 w-24 bg-navy-200/40 rounded animate-pulse" />
          <div className="grid grid-cols-2 gap-x-4 gap-y-2">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex justify-between py-1.5">
                <div className="h-3 w-16 bg-navy-100 rounded animate-pulse" />
                <div className="h-3 w-12 bg-navy-200/40 rounded animate-pulse" />
              </div>
            ))}
          </div>
          {/* Drug-likeness skeleton */}
          <div className="h-4 w-28 bg-navy-200/40 rounded animate-pulse mt-4" />
          <div className="flex gap-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-7 w-20 bg-emerald-100/50 rounded-full animate-pulse" />
            ))}
          </div>
        </div>
        {/* Footer */}
        <div className="px-4 sm:px-5 pb-4 flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin text-navy-400" />
          <p className="text-xs text-navy-400">
            {query ? `'${query}' 분자 카드를 생성하고 있습니다...` : "분자 카드를 생성하고 있습니다..."}
          </p>
        </div>
      </div>
    );
  }

  /* ── Error ── */
  if (error || !data) {
    return (
      <div className="rounded-2xl border border-red-200 bg-red-50 p-6 flex items-center gap-3">
        <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
        <p className="text-sm text-red-700">{error || '분자 정보를 불러올 수 없습니다.'}</p>
      </div>
    );
  }

  const SectionHeader = ({ id, icon: Icon, title, badge }: { id: string; icon: any; title: string; badge?: React.ReactNode }) => (
    <button
      onClick={() => toggleSection(id)}
      className="flex items-center gap-2 w-full py-2.5 text-left group"
    >
      <Icon className="w-4 h-4 text-navy-400 group-hover:text-accent-blue transition-colors" />
      <span className="text-sm font-semibold text-navy-800 flex-1">{title}</span>
      {badge}
      {expandedSections[id]
        ? <ChevronUp className="w-4 h-4 text-navy-400" />
        : <ChevronDown className="w-4 h-4 text-navy-400" />}
    </button>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="rounded-2xl border border-navy-100 bg-white shadow-card overflow-hidden max-w-lg w-full"
    >
      {/* ── HEADER ── */}
      <div className="bg-gradient-to-r from-navy-50 to-white px-5 py-4 border-b border-navy-100">
        <div className="flex items-start gap-4">
          {/* Structure image */}
          <div className="shrink-0 w-20 h-20 bg-white rounded-xl border border-navy-100 shadow-sm
                         flex items-center justify-center overflow-hidden">
            {data.image_url && !imgErr ? (
              <img src={`${data.image_url}?image_size=200x200`} alt={data.name}
                   className="w-full h-full object-contain p-1"
                   onError={() => setImgErr(true)} />
            ) : (
              <FlaskConical className="w-8 h-8 text-navy-300" />
            )}
          </div>

          {/* Name & identifiers */}
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold text-navy-900 leading-tight">
              {data.name}
            </h3>
            {data.iupac_name && (
              <p className="text-xs text-navy-500 mt-0.5 italic leading-snug line-clamp-2">
                {data.iupac_name}
              </p>
            )}
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              {data.cid && (
                <span className="badge-blue text-[11px] px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-mono">
                  CID {data.cid}
                </span>
              )}
              {data.molecular_formula && (
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-navy-50 text-navy-600 font-mono">
                  {data.molecular_formula}
                </span>
              )}
              {data.source && (
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600">
                  {data.source}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* AI Summary */}
        {data.ai_summary && (
          <p className="mt-3 text-xs text-navy-600 leading-relaxed bg-blue-50/50 rounded-lg px-3 py-2 border border-blue-100">
            {data.ai_summary}
          </p>
        )}
      </div>

      {/* ── BODY ── */}
      <div className="px-5 py-1 divide-y divide-navy-100/50">

        {/* Properties Section */}
        <div>
          <SectionHeader id="properties" icon={Beaker} title="물리화학적 성질" />
          <AnimatePresence>
            {expandedSections.properties && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="pb-3 grid grid-cols-2 gap-x-4">
                  <PropItem label="분자량" value={data.molecular_weight} unit="g/mol" />
                  <PropItem label="XLogP" value={data.xlogp} />
                  <PropItem label="TPSA" value={data.tpsa} unit="Å²" />
                  <PropItem label="H-Bond 공여체" value={data.hbond_donor} />
                  <PropItem label="H-Bond 수용체" value={data.hbond_acceptor} />
                  <PropItem label="회전 가능 결합" value={data.rotatable_bonds} />
                  <PropItem label="무거운 원자 수" value={data.heavy_atom_count} />
                  <PropItem label="복잡도" value={data.complexity} />
                  <PropItem label="정확한 질량" value={data.exact_mass} unit="Da" mono />
                  <PropItem label="전하" value={data.charge} />
                </div>

                {/* SMILES copy */}
                {data.canonical_smiles && (
                  <div className="mb-3 flex items-center gap-2 bg-navy-50 rounded-lg px-3 py-2">
                    <span className="text-[11px] text-navy-500 shrink-0">SMILES</span>
                    <code className="text-[11px] font-mono text-navy-700 flex-1 truncate">
                      {data.canonical_smiles}
                    </code>
                    <button
                      onClick={() => copyToClipboard(data.canonical_smiles, 'smiles')}
                      className="shrink-0 p-1 rounded hover:bg-navy-200 transition-colors"
                    >
                      {copied === 'smiles'
                        ? <Check className="w-3.5 h-3.5 text-emerald-500" />
                        : <Copy className="w-3.5 h-3.5 text-navy-400" />}
                    </button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Drug-likeness Section */}
        {data.drug_likeness.length > 0 && (
          <div>
            <SectionHeader
              id="druglikeness"
              icon={Atom}
              title="약물 유사성"
              badge={
                <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium
                  ${data.drug_likeness.every(r => r.passed)
                    ? 'bg-emerald-50 text-emerald-600'
                    : 'bg-amber-50 text-amber-600'
                  }`}>
                  {data.drug_likeness.filter(r => r.passed).length}/{data.drug_likeness.length} 통과
                </span>
              }
            />
            <AnimatePresence>
              {expandedSections.druglikeness && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="pb-3 flex flex-wrap gap-2">
                    {data.drug_likeness.map((rule, i) => (
                      <RuleBadge key={i} rule={rule} />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* GHS Safety Section */}
        {data.ghs_safety && (data.ghs_safety.signal_word || data.ghs_safety.pictograms.length > 0) && (
          <div>
            <SectionHeader
              id="safety"
              icon={Shield}
              title="안전 정보 (GHS)"
              badge={
                data.ghs_safety.signal_word && (
                  <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold
                    ${data.ghs_safety.signal_word === 'Danger'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-amber-100 text-amber-700'
                    }`}>
                    {data.ghs_safety.signal_word}
                  </span>
                )
              }
            />
            <AnimatePresence>
              {expandedSections.safety && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="pb-3">
                    <GHSSection safety={data.ghs_safety} />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* Similar Molecules Section */}
        {data.similar_molecules.length > 0 && (
          <div>
            <SectionHeader
              id="similar"
              icon={FlaskConical}
              title="유사 분자"
              badge={
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-navy-50 text-navy-500">
                  {data.similar_molecules.length}개
                </span>
              }
            />
            <AnimatePresence>
              {expandedSections.similar && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="pb-3 flex gap-2 overflow-x-auto scrollbar-hide">
                    {data.similar_molecules.map((mol) => (
                      <SimilarCard
                        key={mol.cid}
                        mol={mol}
                        onClick={() => onMoleculeClick?.(mol.cid)}
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* ── FOOTER ── */}
      <div className="px-5 py-3 bg-navy-50/50 border-t border-navy-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {data.id && (
            <a href={`/molchat/molecule/${data.id}`} target="_blank" rel="noopener noreferrer"
               className="inline-flex items-center gap-1 text-xs font-medium text-white bg-accent-blue hover:bg-blue-600 px-2.5 py-1 rounded-md transition-colors">
              <Atom className="w-3 h-3" />
              구조 상세 보기
            </a>
          )}
          {!data.id && data.cid && (
            <a href={`/molchat/molecule/${data.cid}`} target="_blank" rel="noopener noreferrer"
               className="inline-flex items-center gap-1 text-xs font-medium text-white bg-accent-blue hover:bg-blue-600 px-2.5 py-1 rounded-md transition-colors">
              <Atom className="w-3 h-3" />
              구조 상세 보기
            </a>
          )}
          {data.source_url && (
            <a href={data.source_url} target="_blank" rel="noopener noreferrer"
               className="inline-flex items-center gap-1 text-xs text-accent-blue hover:underline">
              <ExternalLink className="w-3 h-3" />
              PubChem
            </a>
          )}
          {data.inchikey && (
            <button
              onClick={() => copyToClipboard(data.inchikey!, 'inchikey')}
              className="inline-flex items-center gap-1 text-xs text-navy-400 hover:text-navy-600 transition-colors"
            >
              {copied === 'inchikey'
                ? <Check className="w-3 h-3 text-emerald-500" />
                : <Copy className="w-3 h-3" />}
              InChIKey
            </button>
          )}
        </div>
        <span className="text-[10px] text-navy-400">
          {data.cached ? '⚡ 캐시' : `${Math.round(data.elapsed_ms)}ms`}
        </span>
      </div>
    </motion.div>
  );
}
