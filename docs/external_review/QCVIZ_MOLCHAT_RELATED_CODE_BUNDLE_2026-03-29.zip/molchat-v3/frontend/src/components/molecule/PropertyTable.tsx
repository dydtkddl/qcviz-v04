interface Props {
  properties: Record<string, any>;
  weight?: number | null;
  formula?: string | null;
}

const PROP_MAP: { key: string; label: string; unit?: string; source?: string }[] = [
  { key: "molecular_weight", label: "Molecular Weight", unit: "g/mol", source: "computed" },
  { key: "xlogp", label: "XLogP3", source: "PubChem" },
  { key: "alogp", label: "ALogP", source: "ChEMBL" },
  { key: "tpsa", label: "TPSA", unit: "Å²", source: "computed" },
  { key: "psa", label: "PSA", unit: "Å²", source: "ChEMBL" },
  { key: "hbond_donor", label: "H-Bond Donors", source: "computed" },
  { key: "hbd", label: "H-Bond Donors", source: "ChEMBL" },
  { key: "hbond_acceptor", label: "H-Bond Acceptors", source: "computed" },
  { key: "hba", label: "H-Bond Acceptors", source: "ChEMBL" },
  { key: "rotatable_bonds", label: "Rotatable Bonds", source: "computed" },
  { key: "rtb", label: "Rotatable Bonds", source: "ChEMBL" },
  { key: "heavy_atom_count", label: "Heavy Atoms", source: "computed" },
  { key: "heavy_atoms", label: "Heavy Atoms", source: "ChEMBL" },
  { key: "aromatic_rings", label: "Aromatic Rings", source: "ChEMBL" },
  { key: "complexity", label: "Complexity", source: "PubChem" },
  { key: "charge", label: "Formal Charge", source: "computed" },
  { key: "exact_mass", label: "Exact Mass", unit: "Da", source: "computed" },
];

export default function PropertyTable({ properties, weight, formula }: Props) {
  const seen = new Set<string>();
  const rows = PROP_MAP.filter(({ key, label }) => {
    const val = properties[key];
    if (val == null || val === "" || seen.has(label)) return false;
    seen.add(label);
    return true;
  });

  return (
    <div className="space-y-1.5">
      {weight != null && (
        <div className="flex items-center justify-between py-1.5 border-b border-navy-50">
          <span className="text-xs text-navy-600">Molecular Weight</span>
          <span className="text-xs font-medium text-navy-900">{weight.toFixed(2)} <span className="text-navy-400">g/mol</span></span>
        </div>
      )}
      {rows.map(({ key, label, unit, source }) => {
        const val = properties[key];
        return (
          <div key={key} className="flex items-center justify-between py-1.5 border-b border-navy-50 last:border-0">
            <span className="text-xs text-navy-600">{label}</span>
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-navy-900">
                {typeof val === "number" ? (Number.isInteger(val) ? val : val.toFixed(2)) : val}
                {unit && <span className="text-navy-400 ml-0.5">{unit}</span>}
              </span>
              {source && (
                <span className="text-[9px] text-navy-300">{source}</span>
              )}
            </div>
          </div>
        );
      })}
      {rows.length === 0 && !weight && (
        <p className="text-xs text-navy-400 py-2">No properties available</p>
      )}
    </div>
  );
}
