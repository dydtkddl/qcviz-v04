'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api';

interface Props {
  smiles: string;
  width?: number;
  height?: number;
}

export default function StructureRenderer({ smiles, width = 300, height = 200 }: Props) {
  const [svg, setSvg] = useState<string | null>(null);

  useEffect(() => {
    // Use PubChem 2D image as fallback
    const url = `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/smiles/${encodeURIComponent(smiles)}/PNG?image_size=${width}x${height}`;
    setSvg(url);
  }, [smiles, width, height]);

  if (!svg) {
    return (
      <div
        className="flex items-center justify-center rounded-lg bg-surface-800"
        style={{ width, height }}
      >
        <span className="text-xs text-surface-500">Loading structure...</span>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border border-surface-800 bg-white">
      <img
        src={svg}
        alt={`2D structure of ${smiles}`}
        width={width}
        height={height}
        className="block"
        loading="lazy"
      />
    </div>
  );
}