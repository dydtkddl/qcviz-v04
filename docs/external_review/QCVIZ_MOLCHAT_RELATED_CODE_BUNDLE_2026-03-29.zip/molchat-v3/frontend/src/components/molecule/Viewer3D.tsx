"use client";
import { useEffect, useRef, useState } from "react";
import { Loader2 } from "lucide-react";

interface Props {
  sdfData?: string;
  style?: "stick" | "ballAndStick" | "sphere";
  height?: string;
}

const STYLE_MAP: Record<string, any> = {
  stick: { stick: { radius: 0.15, colorscheme: "Jmol" } },
  ballAndStick: {
    stick: { radius: 0.1, colorscheme: "Jmol" },
    sphere: { scale: 0.25, colorscheme: "Jmol" },
  },
  sphere: { sphere: { colorscheme: "Jmol" } },
};

function get3Dmol(): any {
  if (typeof window !== "undefined") {
    return (window as any).$3Dmol;
  }
  return null;
}

export default function Viewer3D({
  sdfData,
  style = "stick",
  height = "420px",
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<any>(null);
  const [libLoaded, setLibLoaded] = useState(false);
  const [error, setError] = useState("");
  const [rendering, setRendering] = useState(false);

  // Load 3Dmol.js from local public folder
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (get3Dmol()) {
      setLibLoaded(true);
      return;
    }
    if (document.querySelector('script[data-3dmol]')) {
      // Script already loading, poll for availability
      const interval = setInterval(() => {
        if (get3Dmol()) {
          setLibLoaded(true);
          clearInterval(interval);
        }
      }, 100);
      return () => clearInterval(interval);
    }

    const tryLoad = (src: string, label: string) => {
      const script = document.createElement("script");
      script.src = src;
      script.setAttribute("data-3dmol", "true");
      script.onload = () => {
        console.log("[Viewer3D] 3Dmol.js loaded from", label, "window.$3Dmol:", typeof get3Dmol());
        if (get3Dmol()) {
          setLibLoaded(true);
        } else {
          console.warn("[Viewer3D] $3Dmol not found after load from", label);
          if (label === "local") {
            tryLoad("https://3Dmol.org/build/3Dmol-min.js", "cdn");
          } else {
            setError("3Dmol.js loaded but $3Dmol not available");
          }
        }
      };
      script.onerror = () => {
        console.warn("[Viewer3D] Failed to load from", label);
        if (label === "local") {
          tryLoad("https://3Dmol.org/build/3Dmol-min.js", "cdn");
        } else {
          setError("Failed to load 3Dmol.js from all sources");
        }
      };
      document.head.appendChild(script);
    };
    tryLoad("/js/3Dmol-min.js", "local");
  }, []);

  // Render molecule
  useEffect(() => {
    if (!libLoaded || !containerRef.current || !sdfData || sdfData.length < 20) return;

    const $3Dmol = get3Dmol();
    if (!$3Dmol) {
      setError("3Dmol.js not available after load");
      return;
    }

    setRendering(true);
    setError("");

    // Cleanup previous viewer
    if (viewerRef.current) {
      try { viewerRef.current.clear(); } catch {}
      viewerRef.current = null;
    }
    containerRef.current.innerHTML = "";

    try {
      console.log("[Viewer3D] Rendering SDF:", sdfData.length, "chars");
      const viewer = $3Dmol.createViewer(containerRef.current, {
        backgroundColor: "white",
        antialias: true,
      });

      viewer.addModel(sdfData, "sdf");
      const styleObj = STYLE_MAP[style] || STYLE_MAP.stick;
      viewer.setStyle({}, styleObj);
      viewer.zoomTo();
      viewer.render();
      viewerRef.current = viewer;
      console.log("[Viewer3D] Render complete");
    } catch (e: any) {
      console.error("[Viewer3D] Render error:", e);
      setError(`Render failed: ${e.message}`);
    } finally {
      setRendering(false);
    }
  }, [libLoaded, sdfData, style]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (viewerRef.current) {
        try { viewerRef.current.clear(); } catch {}
        viewerRef.current = null;
      }
    };
  }, []);

  // --- Render states ---
  if (!sdfData || sdfData.length < 20) {
    return (
      <div className="flex items-center justify-center rounded-xl bg-navy-50 text-navy-400 text-sm"
           style={{ height }}>
        No structure data available
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 rounded-xl bg-red-50 text-red-500 text-sm"
           style={{ height }}>
        <p>{error}</p>
        <p className="text-xs text-red-400">SDF data: {sdfData.length} chars</p>
      </div>
    );
  }

  if (!libLoaded || rendering) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 rounded-xl bg-navy-50"
           style={{ height }}>
        <Loader2 size={24} className="animate-spin text-navy-400" />
        <p className="text-sm text-navy-400">
          {!libLoaded ? "Loading 3D viewer..." : "Rendering structure..."}
        </p>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="w-full rounded-xl bg-white border border-navy-100"
      style={{ height, position: "relative" }}
    />
  );
}
