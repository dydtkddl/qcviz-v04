import { getApiBase } from "./runtime-config";

const API_BASE = getApiBase();

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const url = `${API_BASE}${path}`;
  const headers = new Headers(options?.headers as HeadersInit | undefined);
  if (options?.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const res = await fetch(url, {
    headers,
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: `HTTP ${res.status}` }));
    throw new Error(err.detail || err.message || `Request failed: ${res.status}`);
  }
  return res.json();
}

async function requestText(path: string): Promise<string> {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed: ${res.status}`);
  return res.text();
}

/* ── Types ── */
export interface MoleculeRecord {
  id: string;
  cid: number | null;
  name: string;
  canonical_smiles: string;
  inchi?: string | null;
  inchikey?: string | null;
  molecular_formula?: string | null;
  molecular_weight?: number | null;
  properties?: Record<string, any>;
  structures?: any[];
  computed_properties?: any[];
}

export interface SearchResponse {
  query: string;
  total: number;
  results: MoleculeRecord[];
  sources_queried: string[];
  cache_hit: boolean;
  elapsed_ms: number;
  resolved_query?: string;
  original_query?: string;
  resolve_method?: string;
  resolve_suggestions?: string[];
}

export interface DetailResponse {
  molecule: MoleculeRecord;
  available_formats: string[];
  calculation_status?: string | null;
}

export interface StructureInfo {
  id: string;
  format: string;
  generation_method: string;
  is_primary: boolean;
  data_length: number;
}

export interface SessionItem {
  id: string;
  title: string | null;
  model_used: string | null;
  message_count: number;
  created_at: string;
  updated_at: string;
}

export interface SessionListResponse {
  total: number;
  limit: number;
  offset: number;
  sessions: SessionItem[];
}

export interface ChatMessageResponse {
  id: string;
  session_id: string;
  role: string;
  content: string;
  token_count?: number;
  model_used?: string;
  tool_calls?: Record<string, any>;
  metadata_extra?: Record<string, any>;
  created_at: string;
}

export interface ChatApiResponse {
  session_id: string;
  message: ChatMessageResponse;
  molecules_referenced: Record<string, any>[];
  tool_results: {
    tool: string;
    success: boolean;
    result_preview: string;
    elapsed_ms: number;
  }[];
  confidence?: number;
  hallucination_flags: string[];
  elapsed_ms: number;
}

/* ── API methods ── */
export const api = {
  // Molecules
  searchMolecules: (query: string, limit = 10) =>
    request<SearchResponse>(`/api/v1/molecules/search?q=${encodeURIComponent(query)}&limit=${limit}`),

  getMoleculeDetail: (id: string) =>
    request<DetailResponse>(`/api/v1/molecules/${id}`),

  getStructures: (id: string) =>
    request<StructureInfo[]>(`/api/v1/molecules/${id}/structures`),

  downloadStructure: (id: string, format: string) =>
    requestText(`/api/v1/molecules/${id}/structure/${format}`),

  // Chat
  sendMessage: (message: string, sessionId?: string) =>
    request<ChatApiResponse>("/api/v1/chat", {
      method: "POST",
      body: JSON.stringify({ message, session_id: sessionId }),
    }),

  // Sessions
  listSessions: (params?: { q?: string; limit?: number; offset?: number }) => {
    const sp = new URLSearchParams();
    if (params?.q) sp.set("q", params.q);
    if (params?.limit) sp.set("limit", String(params.limit));
    if (params?.offset) sp.set("offset", String(params.offset));
    const qs = sp.toString();
    return request<SessionListResponse>(`/api/v1/chat/sessions${qs ? `?${qs}` : ""}`);
  },

  getSession: (sessionId: string) =>
    request<SessionItem>(`/api/v1/chat/sessions/${sessionId}`),

  getHistory: (sessionId: string, limit = 50) =>
    request<ChatMessageResponse[]>(`/api/v1/chat/${sessionId}/history?limit=${limit}`),

  updateSession: (sessionId: string, title: string) =>
    request<SessionItem>(`/api/v1/chat/sessions/${sessionId}`, {
      method: "PUT",
      body: JSON.stringify({ title }),
    }),

  deleteSession: (sessionId: string) =>
    request<void>(`/api/v1/chat/sessions/${sessionId}`, { method: "DELETE" }),

  healthCheck: () => request<any>("/health"),

  // 3D Structure Generation
  generate3D: (smiles: string, format: string = "sdf", optimizeXtb: boolean = false) =>
    request<{
      smiles: string;
      format: string;
      structure_data: string;
      generation_method: string;
      atom_count: number;
      properties: Record<string, any> | null;
    }>("/api/v1/molecules/generate-3d", {
      method: "POST",
      body: JSON.stringify({ smiles, format, optimize_xtb: optimizeXtb }),
    }),

  generate3DSdf: (smiles: string) =>
    requestText(`/api/v1/molecules/generate-3d/sdf?smiles=\${encodeURIComponent(smiles)}`),

  // Molecule Card
  getMoleculeCard: (params: { q?: string; cid?: number }) => {
    const sp = new URLSearchParams();
    if (params.q) sp.set("q", params.q);
    if (params.cid) sp.set("cid", String(params.cid));
    return request<import("@/types/moleculeCard").MoleculeCardData>(
      `/api/v1/molecules/card?${sp.toString()}`
    );
  },
};

// Legacy alias — expose all api methods
// Legacy alias — expose all api methods
export const apiClient = {
  ...api,
};
