const DEFAULT_BACKEND_PORT = "8333";
const DEFAULT_BASE_PATH = "/molchat";

function normalizeBaseUrl(value: string | undefined): string | null {
  if (!value) return null;

  const trimmed = value.trim();
  if (!trimmed) return null;

  try {
    const parsed = new URL(trimmed);
    if (!parsed.hostname) return null;
    return trimmed.replace(/\/+$/, "");
  } catch {
    return null;
  }
}

function normalizeRelativeBase(value: string | undefined): string | null {
  if (!value) return null;

  const trimmed = value.trim();
  if (!trimmed.startsWith("/")) return null;
  return trimmed.replace(/\/+$/, "") || "/";
}

function getBrowserHost(): string | null {
  if (typeof window === "undefined") return null;
  return window.location.hostname || null;
}

function getBrowserLocation(): Location | null {
  if (typeof window === "undefined") return null;
  return window.location;
}

export function getApiBase(): string {
  const envBase = normalizeBaseUrl(process.env.NEXT_PUBLIC_API_URL);
  if (envBase) return envBase;

  const relativeBase = normalizeRelativeBase(process.env.NEXT_PUBLIC_API_URL);
  if (relativeBase) {
    if (typeof window !== "undefined") return relativeBase;
    return `http://localhost:3000${relativeBase}`;
  }

  if (typeof window !== "undefined") return DEFAULT_BASE_PATH;

  const location = getBrowserLocation();
  const host = getBrowserHost();
  if (location && host) {
    return `${location.protocol}//${host}:${DEFAULT_BACKEND_PORT}`;
  }

  return `http://localhost:${DEFAULT_BACKEND_PORT}`;
}

export function getWsBase(): string {
  const envBase = normalizeBaseUrl(process.env.NEXT_PUBLIC_WS_URL);
  if (envBase) return envBase;

  const relativeBase =
    normalizeRelativeBase(process.env.NEXT_PUBLIC_WS_URL) || DEFAULT_BASE_PATH;

  const location = getBrowserLocation();
  if (location) {
    const protocol = location.protocol === "https:" ? "wss:" : "ws:";
    return `${protocol}//${location.host}${relativeBase}`;
  }

  return `ws://localhost:${DEFAULT_BACKEND_PORT}`;
}
