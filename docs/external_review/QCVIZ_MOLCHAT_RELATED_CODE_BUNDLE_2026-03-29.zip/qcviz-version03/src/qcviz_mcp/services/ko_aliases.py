"""Korean → English molecule name alias dictionary and translator.

# FIX(N1): 한국어 분자명 30개 매핑 + 조사 제거 + 번역 함수
"""
from __future__ import annotations

import re
from typing import Dict, Optional

# ── 한국어→영어 분자명 매핑 (30개) ──────────────────────────────
KO_TO_EN: Dict[str, str] = {
    "물": "water",
    "에탄올": "ethanol",
    "메탄올": "methanol",
    "메탄": "methane",
    "에탄": "ethane",
    "메틸아민": "methylamine",
    "메탄아민": "methylamine",
    "에틸아민": "ethylamine",
    "에탄아민": "ethylamine",
    "디메틸아민": "dimethylamine",
    "트리메틸아민": "trimethylamine",
    "프로필아민": "propylamine",
    "부틸아민": "butylamine",
    "벤젠": "benzene",
    "톨루엔": "toluene",
    "아세톤": "acetone",
    "암모니아": "ammonia",
    "이산화탄소": "carbon dioxide",
    "일산화탄소": "carbon monoxide",
    "포름알데히드": "formaldehyde",
    "아세트산": "acetic acid",
    "글리신": "glycine",
    "요소": "urea",
    "피리딘": "pyridine",
    "페놀": "phenol",
    "아닐린": "aniline",
    "아스피린": "aspirin",
    "카페인": "caffeine",
    "포도당": "glucose",
    "과산화수소": "hydrogen peroxide",
    "황산": "sulfuric acid",
    "염산": "hydrochloric acid",
    "수산화나트륨": "sodium hydroxide",
    "아세틸렌": "acetylene",
    "프로판": "propane",
    "부탄": "butane",
    "부타다이엔": "butadiene",
    "뷰타다이엔": "butadiene",
    "부타 다이엔": "butadiene",
    "뷰타 다이엔": "butadiene",
    "1,3-뷰타다이엔": "1,3-butadiene",
    "1,3-뷰타 다이엔": "1,3-butadiene",
    "나프탈렌": "naphthalene",
    "글루탐산": "glutamic acid",
    "세로토닌": "serotonin",
}

# ── 한국어 조사 패턴 (제거 대상) ──────────────────────────────
_JOSA_PATTERN = re.compile(
    r"(?:은|는|이|가|을|를|의|에|에서|로|부터|에\s*대해|에\s*대한|도|만|까지|처럼|같은|하고|이랑|랑|과|와)\s*$"
)

_JOSA_INLINE_PATTERN = re.compile(
    r"(?:은|는|이|가|을|를|의|에|에서|로|부터|에\s*대해|에\s*대한|도|만|까지|처럼|같은|하고|이랑|랑|과|와)(?=\s)"
)

_SUBSCRIPT_MAP = str.maketrans("₀₁₂₃₄₅₆₇₈₉₊₋", "0123456789+-")


def _normalize_formula_text(text: str) -> str:
    result = str(text or "").translate(_SUBSCRIPT_MAP)
    result = re.sub(r"\s*/+\s*$", "", result).strip()
    return result


def _strip_josa(text: str) -> str:
    """Remove trailing Korean postpositions (조사)."""
    result = text.strip()
    for _ in range(3):  # iterative strip in case of stacking
        prev = result
        result = _JOSA_PATTERN.sub("", result).strip()
        if result == prev:
            break
    return result


def translate(text: str) -> str:
    """Translate Korean molecule names to English in the input text.

    - Longest-match-first replacement to avoid partial matches.
    - Strips common Korean postpositions before and after replacement.

    Args:
        text: User input that may contain Korean molecule names.

    Returns:
        Text with Korean molecule names replaced by English equivalents.
    """
    if not text or not text.strip():
        return text

    result = _normalize_formula_text(text.strip())

    # Sort by length descending for longest-match-first
    sorted_aliases = sorted(KO_TO_EN.items(), key=lambda x: len(x[0]), reverse=True)

    for ko_name, en_name in sorted_aliases:
        if ko_name in result:
            # Replace with surrounding josa removal
            # Pattern: (optional josa before) + ko_name + (optional josa after)
            pattern = re.compile(
                rf"({re.escape(ko_name)})"
                r"(?:은|는|이|가|을|를|의|에|에서|로|부터|에\s*대해|에\s*대한|도|만|까지)?"
            )
            result = pattern.sub(en_name, result)

    return result.strip()


def find_molecule_name(text: str) -> Optional[str]:
    """Find and return the English molecule name from Korean text.

    Returns:
        The English molecule name if found, None otherwise.
    """
    if not text:
        return None

    cleaned = _strip_josa(_normalize_formula_text(text.strip()))

    # Longest match first
    sorted_aliases = sorted(KO_TO_EN.items(), key=lambda x: len(x[0]), reverse=True)

    for ko_name, en_name in sorted_aliases:
        if ko_name in cleaned:
            return en_name

    return None
