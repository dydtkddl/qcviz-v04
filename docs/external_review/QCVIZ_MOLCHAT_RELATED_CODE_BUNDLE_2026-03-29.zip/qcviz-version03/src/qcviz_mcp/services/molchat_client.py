"""MolChat API async client.

# FIX(N3): MolChat REST 클라이언트 — resolve, card, generate-3d/sdf
Base URL: http://psid.aizen.co.kr/molchat
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "http://psid.aizen.co.kr/molchat"
_DEFAULT_TIMEOUT = 15


class MolChatClient:
    """Async HTTP client for the MolChat molecule service."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
    ) -> None:
        self.base_url: str = (
            base_url
            or os.getenv("MOLCHAT_BASE_URL", _DEFAULT_BASE_URL)
        ).rstrip("/")
        self.timeout: float = timeout or float(
            os.getenv("MOLCHAT_TIMEOUT", str(_DEFAULT_TIMEOUT))
        )
        self.api_key: Optional[str] = api_key or os.getenv("MOLCHAT_API_KEY")
        self._client: Optional[httpx.AsyncClient] = None

    # ── lifecycle ──────────────────────────────────────────────

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers: Dict[str, str] = {
                "Accept": "application/json",
                "User-Agent": "QCViz-MCP/3.0",
            }
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
                headers=headers,
                follow_redirects=True,
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    # ── health ─────────────────────────────────────────────────

    async def health_live(self) -> bool:
        try:
            client = await self._get_client()
            resp = await client.get("/api/v1/health/live")
            return resp.status_code == 200
        except Exception:
            return False

    async def health_ready(self) -> bool:
        try:
            client = await self._get_client()
            resp = await client.get("/api/v1/health/ready")
            return resp.status_code == 200
        except Exception:
            return False

    # ── resolve ────────────────────────────────────────────────

    @retry(
        retry=retry_if_exception_type((httpx.HTTPError, httpx.TimeoutException)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=4),
        reraise=True,
    )
    async def resolve(self, names: List[str]) -> List[Dict[str, Any]]:
        """Resolve molecule names to CIDs.

        GET /api/v1/molecules/resolve?names=water,ethanol

        Returns:
            List of {name, cid} dicts. Items without CID are omitted.
        """
        if not names:
            return []

        client = await self._get_client()
        names_param = ",".join(n.strip() for n in names if n.strip())
        resp = await client.get(
            "/api/v1/molecules/resolve",
            params={"names": names_param},
        )
        resp.raise_for_status()
        data = resp.json()
        resolved = data.get("resolved", [])
        return [r for r in resolved if r.get("cid")]

    # ── card ───────────────────────────────────────────────────

    @retry(
        retry=retry_if_exception_type((httpx.HTTPError, httpx.TimeoutException)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=4),
        reraise=True,
    )
    async def get_card(self, query: str) -> Optional[Dict[str, Any]]:
        """Get molecule card (SMILES, weight, etc.).

        GET /api/v1/molecules/card?q=aspirin

        Returns:
            Card dict or None if not found.
        """
        if not query or not query.strip():
            return None

        client = await self._get_client()
        resp = await client.get(
            "/api/v1/molecules/card",
            params={"q": query.strip()},
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        data = resp.json()
        return data if data.get("cid") else None

    # ── generate-3d SDF ───────────────────────────────────────

    @retry(
        retry=retry_if_exception_type((httpx.HTTPError, httpx.TimeoutException)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        reraise=True,
    )
    async def generate_3d_sdf(
        self,
        smiles: str,
        optimize_xtb: bool = False,
    ) -> Optional[str]:
        """Generate 3D SDF from SMILES.

        GET /api/v1/molecules/generate-3d/sdf?smiles=O&optimize_xtb=false

        Returns:
            SDF text string or None.
        """
        if not smiles or not smiles.strip():
            return None

        client = await self._get_client()
        params: Dict[str, Any] = {"smiles": smiles.strip()}
        if optimize_xtb:
            params["optimize_xtb"] = "true"

        resp = await client.get(
            "/api/v1/molecules/generate-3d/sdf",
            params=params,
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()

        text = resp.text.strip()
        if not text or "V2000" not in text:
            logger.warning(
                "MolChat generate-3d 응답에 V2000 MOL 블록 없음 / "
                "No V2000 block in MolChat generate-3d response"
            )
            return None

        return text

    # ── convenience: name → SDF pipeline ──────────────────────

    async def name_to_sdf(self, name: str, optimize_xtb: bool = False) -> Optional[str]:
        """High-level: molecule name → resolve → card → SMILES → 3D SDF.

        Returns:
            SDF text or None if any step fails.
        """
        # Step 1: resolve to CID
        resolved = await self.resolve([name])
        if not resolved:
            logger.info("MolChat resolve 실패: %s / MolChat resolve failed: %s", name, name)
            return None

        # Step 2: get card for SMILES
        card = await self.get_card(name)
        smiles: Optional[str] = None
        if card:
            smiles = card.get("canonical_smiles") or card.get("smiles")

        # If card failed, try PubChem-style CID→SMILES later (caller handles fallback)
        if not smiles:
            logger.info(
                "MolChat card에서 SMILES를 못 얻음: %s / "
                "No SMILES from MolChat card: %s",
                name, name,
            )
            return None

        # Step 3: generate 3D SDF
        sdf = await self.generate_3d_sdf(smiles, optimize_xtb=optimize_xtb)
        return sdf
