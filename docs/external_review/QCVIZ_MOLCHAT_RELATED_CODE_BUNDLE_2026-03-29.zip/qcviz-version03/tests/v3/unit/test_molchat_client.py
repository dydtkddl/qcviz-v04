"""tests/v3/unit/test_molchat_client.py — MolChat 클라이언트 단위 테스트 (mock)"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from qcviz_mcp.services.molchat_client import MolChatClient


@pytest.fixture
def client():
    return MolChatClient(base_url="http://mock-molchat:8000", timeout=5.0)


@pytest.fixture
def mock_response_ok():
    """200 OK 응답 mock"""
    resp = MagicMock()
    resp.status_code = 200
    resp.raise_for_status = MagicMock()
    return resp


class TestMolChatResolve:
    """resolve() 메서드 검증"""

    @pytest.mark.asyncio
    async def test_resolve_water(self, client, mock_response_ok):
        """'water' resolve → CID 포함 결과."""
        mock_response_ok.json = MagicMock(return_value={
            "resolved": [{"name": "water", "cid": 962}], "total": 1
        })
        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.get = AsyncMock(return_value=mock_response_ok)
            instance.post = AsyncMock(return_value=mock_response_ok)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=None)
            MockClient.return_value = instance
            result = await client.resolve(["water"])
        assert result is not None

    @pytest.mark.asyncio
    async def test_resolve_empty(self, client):
        """빈 리스트 → 빈 결과."""
        result = await client.resolve([])
        assert result is not None


class TestMolChatGenerate:
    """generate_3d_sdf() 메서드 검증"""

    @pytest.mark.asyncio
    async def test_generate_3d_sdf(self, client, mock_response_ok):
        """SMILES → SDF 문자열 생성."""
        mock_response_ok.text = "fake sdf content\nM  END\n$$$$"
        mock_response_ok.json = MagicMock(return_value={"sdf": "fake sdf content"})
        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=mock_response_ok)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=None)
            MockClient.return_value = instance
            # This tests that the method exists and is callable
            assert hasattr(client, "generate_3d_sdf") or hasattr(client, "name_to_sdf")


class TestMolChatPipeline:
    """name_to_sdf 파이프라인 검증"""

    @pytest.mark.asyncio
    async def test_name_to_sdf_exists(self, client):
        """name_to_sdf 메서드가 존재해야 한다."""
        assert hasattr(client, "name_to_sdf")
